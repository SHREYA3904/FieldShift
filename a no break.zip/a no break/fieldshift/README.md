---
title: TerraAdapt
emoji: 🌾
colorFrom: purple
colorTo: yellow
sdk: docker
app_port: 7860
pinned: false
---

# TerraAdapt (Field Shift) v0.7

NASA climate and satellite data turned into crop-rotation advice for your own field, plus a 16-day weather outlook and an assistant that remembers you.

## Run it (Windows PowerShell)
```
cd fieldshift
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PYTHONPATH="src"
python -m uvicorn --app-dir src fieldshift.api:app --port 8001
```
Open http://127.0.0.1:8001/app/

## Accounts
Email + password only. No OTP, no email or SMS provider needed. Each account keeps its own fields, profile, daily analysis snapshots and chat memory in `fieldshift.db` (set `FIELDSHIFT_DB` to move it).
- Passwords are hashed with scrypt; sessions are httpOnly cookies; 5 wrong tries locks sign-in for 15 minutes.
- Forgot password: there is no email service, so the server owner runs `python -m fieldshift.reset_password someone@example.com`.
- Behind HTTPS set `FIELDSHIFT_COOKIE_SECURE=1`.

## Gemini assistant
1. Create a key at https://aistudio.google.com/apikey
2. Either paste it in the gear (Settings) in the app (kept in your browser only, sent per request, never stored on the server), or set `GEMINI_API_KEY` on the server.
3. Model defaults to `gemini-2.5-flash`; change it in Settings or with `FIELDSHIFT_MODEL`.
Without a key the assistant still answers from built-in rules. Any number in a Gemini reply that is not in the analysis causes a fallback to the rule-based answer.

## Data
NASA POWER (daily weather), MODIS MOD13Q1 NDVI via ORNL DAAC, SoilGrids, Open-Meteo (elevation and the 16-day forecast, not NASA, labelled as such). Missing data is shown, never invented.

## Tests
`python -m pytest -q`

## Credits
Earth textures in `web/vendor/tex` come from the three.js examples (NASA Blue Marble based). three.js and Leaflet are MIT / BSD licensed; see the LICENSE files in `web/vendor`.

## v0.8: the supplied challenge datasets are part of the app

Files live in `src/fieldshift/data/` and are read by `datapack.py` (nothing is hardcoded from them).

| File | Used for |
|---|---|
| NASA POWER daily 2015-2025 | Offline weather for Diamond Valley fields when live NASA POWER fails (Tmax/Tmin estimated, flagged, grade C); cross-check against the live download |
| NASA POWER climatology 2001-2025 | Reference climate on the Data & Sources page; checks whether 2015-2025 is typical |
| SSURGO horizons / demo point | Choose a map unit as a field's soil (`soil = "ssurgo:<mukey>"`): sand, clay, pH, organic matter, water capacity, drainage |
| NASS CDL Eureka County | What is grown nearby; market score proxy for Diamond Valley fields (classes under ~50 acres ignored) |
| FAO EcoCrop | 10 extra crops in the simulator; temperature / rainfall / pH / texture / drainage suitability anywhere |
| NEX-GDDP-CMIP6 | Delta-change projections (3 scenarios x 4 periods) in the Climate Simulator |
| Farmer priorities template | Download, fill in, upload on My Fields; applied vs "not modelled" rows are listed |
| dataset_sources.xlsx | Source catalogue on the Data & Sources page |

Known limits, shown in the app: no file carries coordinates (demo field sits at the GNIS centre of Diamond Valley); the supplied POWER daily file has only mean temperature and 11 years; the NEX-GDDP solar column is labelled MJ/m2/day but holds W/m2 (converted x0.0864); projections and CDL/SSURGO apply only within 100 km of Diamond Valley; returns and prices are not modelled.

### Farmer-friendly additions
- Language picker in the top bar (Hindi, Bengali, Marathi, Tamil, Telugu, Gujarati, Kannada, Punjabi, English) translates the menu and the assistant's question buttons; "A+" makes text bigger.
- Assistant has a microphone button (speech recognition) and a Listen button (read aloud) in the chosen language. These use the browser's own speech features (Chrome/Edge work best; voices for some languages depend on the device).
- Replies in the farmer's language need the Gemini key. Without it, answers are built from templates and stay in English.
- Ask about any place by name ("can you check for Howrah?"): the app looks it up (Open-Meteo geocoding) and analyses that place with your field's crops and priorities.

### Hello Terra, location, any language
- A round Terra button floats on every screen. Tap it, or tick "Say Hello Terra" and just say it. It listens only while the app is open in a browser tab or an installed app window; a web page cannot listen once closed. For the closest thing to "always there", install the app (browser menu > Install TerraAdapt / Add to Home screen) and keep it open or set it to start with the computer or phone.
- "Use my current location" sends the device position with each question, so "what is the weather where I live" is answered for where the farmer is. It is on by default while the demo field is selected.
- Language menu lists ~70 languages. Languages without a built-in dictionary are translated screen by screen with the Gemini key (cached, marked with a globe). Without a key they stay in English.

### Set the Gemini key once (no need to paste it in the browser)
Create a file named `.env` in the project folder (next to README.md) containing one line: `GEMINI_API_KEY=your-key`, then restart the app. In Windows: `copy .env.example .env`, open `.env` in Notepad, paste the key, save. The key stays on your computer and is never sent to the browser. A key pasted in the app's Settings still works and takes priority.

### Terra voice
Terra answers with a short spoken version (two or three sentences), in the best natural voice the device has for the language, and keeps listening for a follow-up until you say "thanks" or "stop". If the browser's own speech recognition does not work (for example in Edge), Terra records a short clip and transcribes it with Gemini (needs the key). "Hello Terra" wake phrase needs Chrome and an open page.


## Season Challenge (game)
A NASA-style interactive: pick a crop and sowing month, then replay one hidden real past year of NASA POWER weather for your field, a week at a time. You have 6 irrigation doses of 25 mm. At harvest the year is revealed and your score is compared with Terra's autopilot (same 150 mm budget, same water-balance model as the Rotation Lab) and with rain-only farming. Endpoint: `POST /api/game/play` (the future is never sent to the browser until the season ends). The score is a teaching index, not a yield forecast.

## Farmer-first navigation (v1.4)
Main bars: Home, Rotation Lab, My Season, My Farm, Ask Terra. **My Season** puts the weather week, risks (traffic-light tiles), crop plan (a month calendar), what-if tests and the game in one swipeable window with big pictures, plain words and a "Read it to me" button. Profile, fields, data sources and the detailed expert pages (forecast, risks, planner, simulator, earth) are in the account menu in the top corner and remain fully available.

## AI without a key: local models (v1.7)
If no Gemini key is set, TerraAdapt looks for a model running on the same computer: Ollama (`http://127.0.0.1:11434`), LM Studio (`:1234`) or llama.cpp (`:8080`). Install Ollama, run `ollama pull qwen2.5:3b`, restart the app: answers, Terra and translation then work offline. Choose another with `LOCAL_LLM_URL` and `LOCAL_LLM_MODEL` in `.env`; `AI_PROVIDER=local` prefers the local model even when a Gemini key exists. Speech-to-text fallback still needs Gemini (or the browser's own microphone engine in Chrome or Edge).

## First-run journey (v1.7)

On first open, after the splash, TerraAdapt asks for your location, flies the globe down to your spot, asks you to name your field and pick a crop, then replays that crop's season on your spot's real NASA weather (harvest, weak harvest or loss) and recommends the best planting months and better crops. Works with no account (spot is `geo:LAT,LON`); the field is saved when you are signed in. Restart it any time from Home, "See a season happen".

## Languages and AI

Hindi, Bengali and German ship with built-in translations (`web/locales/*.json`), so screens, the Terra greeting and the game narration need no AI call. Other languages use AI translation. AI order: Gemini key first; if Gemini fails or there is no key, a local Ollama / LM Studio model is used automatically.

## Going live (cloud)

A `Dockerfile` and a `render.yaml` are included. Any host that runs a Docker image works.

1. Build and run: `docker build -t terraadapt .` then `docker run -p 8000:8000 -e GEMINI_API_KEY=your_key -v terra-data:/data terraadapt`.
2. Put the Gemini key only in the host's secret / environment settings (`GEMINI_API_KEY`). It is never stored in the database or the image. Without it the assistant still answers from the field's own numbers (template mode); with it, answers are AI-written and in the farmer's language. A farmer can also paste their own key in the gear menu (kept in their browser).
3. Mount a persistent disk at `/data` (accounts and saved fields live in `/data/fieldshift.db`). `FIELDSHIFT_COOKIE_SECURE=1` is already set for HTTPS.
4. The server needs outbound internet for NASA POWER, SoilGrids and Open-Meteo. The first visit to a new place downloads 21 years of daily weather (about 5 requests); the app starts this download while the farmer is still naming the field, and caches it in `cache/`.
5. "Save key on this computer" in Settings only works from localhost and is refused behind a proxy.

The Docker build itself was not run in the build environment (no internet there), so run it once and check `/api/health`.

## The game: farmer decisions (v1.8)

Besides irrigating, the farmer can **scout** the next 3 days (4 times), **cover** the crop on one night (2 times; it only helps on a night that really is too cold), and **mulch** the soil once (game rule: about 10% less crop water use). The server verifies every move, and a scouting report can never come from a day that has not happened yet. In the journey the farmer now chooses between farming the season or watching it.

If NASA POWER cannot be reached, the game uses a clearly labelled backup (ERA5 reanalysis via Open-Meteo) instead of failing, and says so on screen.

## Languages (v1.8 fixes)

The built-in Hindi/Bengali/German files were fetched from the wrong URL when the app is served under `/app`, so they never loaded; fixed. Built-in translations now also show when the AI step fails, month and crop names are translated inside sentences, and 190 more screens' strings were added (508 entries per language). Long server-written sentences that are not in the files still need a Gemini key or a local model.

## Deploy on Google Cloud Run

Run these on your own computer (needs the `gcloud` CLI and a project with billing):

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud services enable run.googleapis.com cloudbuild.googleapis.com secretmanager.googleapis.com
printf '%s' 'YOUR_GEMINI_KEY' | gcloud secrets create gemini-key --data-file=-
gcloud run deploy terraadapt --source . --region asia-south1 --allow-unauthenticated \
  --set-secrets GEMINI_API_KEY=gemini-key:latest \
  --set-env-vars FIELDSHIFT_COOKIE_SECURE=1,FIELDSHIFT_DB=/tmp/fieldshift.db \
  --min-instances 1 --memory 1Gi
```

The Gemini key lives in Secret Manager and is read from the environment; it is never written to the app database.
Cloud Run's disk is temporary: accounts and saved fields reset when an instance is replaced. For permanent
storage, mount a Cloud Storage volume at `/data` and set `FIELDSHIFT_DB=/data/fieldshift.db`
(`--add-volume name=d,type=cloud-storage,bucket=YOUR_BUCKET --add-volume-mount volume=d,mount-path=/data`).
Keep `--max-instances 1` if you use SQLite.

## Make weather open instantly

The first time a new place is used, its 20 years of NASA weather are downloaded (five pieces at once) and then kept in the `cache` folder, so every later visit opens at once. To download many places in advance, run once on a computer with internet: `python scripts/prefetch.py`. Then keep the `cache` folder with the app (the Docker image includes it).
