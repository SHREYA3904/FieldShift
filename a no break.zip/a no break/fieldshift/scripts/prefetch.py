"""Download the NASA POWER weather for many farming places ONCE, so the game and forecasts open instantly offline.
Run on a computer with internet, from the project folder:   python scripts/prefetch.py
It is safe to stop and run again: places already downloaded are skipped. Add your own lines to PLACES (name, latitude, longitude)."""
import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from concurrent.futures import ThreadPoolExecutor
from fieldshift import ingest

PLACES = [("Howrah", 22.59, 88.31), ("Kolkata", 22.57, 88.36), ("Delhi", 28.61, 77.21), ("Mumbai", 19.08, 72.88), ("Pune", 18.52, 73.86), ("Nagpur", 21.15, 79.09),
 ("Hyderabad", 17.39, 78.49), ("Bengaluru", 12.97, 77.59), ("Chennai", 13.08, 80.27), ("Lucknow", 26.85, 80.95), ("Patna", 25.59, 85.14), ("Bhopal", 23.26, 77.41),
 ("Jaipur", 26.91, 75.79), ("Ludhiana", 30.90, 75.86), ("Ahmedabad", 23.02, 72.57), ("Indore", 22.72, 75.86), ("Guwahati", 26.14, 91.74), ("Bhubaneswar", 20.30, 85.82),
 ("Raipur", 21.25, 81.63), ("Varanasi", 25.32, 82.97), ("Dhaka", 23.81, 90.41), ("Rajshahi", 24.37, 88.60), ("Kathmandu", 27.72, 85.32), ("Lahore", 31.55, 74.34),
 ("Karachi", 24.86, 67.01), ("Colombo", 6.93, 79.86), ("Bangkok", 13.76, 100.50), ("Hanoi", 21.03, 105.85), ("Jakarta", -6.21, 106.85), ("Manila", 14.60, 120.98),
 ("Beijing", 39.90, 116.40), ("Nairobi", -1.29, 36.82), ("Lagos", 6.52, 3.38), ("Kano", 12.00, 8.52), ("Addis Ababa", 9.03, 38.74), ("Cairo", 30.04, 31.24),
 ("Johannesburg", -26.20, 28.05), ("Accra", 5.60, -0.19), ("Dar es Salaam", -6.79, 39.28), ("Kampala", 0.35, 32.58), ("Sao Paulo", -23.55, -46.63), ("Brasilia", -15.79, -47.88),
 ("Buenos Aires", -34.60, -58.38), ("Mexico City", 19.43, -99.13), ("Lima", -12.05, -77.04), ("Bogota", 4.71, -74.07), ("Des Moines", 41.59, -93.62), ("Fresno", 36.74, -119.79),
 ("Lincoln", 40.81, -96.70), ("Saskatoon", 52.13, -106.67), ("Berlin", 52.52, 13.40), ("Paris", 48.86, 2.35), ("Kyiv", 50.45, 30.52), ("Madrid", 40.42, -3.70),
 ("Istanbul", 41.01, 28.98), ("Tashkent", 41.30, 69.24), ("Perth", -31.95, 115.86), ("Sydney", -33.87, 151.21)]

def get(p):
    name, lat, lon = p
    for attempt in (1, 2, 3):
        try:
            ingest.power_daily(lat, lon); return name, True, ""
        except Exception as e:
            time.sleep(2 * attempt); err = str(e)[:80]
    return name, False, err

if __name__ == "__main__":
    ok = 0
    for i, p in enumerate(PLACES, 1):          # one place at a time (each place already downloads 5 pieces at once), kind to NASA's servers
        n, good, err = get(p); ok += good
        print(f"{i:>2}/{len(PLACES)} {n:<14} {'done' if good else 'FAILED ' + err}", flush=True)
    print(f"\n{ok} of {len(PLACES)} places are now stored in the cache folder and open instantly.")
