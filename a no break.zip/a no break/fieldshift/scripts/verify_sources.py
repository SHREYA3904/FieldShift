"""Step 0. Calls every external source once and prints the response shape. Run this first, on a PC with internet:
    python scripts/verify_sources.py
Send the output back if anything fails."""
import json, sys
sys.path.insert(0, "src")
import requests
from fieldshift import ingest

LAT, LON = 30.9, 75.85
tests = {
 "NASA POWER daily": lambda: {k: (v.shape, str(v[:2])) for k, v in ingest.power_daily(LAT, LON, 2023, 2023).items()},
 "SoilGrids": lambda: ingest.soilgrids(LAT, LON),
 "Open-Meteo elevation": lambda: ingest.elevation(LAT, LON),
 "MODIS NDVI (ORNL DAAC)": lambda: list(requests.get("https://modis.ornl.gov/rst/api/v1/MOD13Q1/subset", params={
     "latitude": LAT, "longitude": LON, "band": "250m_16_days_NDVI", "startDate": "A2023001", "endDate": "A2023100",
     "kmAboveBelow": 0, "kmLeftRight": 0}, headers={"Accept": "application/json"}, timeout=60).json().keys()),
 "Open-Meteo seasonal": lambda: list(requests.get("https://seasonal-api.open-meteo.com/v1/seasonal", params={
     "latitude": LAT, "longitude": LON, "daily": "temperature_2m_mean"}, timeout=30).json().keys()),
 "NOAA ONI": lambda: requests.get("https://psl.noaa.gov/data/correlation/oni.data", timeout=30).text[:120],
}
for name, fn in tests.items():
    r = ingest.result(name, fn)
    print(("OK   " if r["ok"] else "FAIL ") + name, "->", json.dumps(r["data"], default=str)[:300] if r["ok"] else r["error"])
