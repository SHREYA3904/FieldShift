"""Run:  python scripts/check.py   -- tells you in plain words what works on this computer and what does not."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import requests
from fieldshift import ai

def row(ok, name, detail=""):
    print(("OK    " if ok else "FAIL  ") + name + ("  -  " + detail if detail else ""))

k = ai.env_key()
row(bool(k), "AI key or local model found", ("using " + ai.provider(k)["name"] + " " + ai.provider(k)["model"]) if k else ai.local_problem() + " Or no GEMINI_API_KEY seen. Put a file named .env in the project folder with one line: GEMINI_API_KEY=your_key")
if k:
    try:
        ai.generate("Answer with one word.", [{"role": "user", "content": "Say ok"}], k, None, 25, 20); row(True, "AI answers")
    except Exception as e:
        row(False, "AI answers", str(e)[:200])
for name, url in (("NASA POWER", "https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M&community=AG&longitude=88.3&latitude=22.6&start=20240101&end=20240102&format=JSON"),
                  ("Open-Meteo backup", "https://archive-api.open-meteo.com/v1/archive?latitude=22.6&longitude=88.3&start_date=2024-01-01&end_date=2024-01-02&daily=temperature_2m_max"),
                  ("Place search", "https://nominatim.openstreetmap.org/search?format=json&q=Howrah")):
    try:
        r = requests.get(url, timeout=25, headers={"User-Agent": "terraadapt-check"}); row(r.ok, name, "" if r.ok else f"HTTP {r.status_code}")
    except Exception as e:
        row(False, name, str(e)[:160])
