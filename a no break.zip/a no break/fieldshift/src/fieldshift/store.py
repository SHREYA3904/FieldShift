"""Tiny SQLite store for farms and fields (stdlib only). Boundaries are kept as GeoJSON text."""
from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone

DB = os.environ.get("FIELDSHIFT_DB", "fieldshift.db")
DEMO_ID = "demo-field"

DEMO = {
    "id": DEMO_ID, "farm": "Demonstration farm (Diamond Valley, Nevada)", "name": "Diamond Valley alfalfa-region field",
    "lat": 39.7591, "lon": -115.9734, "area_ha": 40, "soil": "ssurgo:demo", "irrigation_mm": 250, "water_availability": "medium",
    "current": ["barley", "cover_legume"], "history": ["barley then fallow", "barley then cover crop"],
    "priorities": {"water": 5, "nfix": 3, "erosion": 3, "om": 4, "forage": 3, "market": 3, "stability": 2},
    "constraints": {"max_irrigation_mm": 450, "market_crops": ["alfalfa", "barley", "wheat"]},
    "soil_test": {},
    "boundary": {"type": "Polygon", "coordinates": [[[-115.978, 39.755], [-115.968, 39.755], [-115.968, 39.763], [-115.978, 39.763], [-115.978, 39.755]]]},
    "note": "Illustrative field placed at the centre of the Diamond Valley basin (USGS GNIS). The supplied files carry no coordinates, so the exact spot is approximate. Soil is the supplied SSURGO demo point.",
}


def _c():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS fields (id TEXT PRIMARY KEY, data TEXT NOT NULL, created_at TEXT, updated_at TEXT, user_id TEXT)")
    if "user_id" not in [r["name"] for r in c.execute("PRAGMA table_info(fields)")]:
        c.execute("ALTER TABLE fields ADD COLUMN user_id TEXT")
    c.execute("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT UNIQUE, phone TEXT UNIQUE, name TEXT, profile TEXT, created_at TEXT, pw TEXT)")
    if "pw" not in [r["name"] for r in c.execute("PRAGMA table_info(users)")]:
        c.execute("ALTER TABLE users ADD COLUMN pw TEXT")
    c.execute("CREATE TABLE IF NOT EXISTS otps (id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT, salt TEXT, code_hash TEXT, expires REAL, attempts INTEGER DEFAULT 0, used INTEGER DEFAULT 0, created REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT, expires REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, field_id TEXT, kind TEXT, content TEXT, created_at TEXT)")
    return c


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _seed(c):
    r = c.execute("SELECT data FROM fields WHERE id=?", (DEMO_ID,)).fetchone()
    if not r:
        c.execute("INSERT INTO fields VALUES (?,?,?,?,?)", (DEMO_ID, json.dumps(DEMO), _now(), _now(), None))
        c.commit()
    elif json.loads(r["data"]) != DEMO:                    # the shared demo field always matches the shipped version
        c.execute("UPDATE fields SET data=?, updated_at=? WHERE id=?", (json.dumps(DEMO), _now(), DEMO_ID))
        c.commit()


def list_fields(user_id=None):
    """The shared demo field plus the user's own fields."""
    with _c() as c:
        _seed(c)
        rows = c.execute("SELECT data FROM fields WHERE id=? OR (user_id IS NOT NULL AND user_id=?) ORDER BY (id=?) DESC, created_at", (DEMO_ID, user_id or "", DEMO_ID))
        return [json.loads(r["data"]) for r in rows]


def all_places():
    """Every saved field's (lat, lon), newest first: used to download their weather in the background when the server starts."""
    with _c() as c:
        _seed(c)
        out = []
        for r in c.execute("SELECT data FROM fields ORDER BY created_at DESC LIMIT 200"):
            try:
                d = json.loads(r["data"]); out.append((float(d["lat"]), float(d["lon"])))
            except (KeyError, TypeError, ValueError):
                continue
        return out


def get_field(fid, user_id=None):
    with _c() as c:
        _seed(c)
        r = c.execute("SELECT data, user_id FROM fields WHERE id=?", (fid,)).fetchone()
        if not r or (fid != DEMO_ID and (not user_id or r["user_id"] != user_id)):
            return None
        return json.loads(r["data"])


def save_field(data: dict, fid: str | None = None, user_id=None):
    if not user_id:
        raise PermissionError("sign in to save fields")
    fid = fid or data.get("id") or str(uuid.uuid4())
    data = {**data, "id": fid}
    with _c() as c:
        _seed(c)
        row = c.execute("SELECT user_id FROM fields WHERE id=?", (fid,)).fetchone()
        if row and row["user_id"] != user_id:                 # includes the demo field: saving makes a copy
            fid = str(uuid.uuid4())
            data["id"] = fid
            row = None
        if row:
            c.execute("UPDATE fields SET data=?, updated_at=? WHERE id=?", (json.dumps(data), _now(), fid))
        else:
            c.execute("INSERT INTO fields VALUES (?,?,?,?,?)", (fid, json.dumps(data), _now(), _now(), user_id))
        c.commit()
    return data


def delete_field(fid, user_id=None):
    if fid == DEMO_ID or not user_id:
        return False
    with _c() as c:
        n = c.execute("DELETE FROM fields WHERE id=? AND user_id=?", (fid, user_id)).rowcount
        c.execute("DELETE FROM memory WHERE field_id=? AND user_id=?", (fid, user_id))
        c.commit()
        return n > 0


# ---- users and memory ----
def _user(r):
    if not r:
        return None
    return {"id": r["id"], "email": r["email"], "phone": r["phone"], "name": r["name"] or "", "profile": json.loads(r["profile"] or "{}"), "created_at": r["created_at"]}


def find_user(email=None, phone=None):
    with _c() as c:
        r = c.execute("SELECT * FROM users WHERE (email IS NOT NULL AND email=?) OR (phone IS NOT NULL AND phone=?)", (email, phone)).fetchone()
        return _user(r)


def get_user(uid):
    with _c() as c:
        return _user(c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())


def get_pw(email):
    with _c() as c:
        r = c.execute("SELECT pw FROM users WHERE email=?", (email,)).fetchone()
        return r["pw"] if r else None


def set_pw(email, pw):
    with _c() as c:
        n = c.execute("UPDATE users SET pw=? WHERE email=?", (pw, email)).rowcount
        c.commit()
        return n > 0


def create_user(email=None, phone=None, name="", pw=None):
    uid = str(uuid.uuid4())
    with _c() as c:
        c.execute("INSERT INTO users (id, email, phone, name, profile, created_at, pw) VALUES (?,?,?,?,?,?,?)", (uid, email, phone, name, "{}", _now(), pw))
        c.commit()
    return get_user(uid)


def update_user(uid, name=None, profile=None, email=None, phone=None):
    u = get_user(uid)
    with _c() as c:
        c.execute("UPDATE users SET name=?, profile=?, email=COALESCE(?,email), phone=COALESCE(?,phone) WHERE id=?",
                  (u["name"] if name is None else name, json.dumps(u["profile"] if profile is None else profile), email, phone, uid))
        c.commit()
    return get_user(uid)


def add_memory(uid, kind, content, field_id=None):
    with _c() as c:
        c.execute("INSERT INTO memory (user_id, field_id, kind, content, created_at) VALUES (?,?,?,?,?)", (uid, field_id, kind, json.dumps(content), _now()))
        c.commit()


def list_memory(uid, kind=None, field_id=None, limit=50):
    q, a = "SELECT * FROM memory WHERE user_id=?", [uid]
    if kind:
        q += " AND kind=?"; a.append(kind)
    if field_id:
        q += " AND field_id=?"; a.append(field_id)
    q += " ORDER BY id DESC LIMIT ?"; a.append(limit)
    with _c() as c:
        return [{"id": r["id"], "field_id": r["field_id"], "kind": r["kind"], "content": json.loads(r["content"]), "created_at": r["created_at"]} for r in reversed(c.execute(q, a).fetchall())]


def clear_memory(uid, kind=None, field_id=None):
    q, a = "DELETE FROM memory WHERE user_id=?", [uid]
    if kind:
        q += " AND kind=?"; a.append(kind)
    if field_id:
        q += " AND field_id=?"; a.append(field_id)
    with _c() as c:
        c.execute(q, a); c.commit()


def tr_get(lang: str, texts: list[str]) -> dict:
    with _c() as c:
        c.execute("CREATE TABLE IF NOT EXISTS translations (lang TEXT, src TEXT, out TEXT, PRIMARY KEY (lang, src))")
        res = {}
        for t in texts:
            r = c.execute("SELECT out FROM translations WHERE lang=? AND src=?", (lang, t)).fetchone()
            if r:
                res[t] = r["out"]
        return res


def tr_put(lang: str, pairs: dict) -> None:
    with _c() as c:
        c.execute("CREATE TABLE IF NOT EXISTS translations (lang TEXT, src TEXT, out TEXT, PRIMARY KEY (lang, src))")
        c.executemany("INSERT OR REPLACE INTO translations VALUES (?,?,?)", [(lang, k, v) for k, v in pairs.items()])
        c.commit()
