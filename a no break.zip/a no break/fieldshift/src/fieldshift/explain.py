"""Layer 6: turn numbers into structured, explainable records (why, evidence, benefits, gaps, risks)."""
from __future__ import annotations

import numpy as np

from .climate import Climate
from .engine import Engine

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _crop_block(c, f, start: int) -> dict:
    return {
        "id": c.id, "name": c.name, "sow_month": MONTHS[start],
        "months": [MONTHS[m] for m in f["idx"][start]],
        "rain_in_season_mm": round(float(f["rain"][start]), 1),
        "typical_need_mm": round(float(c.need), 1),
        "monthly_temp_range_c": [round(float(f["t"][start].min()), 1), round(float(f["t"][start].max()), 1)],
        "comfortable_range_c": [c.tlo, c.thi],
        "temperature_fit": round(float(f["tf"][start]), 3),
        "water_fit": round(float(f["wf"][start]), 3),
        "hot_months": int(f["hot"][start]),
        "cold_risk": bool(f["cold"][start]),
        "data_confidence": c.confidence,
        "sources": list(c.sources),
    }


def build(engine: Engine, res: dict, climate: Climate, anom=None) -> list[dict]:
    c = res["central"]; mc = res["mc"]; cur = res["cur_k"]
    records = []
    for label, why, k in engine.pick_strategies(res):
        i, j = engine.pairs[k]
        ci, cj = engine.crops[i], engine.crops[j]
        a, b = (int(x) for x in c["ab"][k])
        A = _crop_block(ci, c["fits"][i], a)
        B = _crop_block(cj, c["fits"][j], b)
        used = set(c["fits"][i]["idx"][a]) | set(c["fits"][j]["idx"][b])
        cal = ["A" if m in set(c["fits"][i]["idx"][a]) else "B" if m in set(c["fits"][j]["idx"][b]) else "bare"
               for m in range(12)]
        bare = [m for m in range(12) if m not in used]
        need = ci.need + cj.need
        irr = float(c["irr_need"][k])
        rain_cover = max(0.0, 1 - irr / need)

        evidence = []
        for blk in (A, B):
            evidence.append(
                f"{blk['name']}, sow {blk['sow_month']}: rain in season about {blk['rain_in_season_mm']:.0f} mm "
                f"against a typical need of {blk['typical_need_mm']:.0f} mm; monthly temperature "
                f"{blk['monthly_temp_range_c'][0]:.0f} to {blk['monthly_temp_range_c'][1]:.0f} C "
                f"(comfortable {blk['comfortable_range_c'][0]:.0f} to {blk['comfortable_range_c'][1]:.0f} C).")
        stress = {}
        if anom is not None:
            for blk, nm in ((A, ci.name), (B, cj.name)):
                ms = [MONTHS.index(m) for m in blk["months"]]
                blk["dry_year_share"] = round(anom.season_share(ms, "dry"), 2)
                blk["hot_year_share"] = round(anom.season_share(ms, "hot"), 2)
                blk["cold_year_share"] = round(anom.season_share(ms, "cold"), 2)
                evidence.append(f"Across the last {len(anom.years)} years, at least one month of the {nm} season was unusually dry in "
                                f"{blk['dry_year_share']*100:.0f}% of years and unusually hot in {blk['hot_year_share']*100:.0f}%.")
        if climate.soil_wet is not None:
            for blk, cc in ((A, ci), (B, cj)):
                ms = [MONTHS.index(m) for m in blk["months"]]
                evidence.append(f"Root-zone soil wetness during the {blk['name']} season averages "
                                f"{float(np.mean(climate.soil_wet[ms])):.2f} (0 dry, 1 wet; modelled, not a direct SMAP reading).")
        if res["scenario"].rain_pct or res["scenario"].temp_c:
            evidence.append(f"Scenario applied: rainfall {res['scenario'].rain_pct:+.0f}%, warming {res['scenario'].temp_c:+.1f} C.")

        benefits = []
        if ci.nfix >= 4 or cj.nfix >= 4:
            benefits.append("Includes a nitrogen-fixing crop, which can reduce fertiliser needs.")
        if ci.family != cj.family:
            benefits.append("Two different crop families can interrupt pest and disease cycles (confirm locally).")
        if ci.erosion + cj.erosion >= 6:
            benefits.append("Good ground cover helps reduce erosion.")
        if ci.om + cj.om >= 6:
            benefits.append("Adds organic matter.")
        if max(ci.forage, cj.forage) >= 4:
            benefits.append("Can supply fodder.")
        if rain_cover >= 0.7:
            benefits.append("Rain covers most of the water need.")
        if cur is not None and k != cur:
            d = float(c["irr_need"][cur]) - irr
            if abs(d) >= 30:
                benefits.append(f"Needs about {abs(d):.0f} mm {'less' if d > 0 else 'more'} irrigation per year than your current rotation.")
        if not benefits:
            benefits.append("No clear advantage in the factors this tool covers.")

        gaps = ["Crop water needs are typical values, not measurements for the field.",
                "Climate data is gridded (about 50 km), so it can miss local differences.",
                "Soil tests, pest history, equipment and market prices are not included."]
        if climate.source != "nasa_power":
            gaps.insert(0, f"Climate source is '{climate.source}', not real NASA observations.")
        for cc in (ci, cj):
            if cc.confidence == "estimate":
                gaps.append(f"Temperature limits for {cc.name} are estimates: check with local extension advice.")

        risks = []
        for blk in (A, B):
            if blk["hot_months"]:
                risks.append(f"{blk['hot_months']} month(s) of the {blk['name']} season run hotter than comfortable: heat stress risk.")
            if blk["cold_risk"]:
                risks.append(f"Some months are colder than the minimum for {blk['name']}: frost or cold damage risk.")
            if blk["water_fit"] < 0.7:
                risks.append(f"Rain plus available irrigation may not meet the water need of {blk['name']}.")
        for blk in (A, B):
            if blk.get("dry_year_share", 0) >= 0.25:
                risks.append(f"In about {blk['dry_year_share']*100:.0f}% of past years the {blk['name']} season had an unusually dry month: drought exposure.")
            if blk.get("hot_year_share", 0) >= 0.25:
                risks.append(f"In about {blk['hot_year_share']*100:.0f}% of past years the {blk['name']} season had an unusually hot month.")
        if ci.family == cj.family:
            risks.append("Both crops are in the same family, so pest and disease carry-over is more likely.")
        wet_bare = [MONTHS[m] for m in bare if climate.rain[m] > 100]
        if wet_bare:
            risks.append(f"Fields are bare in {', '.join(wet_bare)} when rain is heavy: erosion risk. A cover crop could help.")
        risks.append("A farmer or local agriculture adviser should review this before any change.")

        records.append({
            "label": label, "why": why,
            "crops": [A, B],
            "calendar": cal, "bare_months": [MONTHS[m] for m in bare],
            "scores": {
                "overall": round(float(c["total"][k]), 3),
                "climate_fit": round(float(c["fit"][k]), 3),
                "priority_match": round(float((c["pri"][i] + c["pri"][j]) / 2), 3),
                "irrigation_need_mm_per_year": round(irr, 0),
                "rain_covers_pct": round(rain_cover * 100, 0),
            },
            "uncertainty": {
                "overall_p10": round(float(mc["p10"][k]), 3), "overall_p90": round(float(mc["p90"][k]), 3),
                "p_in_top3": round(float(mc["p_top3"][k]), 2),
                "p_beats_current": None if mc["p_beats_current"] is None else round(float(mc["p_beats_current"][k]), 2),
                "draws": res["n_mc"],
                "method": "Monte Carlo over interannual climate spread, crop temperature and water-need uncertainty, and uncertainty in the 0-5 judgement scores",
            },
            "evidence": evidence, "benefits": benefits, "information_gaps": gaps, "risks_for_local_review": risks,
        })
    return records
