"""Email + password accounts. Passwords are stored only as salted scrypt hashes. Sessions are random tokens kept as
SHA-256 hashes, delivered in an httpOnly cookie. There is no email sending, so there is no automatic password reset:
use `python -m fieldshift.reset_password you@example.com` on the server to set a new one."""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import time

from . import store

SESSION_DAYS, MAX_FAILS, LOCK_S = 30, 5, 900
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
COMMON = {"password", "12345678", "123456789", "qwertyui", "password1", "11111111", "abcd1234", "iloveyou"}
_FAILS: dict[str, list[float]] = {}


class AuthError(Exception):
    def __init__(self, msg, status=400):
        super().__init__(msg)
        self.status = status


def normalise_email(e: str) -> str:
    e = (e or "").strip().lower()
    if not EMAIL_RE.match(e) or len(e) > 254:
        raise AuthError("Enter a valid email address.")
    return e


def hash_pw(pw: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return f"scrypt${salt.hex()}${h.hex()}"


def check_pw(pw: str, stored: str | None) -> bool:
    if not stored:
        hash_pw(pw)                                     # keep timing similar when the account does not exist
        return False
    try:
        _, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, bytes.fromhex(salt)).split("$")[2], h)
    except ValueError:
        return False


def _session(user):
    token = secrets.token_urlsafe(32)
    with store._c() as c:
        c.execute("INSERT INTO sessions VALUES (?,?,?)", (hashlib.sha256(token.encode()).hexdigest(), user["id"], time.time() + SESSION_DAYS * 86400))
        c.commit()
    return token


def signup(email: str, password: str, name: str = ""):
    email = normalise_email(email)
    if len(password or "") < 8 or len(password) > 128:
        raise AuthError("Use a password of 8 to 128 characters.")
    if password.lower() in COMMON:
        raise AuthError("That password is too common. Choose another.")
    if store.find_user(email):
        raise AuthError("An account with this email already exists. Sign in instead.", 409)
    user = store.create_user(email, None, (name or "").strip()[:80], hash_pw(password))
    return user, _session(user)


def login(email: str, password: str):
    email = normalise_email(email)
    now = time.time()
    fails = [t for t in _FAILS.get(email, []) if now - t < LOCK_S]
    if len(fails) >= MAX_FAILS:
        raise AuthError(f"Too many wrong attempts. Try again in {int((LOCK_S - (now - fails[0])) / 60) + 1} minutes.", 429)
    if not check_pw(password or "", store.get_pw(email)):
        _FAILS[email] = fails + [now]
        raise AuthError("Email or password is not right.", 401)
    _FAILS.pop(email, None)
    user = store.find_user(email)
    return user, _session(user)


def user_for_token(token: str | None):
    if not token:
        return None
    with store._c() as c:
        r = c.execute("SELECT user_id, expires FROM sessions WHERE token_hash=?", (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
    if not r or r["expires"] < time.time():
        return None
    return store.get_user(r["user_id"])


def logout(token: str | None):
    if token:
        with store._c() as c:
            c.execute("DELETE FROM sessions WHERE token_hash=?", (hashlib.sha256(token.encode()).hexdigest(),))
            c.commit()
