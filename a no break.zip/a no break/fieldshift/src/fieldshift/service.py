"""One entry point used by the API and the CLI."""
from __future__ import annotations

from .climate import Climate, fetch_power, synthetic
from .crops import load_crops
from .engine import Engine, Scenario
from . import ml
from .explain import build

_ENGINE = Engine(load_crops())


def get_climate(lat: float, lon: float, offline: bool = False, cache_dir: str = "cache") -> Climate:
    if offline:
        c = synthetic(lat)
        c.lon = lon
        return c
    try:
        return fetch_power(lat, lon, cache_dir=cache_dir)
    except Exception as e:                      # network blocked, API down, bad response
        c = synthetic(lat)
        c.lon = lon
        c.notes.append(f"NASA POWER unavailable ({type(e).__name__}); using a synthetic climate instead.")
        return c


def analyse_legacy(lat: float, lon: float, soil: str = "loam", irrigation_mm: float = 0.0,
            current: tuple[str, str] | None = None, priorities: dict | None = None,
            rain_pct: float = 0.0, temp_c: float = 0.0, n_mc: int = 300, seed: int = 0,
            offline: bool = False, cache_dir: str = "cache", climate: Climate | None = None) -> dict:
    climate = climate or get_climate(lat, lon, offline, cache_dir)
    anom = ml.analyse(climate)
    res = _ENGINE.run(climate, priorities, Scenario(rain_pct, temp_c), soil, irrigation_mm, current, n_mc, seed)
    return {
        "location": {"lat": lat, "lon": lon},
        "climate": {
            "source": climate.source, "notes": climate.notes, "years_of_data": climate.years,
            "monthly_temp_c": [round(float(x), 2) for x in climate.temp],
            "monthly_rain_mm": [round(float(x), 1) for x in climate.rain],
            "annual_rain_mm": round(climate.annual_rain(), 0),
            "rain_trend_mm_per_year": round(climate.rain_trend, 2),
            "warming_trend_c_per_decade": round(climate.temp_trend * 10, 3),
            "anomalies": None if anom is None else anom.to_json(),
            "soil_wetness_by_month": None if climate.soil_wet is None else [round(float(x), 3) for x in climate.soil_wet],
        },
        "strategies": build(_ENGINE, res, climate, anom),
        "disclaimer": "Decision support only. Compares options against each other; does not predict yield or profit. "
                      "Review with a farmer or local agricultural adviser.",
    }


def crop_list() -> list[dict]:
    from . import simulate
    return [{"id": c.id, "name": c.name, "family": c.family, "confidence": c.confidence,
             "sources": list(c.sources)} for c in simulate.load_params().values()]


def analyse(lat, lon, soil="auto", irrigation_mm=0.0, current=None, priorities=None, rain_pct=0.0, temp_c=0.0,
            n_mc=300, seed=0, offline=False, cache_dir="cache", climate=None, soil_test=None, constraints=None, projection=None):
    """Live daily-data pipeline. Falls back to the labelled monthly/sample path only when live data cannot be fetched."""
    from . import pipeline
    if not offline and climate is None:
        try:
            return pipeline.analyse(lat, lon, soil, irrigation_mm, current, priorities, rain_pct, temp_c, seed=seed, soil_test=soil_test, constraints=constraints, projection=projection)
        except RuntimeError as e:                      # data source down: say so, use the labelled fallback
            out = analyse_legacy(lat, lon, "loam" if (soil == "auto" or str(soil).startswith("ssurgo:")) else soil, irrigation_mm, current, priorities,
                                 rain_pct, temp_c, n_mc, seed, False, cache_dir, climate)
            out["climate"]["notes"] = [f"Live daily data failed ({e}). Showing the simpler monthly method."] + list(out["climate"]["notes"])
            out["evidence_grade"] = {"grade": "C", "reasons": ["Live data unavailable."]}
            return out
    out = analyse_legacy(lat, lon, "loam" if (soil == "auto" or str(soil).startswith("ssurgo:")) else soil, irrigation_mm, current, priorities,
                         rain_pct, temp_c, n_mc, seed, offline, cache_dir, climate)
    out["evidence_grade"] = {"grade": "C", "reasons": ["Sample or monthly data only."]}
    return out
