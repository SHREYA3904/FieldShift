"""Set a new password for an account: python -m fieldshift.reset_password you@example.com [new-password]"""
import getpass
import sys

from . import auth, store

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: python -m fieldshift.reset_password email [new-password]")
    email = auth.normalise_email(sys.argv[1])
    pw = sys.argv[2] if len(sys.argv) > 2 else getpass.getpass("New password: ")
    if len(pw) < 8:
        sys.exit("Use at least 8 characters.")
    print("Password updated." if store.set_pw(email, auth.hash_pw(pw)) else "No account with that email.")
