// "My Season": weather, risks, plan, what-if and the game in one swipeable window, in plain words and pictures (no charts).
import { el, MONTHS, toast } from "../ui.js";
import { api } from "../api.js";
import { cropNames } from "./common.js";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const pretty = (id) => id.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
const iconFor = (id) => (/drought|dry|water/.test(id) ? "💧" : /heat|hot/.test(id) ? "🔥" : /frost|cold/.test(id) ? "❄️" : /flood|rain|wet/.test(id) ? "🌧️" : /erosion|bare/.test(id) ? "🏜️" : /soil|organic|nitrogen/.test(id) ? "🌱" : /satellite|ndvi|green/.test(id) ? "🛰️" : "⚠️");
function skyOf(d) {
  const r = d.rain_mm || 0, hi = d.tmax, lo = d.tmin;
  if (r >= 20) return ["🌧️", "Heavy rain", "crit"]; if (r >= 5) return ["🌦️", "Rain", "info"]; if (lo != null && lo <= 0) return ["❄️", "Frost", "crit"];
  if (hi != null && hi >= 38) return ["🔥", "Very hot", "crit"]; if (hi != null && hi >= 33) return ["☀️", "Hot", "warn"]; if (lo != null && lo <= 5) return ["🥶", "Cold night", "warn"];
  return ["🌤️", "Pleasant", "good"];
}
const bigBtn = (text, fn, cls = "") => el("button", { type: "button", class: "sbtn " + cls, text, onclick: fn });

export async function render(app) {
  const f = app.field(), root = el("div", { class: "page season" });
  const tabs = [["🎮", "Play", playSlide], ["☀️", "This week", weekSlide], ["⚠️", "Risks", riskSlide], ["🗓️", "My plan", planSlide], ["❓", "What if?", whatIfSlide]];
  let cur = 0; const done = [];
  const bar = el("div", { class: "stabs", role: "tablist" }), view = el("div", { class: "sview" }), dots = el("div", { class: "sdots" });
  const say = () => { try { const t = view.innerText.replace(/\s+/g, " ").slice(0, 700); const u = new SpeechSynthesisUtterance(t); u.lang = app.lang() === "auto" ? navigator.language : app.lang(); speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { toast("Your phone or browser cannot read aloud."); } };
  const nav = el("div", { class: "snav" }, [bigBtn("◀ Back", () => go(cur - 1), "ghost"), bigBtn("🔊 Read it to me", say, "ghost"), bigBtn("Next ▶", () => go(cur + 1), "solid")]);
  tabs.forEach(([ic, label], i) => bar.append(el("button", { type: "button", role: "tab", class: "stab", onclick: () => go(i) }, [el("span", { class: "sic", text: ic }), el("span", { text: label })])));
  tabs.forEach(() => dots.append(el("i")));
  root.append(el("div", { class: "page-head" }, [el("div", {}, [el("h2", { text: "My Season" }), el("p", { class: "sub", text: `${f.name}. Swipe, or tap a picture.` })])]), bar, view, nav, dots);

  async function go(i) {
    if (i < 0 || i >= tabs.length) return; cur = i;
    [...bar.children].forEach((b, k) => { b.setAttribute("aria-selected", k === i); b.classList.toggle("on", k === i); }); [...dots.children].forEach((d, k) => d.classList.toggle("on", k === i));
    view.classList.remove("in"); void view.offsetWidth; view.classList.add("in");
    view.replaceChildren(el("p", { class: "hint", text: "One moment…" }));
    try { if (!done[i]) done[i] = await tabs[i][2](); view.replaceChildren(done[i]); } catch (e) { view.replaceChildren(el("div", { class: "callout crit", text: e.message || "Something went wrong. Try again." })); done[i] = null; }
    bar.children[i].scrollIntoView({ block: "nearest", inline: "center" });
  }
  let x0 = null; view.addEventListener("touchstart", (e) => (x0 = e.touches[0].clientX), { passive: true });
  view.addEventListener("touchend", (e) => { if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 70) go(cur + (dx < 0 ? 1 : -1)); });
  root.tabIndex = 0; root.addEventListener("keydown", (e) => { if (e.target.closest("input,select,textarea")) return; if (e.key === "ArrowRight") go(cur + 1); if (e.key === "ArrowLeft") go(cur - 1); });

  // 1. This week
  async function weekSlide() {
    const o = await api.forecast(f.id), top = o.actions.find((a) => a.severity !== "info"), days = o.days.slice(0, 7);
    return el("div", { class: "slide" }, [
      el("div", { class: "shero " + (top ? (top.severity === "crit" ? "crit" : "warn") : "good") }, [el("span", { class: "hface", text: top ? (top.severity === "crit" ? "😟" : "😐") : "😊" }), el("div", {}, [el("h3", { text: top ? top.title : "All calm. Nothing unusual is coming." }), el("p", { text: top ? top.evidence : "The next 16 days look normal for your field." })])]),
      el("h4", { text: "Your next 7 days" }), el("div", { class: "days" }, days.map((d) => { const [ic, w, k] = skyOf(d), dt = new Date(d.date + "T12:00:00"); return el("div", { class: "day " + k }, [el("small", { text: DAYS[dt.getDay()] }), el("span", { class: "dic", text: ic }), el("b", { text: w }), el("small", { text: d.tmax != null ? Math.round(d.tmax) + "°" : "" })]); })),
      ...o.actions.filter((a) => a !== top).slice(0, 3).map((a) => el("div", { class: "tip " + a.severity }, [el("b", { text: a.title }), el("p", { text: a.evidence })])),
      el("p", { class: "hint", text: `Forecast from ${o.source}. Weather can change; check again tomorrow.` })]);
  }
  // 2. Risks
  async function riskSlide() {
    const a = await app.analyse(), v = a.vulnerability, face = { low: "😊", moderate: "😐", high: "😟" }[v.category] || "😐", word = { low: "Low", moderate: "Medium", high: "High" }[v.category] || v.category;
    const tiles = v.indicators.slice().sort((x, y) => y.score - x.score).map((i) => { const k = i.score < 33 ? "good" : i.score < 66 ? "warn" : "crit", w = i.score < 33 ? "Safe" : i.score < 66 ? "Watch" : "Danger"; const t = el("button", { type: "button", class: "rtile " + k, onclick: () => t.classList.toggle("open") }, [el("span", { class: "ric", text: iconFor(i.id) }), el("b", { text: pretty(i.id) }), el("em", { text: w }), el("p", { text: i.evidence })]); return t; });
    return el("div", { class: "slide" }, [el("div", { class: "shero " + (v.category === "low" ? "good" : v.category === "high" ? "crit" : "warn") }, [el("span", { class: "hface", text: face }), el("div", {}, [el("h3", { text: `Risk to your farm: ${word}` }), el("p", { text: "Green is safe, yellow needs watching, red needs action. Tap a tile to see why." })])]),
      el("div", { class: "rtiles" }, tiles), v.missing_information.length ? el("div", { class: "tip warn" }, [el("b", { text: "We could not check everything" }), el("p", { text: v.missing_information.join(" ") })]) : null]);
  }
  // 3. My plan
  async function planSlide() {
    const a = await app.analyse(), S = a.strategies, now = S[0], alts = S.slice(1).sort((p, q) => q.scores.overall - p.scores.overall); let pick = alts[0];
    const host = el("div");
    const cal = (s) => el("div", { class: "cal" }, MONTHS.map((m, i) => { const c = s.crops.findIndex((c) => c.months.includes(m)); return el("div", { class: "cm " + (c === 0 ? "a" : c === 1 ? "b" : "bare") }, [el("small", { text: m }), el("i", { text: c < 0 ? "" : s.crops[c].name.split(" ")[0] })]); }));
    const col = (title, s, best) => el("div", { class: "pcol" + (best ? " best" : "") }, [el("h4", { text: title }), best ? el("span", { class: "ribbon", text: "⭐ Better idea" }) : null, el("p", { class: "ptitle", text: s.label }), el("p", { class: "hint", text: cropNames(s) }), cal(s),
      ...s.crops.map((c) => el("div", { class: "step" }, [el("span", { text: "🌱" }), el("div", {}, [el("b", { text: `${c.name}: sow in ${c.sow_month}` }), el("small", { text: `Harvest around ${c.months[c.months.length - 1]} · about ${c.season_days} days` })])])),
      s.bare_months.length ? el("p", { class: "hint", text: `Field is empty in: ${s.bare_months.join(", ")}` }) : el("p", { class: "hint", text: "The field is never left empty." }), ...(best ? (s.interventions || []).slice(0, 3).map((t) => el("div", { class: "tip info" }, [el("p", { text: t })])) : [])]);
    const draw = () => host.replaceChildren(el("div", { class: "plan" }, [col("What you do now", now, false), col("Try this", pick, true)]));
    const chips = el("div", { class: "chips" }, alts.slice(0, 4).map((s) => { const b = bigBtn(s.label, () => { pick = s; [...chips.children].forEach((c) => c.classList.toggle("on", c === b)); draw(); }, "chip" + (s === pick ? " on" : "")); return b; }));
    draw(); return el("div", { class: "slide" }, [el("h3", { text: "What to grow, and when" }), el("p", { class: "sub", text: "Tap another idea to compare. Each month shows the crop in the ground; brown means empty." }), chips, host, el("p", { class: "hint", text: "Sowing months come from simulating your field's real weather. Check with local advice for the exact date." })]);
  }
  // 4. What if
  async function whatIfSlide() {
    const base = await app.analyse(), st = { temp: 0, rain: 0 }, out = el("div", { class: "wout" }); let busy = 0;
    const group = (title, key, opts) => { const row = el("div", { class: "wrow" }, opts.map(([label, v, ic]) => { const b = bigBtn("", () => { st[key] = v; [...row.children].forEach((c) => c.classList.toggle("on", c === b)); run(); }, "wopt" + (v === 0 ? " on" : "")); b.append(el("span", { class: "sic", text: ic }), el("span", { text: label })); return b; })); return el("div", {}, [el("h4", { text: title }), row]); };
    async function run() {
      const my = ++busy; out.replaceChildren(el("p", { class: "hint", text: "Working it out for your field…" }));
      try {
        const sc = st.temp === 0 && st.rain === 0 ? base : await app.analyse({ temp_c: st.temp, rain_pct: st.rain }); if (my !== busy) return;
        const dv = sc.vulnerability.overall - base.vulnerability.overall, k = dv >= 5 ? "crit" : dv <= -5 ? "good" : "warn", w = st.temp === 0 && st.rain === 0 ? "This is how things are today." : dv >= 5 ? "Your farm would be MORE at risk." : dv <= -5 ? "Your farm would be LESS at risk." : "Your farm would be about the same.";
        const best = sc.strategies.slice().sort((p, q) => q.scores.overall - p.scores.overall)[0], b0 = base.strategies[0], s0 = sc.strategies[0], water = b0.scores.irrigation_need_mm_per_year > 0 ? (s0.scores.irrigation_need_mm_per_year - b0.scores.irrigation_need_mm_per_year) / b0.scores.irrigation_need_mm_per_year : 0;
        out.replaceChildren(el("div", { class: "shero " + k }, [el("span", { class: "hface", text: k === "crit" ? "😟" : k === "good" ? "😊" : "😐" }), el("div", {}, [el("h3", { text: w }), el("p", { text: Math.abs(water) >= 0.1 ? `Your current crops would need about ${Math.round(Math.abs(water) * 100)}% ${water > 0 ? "more" : "less"} irrigation water.` : "Your current crops would need about the same water." })])]),
          el("div", { class: "tip info" }, [el("b", { text: "Best choice in this case: " + best.label }), el("p", { text: cropNames(best) })]), el("p", { class: "hint", text: "This is a what-if test using your field's past weather, not a forecast." }));
      } catch (e) { out.replaceChildren(el("div", { class: "callout crit", text: e.message })); }
    }
    run(); return el("div", { class: "slide" }, [el("h3", { text: "What if the weather changes?" }), el("p", { class: "sub", text: "Tap to test. See what it would mean for your farm." }),
      group("Temperature", "temp", [["Cooler", -1, "🧊"], ["Same", 0, "🌤️"], ["Warmer", 2, "☀️"], ["Much hotter", 4, "🔥"]]), group("Rain", "rain", [["Much drier", -30, "🏜️"], ["Drier", -15, "🌥️"], ["Same", 0, "🌦️"], ["Wetter", 20, "🌧️"]]), out]);
  }
  // 5. Play
  async function playSlide() { const g = await import("./game.js"); const r = await g.render(app); r.querySelector(".page-head")?.remove(); r.style.padding = "0"; return r; }

  go(0); return root;
}
