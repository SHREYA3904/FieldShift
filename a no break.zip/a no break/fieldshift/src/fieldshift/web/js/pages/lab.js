import { el, pct, badge, toast, MONTHS } from "../ui.js";
import { radar, rangeBars } from "../charts.js";
import { api } from "../api.js";
import { compareHero, farmYear } from "../rot.js";
import { head, card, evidence, disclaimer, hypo, cropNames } from "./common.js";

const PRI = [["water", "Save water"], ["nfix", "Fix nitrogen"], ["erosion", "Protect soil"], ["om", "Organic matter"], ["forage", "Fodder"], ["market", "Market"]];
const COL = ["#b3a69c", "#f2a65a", "#8f7bff", "#ffc766", "#ff7b8a"];

export async function render(app) {
  const f = app.field(); let pri = { ...(f.priorities || {}) }, a = await app.analyse(), sel = 1, compare = new Set([0, 1]);
  const root = el("div", { class: "page" }), body = el("div", { class: "page", style: "padding:0" });
  async function recalc() { body.replaceChildren(el("p", { class: "hint", text: "Recalculating every crop and sowing month…" })); try { a = await app.analyse({ priorities: pri }); } catch (e) { toast(e.message); } draw(); }
  const sliders = el("div", { class: "grid g3" }, PRI.map(([k, l]) => { const o = el("output", { text: pri[k] ?? 3 }); return el("label", { class: "field" }, [el("span", { style: "display:flex;justify-content:space-between" }, [l, o]), el("input", { type: "range", min: 0, max: 5, step: 1, value: pri[k] ?? 3, oninput: (e) => { pri[k] = +e.target.value; o.textContent = e.target.value; } })]); }));
  function draw() {
    const S = a.strategies;
    const picks = el("div", { class: "toolbar" }, S.map((s, i) => el("label", { class: "check" }, [el("input", { type: "checkbox", checked: compare.has(i), onchange: (e) => { e.target.checked ? compare.add(i) : compare.delete(i); draw(); } }), el("i", { style: `display:inline-block;width:10px;height:10px;border-radius:3px;background:${COL[i]};margin:0 6px` }), s.label])));
    const cards = S.map((s, i) => strategyCard(s, i));
    const best = S.find((x) => x.label.startsWith("Best")) || S[1] || S[0];
    const charts = el("details", { class: "card" }, [el("summary", { text: "For experts: charts and score ranges", style: "cursor:pointer;font-weight:600" }), el("div", { class: "grid g2", style: "margin-top:10px" }, [card("Compare strategies", [picks, radar(S.map((s, i) => ({ s, color: COL[i] })).filter((x, i) => compare.has(i)))]), card("Overall score with uncertainty", [rangeBars(S, sel, (i) => { sel = i; draw(); })])])]);
    body.replaceChildren(hypo(a), compareHero(S[0], best), el("h3", { text: "All the ideas, from best to worst", style: "margin:6px 0" }), ...cards, charts, evidence(a), disclaimer(a));
  }
  function strategyCard(s, i) {
    const u = s.uncertainty, out = el("div"), det = el("details", { open: i === sel });
    det.append(el("summary", { text: "Evidence, benefits, gaps and risks", style: "cursor:pointer;font-weight:600;margin:6px 0" }),
      el("div", { class: "grid g2" }, [
        el("div", {}, [el("h4", { text: "Evidence", style: "margin:6px 0" }), el("ul", { class: "list" }, s.evidence.map((t) => el("li", { text: t }))), el("h4", { text: "Benefits", style: "margin:10px 0 6px" }), el("ul", { class: "list" }, s.benefits.map((t) => el("li", { text: t })))]),
        el("div", {}, [el("h4", { text: "Information gaps", style: "margin:6px 0" }), el("ul", { class: "list" }, s.information_gaps.map((t) => el("li", { text: t }))), el("h4", { text: "Risks to check locally", style: "margin:10px 0 6px" }), el("ul", { class: "list" }, s.risks_for_local_review.map((t) => el("li", { text: t })))])]),
      s.interventions && s.interventions.length ? el("div", { class: "callout good", style: "margin-top:8px" }, [el("b", { text: "Adaptation actions: " }), s.interventions.join(" ")]) : null);
    return el("section", { class: "card strat" + (i === sel ? " best" : ""), id: "s" + i }, [
      el("div", { class: "strat-head" }, [el("div", {}, [el("h3", { text: s.label, style: "font-size:19px" }), el("p", { class: "sub", text: cropNames(s) + " · sown " + s.crops.map((c) => c.sow_month).join(" and ") })]), el("div", { style: "text-align:right" }, [el("b", { style: "font:600 30px var(--font-display)", text: pct(s.scores.overall) }), el("div", { class: "hint", text: `range ${pct(u.overall_p10)} to ${pct(u.overall_p90)}` })])]),
      el("p", { text: s.why }),
      i === sel ? farmYear(s) : el("div", { class: "seqbar", role: "img", "aria-label": "12-month sequence" }, s.calendar.map((k, m) => el("div", { class: k, title: MONTHS[m] + ": " + (k === "A" ? s.crops[0].name : k === "B" ? s.crops[1].name : "bare"), text: MONTHS[m][0] }))),
      el("div", { class: "grid g4", style: "margin-top:6px" }, [mini("Climate fit", pct(s.scores.climate_fit) + "%"), mini("Matches priorities", pct(s.scores.priority_match) + "%"), mini("Irrigation still needed", Math.round(s.scores.irrigation_need_mm_per_year) + " mm/yr"), mini("Chance it beats current", pct(u.p_beats_current) + "%")]),
      det, el("div", { class: "toolbar" }, [badge("evidence " + s.evidence_grade, ""), el("button", { class: "btn", text: app.aiOn() ? "Explain with AI" : "Explain in plain words", onclick: async (e) => { e.target.disabled = true; out.replaceChildren(el("p", { class: "hint", text: "Writing…" })); try { const r = await api.explain({ strategy: s, language: app.lang() }); out.replaceChildren(el("div", { class: "callout" }, [el("p", { text: r.text, style: "white-space:pre-wrap;margin:0 0 6px" }), el("small", { class: "hint", text: r.note })])); } catch (err) { out.replaceChildren(el("p", { class: "hint", text: err.message })); } e.target.disabled = false; } })]), out]);
  }
  const mini = (l, v) => el("div", { class: "kpi", style: "padding:8px 0" }, [el("b", { text: v, style: "font-size:20px" }), el("span", { text: l })]);
  root.append(head("Rotation Lab", "Every crop and sowing month is simulated on your field's real weather history. Change what matters to you and the ranking is recalculated by the server."),
    card("Your priorities", [sliders, el("div", { class: "toolbar" }, [el("button", { class: "btn solid", text: "Recalculate ranking", onclick: recalc }), el("button", { class: "btn", text: "Reset to field defaults", onclick: () => { pri = { ...(f.priorities || {}) }; recalc(); } })])]), body);
  draw();
  return root;
}
