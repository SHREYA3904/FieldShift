import { el, reveal, count, MONTHS, pct, icon } from "../ui.js";
import { splitText } from "../fx.js";
import { store, keys } from "../api.js";
import { gauge, radar, polygonSketch } from "../charts.js";
import { byLabel } from "./common.js";

let node = null, globeLoaded = false;

function signal(ico, bg, val, label) { return el("div", { class: "signal reveal" }, [el("i", { style: `background:${bg}`, text: ico }), el("div", {}, [el("b", { text: val }), el("span", { text: label })])]); }
function story(n, kicker, h, p, visual, stage, flip) {
  return el("section", { class: "story" + (flip ? " flip" : ""), "aria-label": kicker, "data-stage": JSON.stringify(stage) }, [el("div", { class: "inner" }, [
    el("div", { class: "reveal" }, [el("p", { class: "eyebrow", text: `${n} · ${kicker}` }), splitText(el("h2", { text: h })), p ? el("p", { text: p, style: "margin-top:14px" }) : null]),
    el("div", { class: "reveal" }, [visual])])]);
}

function sigs(a, f) {
  const c = a && a.climate, sat = a && a.satellite, v = a && a.vulnerability;
  const sig1 = el("div", { class: "grid", style: "gap:12px" }, a ? [
    signal("🌡", "rgba(255,199,102,.16)", `${c.warming_trend_c_per_decade >= 0 ? "+" : ""}${c.warming_trend_c_per_decade.toFixed(2)} °C / decade`, `Measured temperature trend, ${c.years_of_data} years of NASA POWER`),
    signal("🌧", "rgba(90,182,255,.16)", `${c.rain_trend_mm_per_year >= 0 ? "+" : ""}${c.rain_trend_mm_per_year.toFixed(1)} mm / year`, "Rain trend (the test results on the Climate Risks page say whether it is significant)"),
    signal("🏜", "rgba(255,123,138,.16)", `${a.detection.drought.months_in_drought_last_24} of 24 months`, "In drought (SPI-3 ≤ −1) over the last two years")] :
    [el("p", { class: "hint", text: "Live demo numbers appear here once the server can reach NASA." })]);
  const sig2 = el("div", { class: "grid", style: "gap:12px" }, (a ? a.datasets : []).slice(0, 6).map((d) =>
    el("div", { class: "signal reveal" }, [el("i", { style: "background:rgba(242,166,90,.14)", text: d.status === "live" ? "●" : "○" }), el("div", {}, [el("b", { text: d.name, style: "font-size:15px" }), el("span", { text: `${d.resolution}. ${d.status === "live" ? "Connected" : d.status === "fallback" ? "Fallback used" : "Not connected yet"}` })])])));
  const sk = a && polygonSketch(f.boundary, 200);
  const sig3 = el("div", { class: "card", style: "display:grid;grid-template-columns:auto 1fr;gap:18px;align-items:center" }, a ? [
    sk || el("div"), el("div", {}, [gauge(v.overall, "Vulnerability"), el("p", { class: "hint", style: "text-align:center", text: `Demo field · ${v.category} vulnerability · confidence ${v.confidence}` })])] : [el("p", { class: "hint", text: "Field summary appears once data loads." })]);
  const strs = a ? [a.strategies[0], byLabel(a, "Best"), byLabel(a, "Water")].filter(Boolean) : [];
  const sig4 = a ? el("div", { class: "card" }, [radar(strs.map((s, i) => ({ s, color: ["#b3a69c", "#f2a65a", "#8f7bff"][i] })))]) : el("p", { class: "hint", text: "Strategy comparison appears once data loads." });
  const sig5 = a ? el("div", { class: "grid g2", style: "gap:12px" }, [
    signal("✓", "rgba(242,166,90,.16)", `${pct(byLabel(a, "Best").scores.overall)} vs ${pct(a.strategies[0].scores.overall)}`, "Best-match rotation vs current, demo field"),
    signal("↧", "rgba(90,182,255,.16)", `${Math.round(byLabel(a, "Water").scores.irrigation_need_mm_per_year)} mm`, "Irrigation still needed per year, water-saving option")]) : el("span");

  return [sig1, sig2, sig3, sig4, sig5];
}

export async function render(app) {
  if (node) return node;
  const f = (app.fields.find((x) => x.id === "demo-field")) || app.field();
  const readout = el("div", { class: "readout", id: "ro" }, [el("b", { id: "ro-place", text: "Drag the globe. Click anywhere." }), el("span", { id: "ro-sub", text: "Then open the workspace to analyse a field there." })]);
  const globeHost = el("div", { class: "globe", id: "globe", "aria-label": "Interactive globe. Drag to rotate, click to choose a place." });
  const hero = el("section", { class: "hero" }, [globeHost, el("div", { class: "hero-copy rise" }, [
    el("p", { class: "eyebrow", text: "NASA Space Apps 2026 · Field Shift" }),
    splitText(el("h1", {}, ["Farming with the ", el("em", { text: "intelligence" }), " of Earth."])),
    el("p", { class: "lead", text: "TerraAdapt turns NASA climate and satellite records into clear comparisons of crop rotations for your own field, with the uncertainty shown." }),
    el("div", { class: "hero-cta" }, [el("a", { class: "btn solid", href: app.user ? "#/dashboard" : "#/login", text: "Explore Your Field" }), el("a", { class: "btn", href: "#story1", text: "See how it works", onclick: (e) => { e.preventDefault(); document.getElementById("story1").scrollIntoView({ behavior: "smooth" }); } })]),
    el("div", { class: "looking" }, [el("p", { text: "What are you looking for?" }), el("a", { href: "#/forecast", text: "Weather outlook" }), el("a", { href: "#/lab", text: "Which rotation to grow" }), el("a", { href: "#/risks", text: "Climate risks" }), el("a", { href: "#/fields", text: "My fields" }), el("a", { href: "#/assistant", class: "askpill", text: "Ask me anything…" })])
  ]),
    readout, el("div", { class: "scroll-cue", text: "Scroll" })]);

  const holders = [1, 2, 3, 4, 5].map(() => el("div", { class: "grid" }, [el("div", { class: "skeleton", style: "height:150px" })]));
  const [sig1, sig2, sig3, sig4, sig5] = holders;
  const wrap = el("div", {}, [hero,
    el("div", { id: "story1" }),
    story("01", "A Changing Planet", "The climate is changing. So must the way we farm.", "Warmer seasons, shifting rain and longer dry spells reach every field differently. TerraAdapt measures what changed at your location instead of assuming it.", sig1, { x: 0.24, y: 0, s: 0.95 }),
    story("02", "Reading Earth's Signals", "Earth is constantly sending signals.", "Daily weather, satellite greenness, soil and elevation are pulled live. Each source is labelled with its resolution, and anything we cannot reach is marked, never invented.", sig2, { x: -0.24, y: 0, s: 0.8 }, true),
    story("03", "Understanding Your Field", "Every field tells a different story.", "Draw your boundary, add soil tests and history, and get a 0 to 100 vulnerability score with the evidence behind every point and the information that is still missing.", sig3, { x: 0.24, y: 0, s: 1.2, pin: [23.25, 87.86] }),
    story("04", "The Rotation Lab", "Better decisions begin with better comparisons.", "Every crop and sowing month is simulated across all past years. Move your priorities and the whole ranking is recalculated, with a range around each score.", sig4, { x: -0.24, y: 0.02, s: 0.75 }, true),
    story("05", "Building Resilience", "Adapt today. Protect tomorrow.", "Decision support, not a yield forecast. Always check with a local agricultural adviser.", sig5, { x: 0, y: 0, s: 1.35 }),
    el("section", { class: "cta-end reveal" }, [splitText(el("h2", { text: "Start with your own field." })), el("div", { class: "hero-cta", style: "justify-content:center" }, [el("a", { class: "btn solid", href: app.user ? "#/dashboard" : "#/login", text: app.user ? "Open my workspace" : "Create your account" }), el("a", { class: "btn", href: "#/dashboard", text: "Try the demo field" })])])]);
  node = wrap;
  app.analyse({}, "demo-field").then((a) => { sigs(a, f).forEach((v, i) => { holders[i].replaceChildren(v); reveal(holders[i]); }); })
    .catch(() => holders.forEach((h) => h.replaceChildren(el("p", { class: "hint", text: "Live demo numbers appear here once the server can reach NASA." }))));
  return wrap;
}

function applyStage(st) {
  const go = () => { if (window.FSGlobe) { window.FSGlobe.setStage({ x: st.x, y: st.y, s: st.s }); if (st.pin) window.FSGlobe.setPin(st.pin[0], st.pin[1], true); return true; } return false; };
  if (!go()) { let n = 0; const t = setInterval(() => { if (go() || ++n > 40) clearInterval(t); }, 250); }
}
export function after(n) {
  reveal(n);
  setTimeout(() => n.querySelectorAll(".hero h1 .ch").forEach((c) => c.classList.add("go")), 150);
  const hero = n.querySelector(".hero"), globe = n.querySelector("#globe");
  new IntersectionObserver((es) => globe.classList.toggle("live", es[0].isIntersecting), { threshold: 0.35 }).observe(hero);
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) applyStage(JSON.parse(e.target.dataset.stage)); }), { threshold: 0.55 });
  n.querySelectorAll(".story").forEach((s) => io.observe(s));
  new IntersectionObserver((es) => { if (es[0].isIntersecting) applyStage({ x: 0.2, y: 0, s: 1 }); }, { threshold: 0.6 }).observe(hero);
  if (!globeLoaded && store.get(keys.THREEN, "1") === "1") {
    globeLoaded = true;
    document.addEventListener("fs:pick", (e) => {
      const { lat, lon } = e.detail, p = document.getElementById("ro-place"), s = document.getElementById("ro-sub"); if (!p) return;
      p.textContent = `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? "N" : "S"}, ${Math.abs(lon).toFixed(2)}°${lon >= 0 ? "E" : "W"}`;
      s.innerHTML = ""; s.appendChild(el("a", { href: `#/fields?lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`, text: "Add a field here →", style: "color:var(--accent)" }));
    });
    document.addEventListener("fs:noglobe", () => { const g = document.getElementById("globe"); if (g) g.style.background = "radial-gradient(circle at 72% 50%,#3a2350,transparent 62%)"; });
    import("../../globe.js").catch(() => document.dispatchEvent(new CustomEvent("fs:noglobe")));
  } else if (store.get(keys.THREEN, "1") !== "1") {
    const g = document.getElementById("globe"); if (g) g.style.background = "radial-gradient(circle at 72% 50%,#3a2350,transparent 62%)";
  }
}
