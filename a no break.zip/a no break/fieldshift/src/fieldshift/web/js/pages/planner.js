import { el, MONTHS, pct } from "../ui.js";
import { ring } from "../charts.js";
import { head, card, hypo, cropNames } from "./common.js";

function gantt(s, risk) {
  const bar = (name, months, cls, color) => {
    const segs = []; let i = 0; const set = new Set(months.map((m) => MONTHS.indexOf(m)));
    while (i < 12) { if (set.has(i)) { let j = i; while (set.has(j + 1) && j < 11) j++; segs.push([i, j]); i = j + 1; } else i++; }
    return el("div", { class: "grow" }, [el("span", { text: name }), el("div", { class: "gtrack" }, segs.map(([a, b]) => el("div", { class: "gbar", style: `left:${a / 12 * 100}%;width:${(b - a + 1) / 12 * 100}%;background:${color}`, text: (b - a) >= 1 ? name.split(" ")[0] : "" })))]);
  };
  const riskMonths = (k, min) => MONTHS.filter((_, i) => risk[k][i] >= min);
  return el("div", { class: "gantt" }, [
    el("div", { class: "gmonths" }, [el("div"), el("div", {}, MONTHS.map((m) => el("span", { text: m })))]),
    bar(s.crops[0].name, s.crops[0].months, "A", "var(--leaf)"), bar(s.crops[1].name, s.crops[1].months, "B", "var(--water)"),
    bar("Bare field", s.bare_months, "bare", "var(--sun)"), bar("Dry risk (≥20% of years)", riskMonths("dry", .2), "r", "#c9a24f"), bar("Heat risk (≥20% of years)", riskMonths("hot", .2), "r", "var(--crit)")]);
}
export async function render(app) {
  const a = await app.analyse(), root = el("div", { class: "page" }), host = el("div", { class: "page", style: "padding:0" }); let i = 1;
  const sel = el("select", { "aria-label": "Compare with", onchange: (e) => { i = +e.target.value; draw(); } }, a.strategies.slice(1).map((s, k) => el("option", { value: k + 1, text: s.label, selected: k + 1 === i })));
  function draw() {
    const cur = a.strategies[0], s = a.strategies[i], risk = a.climate.anomalies.monthly_risk;
    host.replaceChildren(hypo(a),
      el("div", { class: "grid g2" }, [card("Now: " + cur.label, [el("p", { class: "sub", text: cropNames(cur) }), gantt(cur, risk), el("p", { class: "hint", text: cur.bare_months.length ? `Bare months: ${cur.bare_months.join(", ")}` : "No bare months." })]),
        card("Proposed: " + s.label, [el("p", { class: "sub", text: cropNames(s) }), gantt(s, risk), el("p", { class: "hint", text: s.bare_months.length ? `Bare months: ${s.bare_months.join(", ")}` : "No bare months." })])]),
      el("div", { class: "grid g2" }, [card("Year at a glance", [el("div", { style: "display:grid;place-items:center" }, [ring(s)])]),
        card("What to do and when", [el("ul", { class: "list" }, [...s.crops.map((c) => el("li", { text: `${c.name}: sow in ${c.sow_month}, growing ${c.months[0]} to ${c.months[c.months.length - 1]} (about ${c.season_days} days). Rain in season ${Math.round(c.rain_in_season_mm)} mm against a typical need of ${Math.round(c.typical_need_mm)} mm.` })),
          ...(s.interventions || []).map((t) => el("li", { text: t }))]), el("p", { class: "hint", text: "Sowing months are chosen by simulation across past years. Confirm exact dates with local advice and the monsoon or season onset in your area." })])]));
  }
  root.append(head("Seasonal Planner", "Month-by-month view of what grows, when the field is bare and when climate risks cluster.", el("label", { class: "field", style: "min-width:240px" }, ["Compare current with", sel])), host);
  draw(); return root;
}
