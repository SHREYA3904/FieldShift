import { el, pct, badge, catKind, MONTHS } from "../ui.js";
import { gauge, riskHeat, mlChart } from "../charts.js";
import { head, card, evidence } from "./common.js";

export async function render(app) {
  const a = await app.analyse(), v = a.vulnerability, ml = a.ml_detection, d = a.detection;
  const inds = v.indicators.slice().sort((x, y) => y.score - x.score).map((i) => el("div", { class: "ind" }, [
    el("div", { class: "ind-top" }, [el("span", { text: i.id.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase()) }), el("span", {}, [badge(i.category, catKind(i.category)), ` ${Math.round(i.score)}`])]),
    el("div", { class: "meter" }, [el("i", { style: `width:${i.score}%;background:${i.score < 33 ? "var(--good)" : i.score < 66 ? "var(--warn)" : "var(--crit)"}` })]),
    el("span", { class: "hint", text: `${i.evidence} (weight ${Math.round(i.weight * 100)}%)` })]));
  return el("div", { class: "page" }, [head("Climate Risks", "Where this field is vulnerable, how sure we are, and what we could not assess."),
    el("div", { class: "grid g2" }, [
      card("Vulnerability score", [el("div", { style: "text-align:center" }, [gauge(v.overall, "Vulnerability"), el("p", {}, [badge(`${v.category} vulnerability`, catKind(v.category)), " ", badge(`confidence ${v.confidence}`, "")])]), el("p", { class: "hint", text: `Scored for: ${a.vulnerability_for || "your current rotation"}. ${v.method}` }),
        v.missing_information.length ? el("div", { class: "callout warn" }, [el("b", { text: "Missing information: " }), v.missing_information.join(" ")]) : el("div", { class: "callout good", text: "No key inputs are missing." })]),
      card("Indicators and evidence", inds)]),
    evidence(a),
    card("Months that were unusual in past years", [riskHeat(a.climate.anomalies.monthly_risk), el("p", { class: "hint", text: `Share of the ${a.climate.years_of_data} years in which each month was unusually dry, hot, wet or cold. ${a.climate.anomalies.method}.` })]),
    el("div", { class: "grid g2" }, [
      card("Detected shifts (statistical tests)", [el("ul", { class: "list" }, d.shifts.map((s) => el("li", {}, [badge(s.mann_kendall.p < .05 ? "significant" : "not significant", s.mann_kendall.p < .05 ? "warn" : ""), " ", s.verdict, s.pettitt.significant ? ` A step change was detected around year index ${s.pettitt.change_index}.` : ""]))),
        el("p", { class: "hint", text: "Mann-Kendall trend test with Sen's slope, and Pettitt change-point test. A trend that is not significant may be noise." })]),
      card("Drought", [el("ul", { class: "list" }, [el("li", { text: `Lowest 3-month SPI in the last 24 months: ${d.drought.spi3_lowest_last_24_months}` }), el("li", { text: `${d.drought.months_in_drought_last_24} of the last 24 months were in drought.` }),
        el("li", { text: `Longest dry spell: ${d.drought.longest_dry_spell_days_median} days in a typical year, ${d.drought.longest_dry_spell_days_worst} days in the worst year.` })]), el("p", { class: "hint", text: d.drought.note })])]),
    ml ? card("Learned satellite stress detection", [
      el("div", { class: "callout " + (ml.reliable ? "good" : "warn") }, [el("b", { text: ml.reliable ? "Model is reliable here. " : "Model is not reliable here. " }), ml.verdict, ` Skill vs monthly average: ${ml.skill_vs_monthly_average}, R² ${ml.r2}, ${ml.years_used} years.`]),
      ml.recent && ml.recent.length ? mlChart(ml) : null,
      ml.reliable && ml.unexplained_stress.length ? el("div", { class: "tw" }, [el("table", { class: "t" }, [el("thead", {}, [el("tr", {}, ["Month", "Observed", "Expected", "Gap (z)"].map((h) => el("th", { text: h })))]),
        el("tbody", {}, ml.unexplained_stress.slice(0, 10).map((s) => el("tr", {}, [el("td", { text: `${s.month} ${s.year}` }), el("td", { text: s.observed_ndvi }), el("td", { text: s.expected_ndvi }), el("td", { text: s.z })])))])]) : null,
      el("p", { class: "hint", text: ml.method })]) : card("Learned satellite stress detection", [el("p", { class: "hint", text: "Needs satellite greenness data, which was not retrieved for this run." })]),
    a.nasa_soil_wetness_check ? card("Cross-check with NASA soil wetness", [el("p", { text: a.nasa_soil_wetness_check.meaning }), el("p", { class: "hint", text: `Spearman r = ${a.nasa_soil_wetness_check.spearman_r} over ${a.nasa_soil_wetness_check.months} months. ${a.nasa_soil_wetness_check.method}` })]) : null]);
}
