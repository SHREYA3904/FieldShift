import { el, toast, badge } from "../ui.js";
import { api } from "../api.js";
import { head, card } from "./common.js";

export async function render(app) {
  const u = app.user, p = { ...u.profile }, mem = await api.memory();
  const text = (label, key, ph, type = "text") => el("label", { class: "field" }, [label, el("input", { type, placeholder: ph || "", value: p[key] ?? "", oninput: (e) => (p[key] = type === "number" ? (e.target.value ? +e.target.value : "") : e.target.value) })]);
  const sel = (label, key, opts) => el("label", { class: "field" }, [label, el("select", { onchange: (e) => (p[key] = e.target.value) }, [["", "Not set"], ...opts].map(([v, t]) => el("option", { value: v, text: t, selected: (p[key] || "") === v })))]);
  const name = el("input", { type: "text", value: u.name || "", maxlength: 80 });
  const mine = app.fields.filter((f) => f.id !== "demo-field");
  const last = {}; mem.snapshots.forEach((s) => (last[s.field_id] = s.content));
  const form = el("form", { class: "grid", onsubmit: async (e) => { e.preventDefault(); try { const r = await api.updateMe({ name: name.value.trim(), profile: p }); app.user = r.user; toast("Profile saved. Advice will use it."); } catch (ex) { toast(ex.message); } } }, [
    el("label", { class: "field" }, ["Name", name]), text("Where you farm", "region", "Village, district, state or country"), text("Total farm size (ha)", "farm_size_ha", "", "number"),
    sel("Experience", "experience", [["beginner", "Just starting"], ["some", "A few seasons"], ["experienced", "Experienced"]]),
    sel("What matters most", "main_goal", [["water", "Save water"], ["soil", "Healthier soil"], ["income", "Higher income"], ["fodder", "Fodder for livestock"], ["balanced", "A bit of everything"]]),
    sel("Water source", "water_source", [["rain", "Rain only"], ["well", "Well / borewell"], ["canal", "Canal / river"], ["mixed", "Mixed"]]),
    el("label", { class: "field" }, ["Anything else the assistant should know", el("textarea", { rows: 3, oninput: (e) => (p.notes = e.target.value) }, p.notes || "")]),
    el("button", { class: "btn solid", type: "submit", text: "Save profile" })]);
  const chat = mem.chat.length;
  return el("div", { class: "page" }, [head("Profile & Memory", "What TerraAdapt knows about you and your farm. You can change or erase it any time."),
    el("div", { class: "grid g2" }, [card("About you", [el("p", { class: "hint", text: `Signed in as ${u.email || u.phone}` }), form]),
      card("What I remember", [
        el("div", { class: "memrow" }, [el("span", { text: "Saved fields" }), el("b", { text: mine.length })]),
        ...mine.map((f) => { const s = last[f.id]; return el("div", { class: "memrow" }, [el("span", {}, [el("b", { text: f.name }), el("div", { class: "hint", text: `${f.current.join(" then ")}${f.area_ha ? ", " + f.area_ha + " ha" : ""}${s ? `. Last checked ${s.date}: vulnerability ${Math.round(s.vulnerability)}, best option ${s.best_crops.join(" then ")}` : ". Not analysed yet"}` })]), badge(s ? s.category : "new", "")]); }),
        el("div", { class: "memrow" }, [el("span", { text: "Analysis snapshots (one a day per field)" }), el("b", { text: mem.snapshots.length })]),
        el("div", { class: "memrow" }, [el("span", { text: "Chat messages remembered" }), el("b", { text: chat })]),
        el("div", { class: "toolbar" }, [el("button", { class: "btn", text: "Clear chat memory", onclick: async () => { await api.forget("chat"); toast("Chat memory cleared."); app.go("profile"); location.reload(); } }),
          el("button", { class: "btn", text: "Forget history snapshots", onclick: async () => { await api.forget("snapshot"); toast("Snapshots cleared."); location.reload(); } })]),
        el("p", { class: "hint", text: "Fields are kept until you delete them under My Fields. Memory is stored in this app's database on the server you run, linked to your account, and is sent to the AI only if you turned AI on." })])])]);
}
