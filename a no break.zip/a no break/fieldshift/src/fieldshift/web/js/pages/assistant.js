import { el, toast } from "../ui.js";
import { api } from "../api.js";
import { head, card } from "./common.js";
import { t, voiceCode } from "../i18n.js";
import { askTerra, speak as terraSpeak } from "../terra.js";

const QS = ["What can I plant now?", "When can I plant rice?", "What is the weather outlook this week?", "Should I irrigate now?", "Why is this rotation recommended?", "How vulnerable is my field and why?", "What happens if rain falls 20% below normal?", "Show my fields", "What changed since last time?", "What information is missing?"];
const SR = window.SpeechRecognition || window.webkitSpeechRecognition, TTS = "speechSynthesis" in window;
const speak = (txt) => { if (!TTS) return; speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(txt); u.lang = voiceCode(); u.rate = 0.9; speechSynthesis.speak(u); };
export async function render(app) {
  const f = app.field(), log = el("div", { class: "chat", role: "log", "aria-live": "polite" });
  const add = (cls, text, note) => { const m = el("div", { class: "msg " + cls, ...(cls === "u" ? { translate: "no" } : {}) }, [el("span", { text }), note ? el("small", { text: note }) : null]); log.appendChild(m); log.scrollTop = log.scrollHeight; return m; };
  const nm = app.first();
  add("a", `${nm ? "Hi " + nm + ". " : "Hi. "}I look at ${f.name} using its NASA climate history, satellite readings and the 16-day forecast${app.user ? ", and I remember your fields and our earlier chats" : ". Sign in and I will remember your fields and our chats"}. ${app.aiOn() ? "AI writing is on." : "AI is off, so answers are assembled directly from your results."}`);
  if (app.user) {
    try { const m = await api.memory(); m.chat.filter((c) => c.field_id === f.id).slice(-10).forEach((c) => add(c.content.role === "user" ? "u" : "a", c.content.text)); } catch (e) { /* history is optional */ }
  }
  async function ask(q, shown) {
    if (!q.trim()) return; add("u", shown || q);
    const w = add("a", ""); w.firstChild.replaceWith(el("span", { class: "typing" }, [el("i"), el("i"), el("i")]));
    try { const r = await askTerra(app, q); const a = r.as_of; w.setAttribute("translate", "no"); w.replaceChildren(...[el("span", { text: r.text }), r.place ? el("small", { class: "placenote", text: r.place.note }) : null,
      TTS ? el("button", { type: "button", class: "btn say", text: "🔊 " + t("Listen"), onclick: () => speak(r.text) }) : null, el("small", { text: (r.mode === "ai" ? "AI-written · " : "From your results · ") + r.note }),
      a ? el("small", { class: "asof", text: `Live data · today ${a.today} · NASA POWER ${a.weather_from || "?"} to ${a.weather_through || "?"} (${a.years || "?"} years) · ${a.forecast_fetched_at ? "forecast fetched " + a.forecast_fetched_at.replace("T", " ").slice(0, 16) + " UTC" : "no forecast used"} · satellite ${a.satellite ? "on" : "off"}` }) : null].filter(Boolean)); }
    catch (e) { w.replaceChildren(el("span", { text: e.message })); if (e.status === 404) { try { await app.reloadFields(); app.drawFieldSelect(); } catch (_) {} } }
    log.scrollTop = log.scrollHeight;
  }
  const inp = el("input", { type: "text", placeholder: `${t("Ask")}: ${f.name}…`, maxlength: 400, "aria-label": "Your question", style: "flex:1" });
  function listen(btn) {
    const r = new SR(); r.lang = voiceCode(); r.interimResults = false; btn.classList.add("on");
    r.onresult = (ev) => { const q = ev.results[0][0].transcript; inp.value = ""; ask(q); };
    r.onerror = () => toast("I could not hear you. Allow the microphone and try again."); r.onend = () => btn.classList.remove("on");
    try { r.start(); } catch (_) { btn.classList.remove("on"); }
  }
  const form = el("form", { class: "chat-in", onsubmit: (e) => { e.preventDefault(); const q = inp.value; inp.value = ""; ask(q); } }, [inp, SR ? el("button", { class: "btn mic", type: "button", "aria-label": t("Speak"), title: t("Speak"), text: "🎤", onclick: (e) => listen(e.currentTarget) }) : null, el("button", { class: "btn solid", type: "submit", text: t("Ask") })]);
  const wrap = el("div", { class: "page" }, [head("AI Assistant", "Grounded in this field's results, the forecast and what it remembers about you. AI answers are checked against your numbers and replaced if they add figures.",
    app.user ? el("button", { class: "btn", text: t("Clear chat memory"), onclick: async () => { await api.forget("chat"); location.reload(); } }) : el("a", { class: "btn solid", href: "#/login", text: "Sign in to be remembered" })),
    card(null, [log, el("div", { class: "qchips", style: "margin:10px 0" }, QS.map((q) => el("button", { type: "button", text: t(q), onclick: () => ask(q, t(q)) }))), form])]);
  setTimeout(() => (log.scrollTop = log.scrollHeight), 50);
  return wrap;
}
