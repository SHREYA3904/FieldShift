import { el, pct, MONTHS, catKind, badge } from "../ui.js";
import { gauge, climateChart } from "../charts.js";
import { head, card, kpi, evidence, disclaimer, byLabel, cropNames } from "./common.js";
import { api } from "../api.js";
import { emoji } from "../journey.js";

export async function render(app) {
  const a = await app.analyse(), f = app.field(), v = a.vulnerability, cur = a.strategies[0], best = byLabel(a, "Best"), c = a.climate;
  const unusual = (c.anomalies.recent_unusual_months || []).slice(0, 6);
  const hr = new Date().getHours(), greet = hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening", nm = app.first();
  const goal = app.user && app.user.profile.main_goal, GL = { water: "saving water", soil: "healthier soil", income: "income", fodder: "fodder for livestock", balanced: "a balanced approach" };
  const out = el("div", { class: "card" }, [el("p", { class: "hint", text: "Checking the 16-day forecast for this field…" })]);
  api.forecast(f.id).then((o) => { const top = o.actions.find((x) => x.severity !== "info"); out.replaceChildren(el("div", { style: "display:flex;justify-content:space-between;gap:10px;align-items:start" }, [el("div", {}, [el("span", { class: "hint", text: "Weather outlook, next 16 days" }), el("h3", { text: top ? top.title : "Nothing unusual ahead", style: "font-size:18px;margin:4px 0" }), el("p", { class: "hint", text: top ? top.action || top.evidence : `${o.stats.rain_next7_mm.toFixed(0)} mm rain expected in 7 days.` })]), badge(o.level, o.level === "alert" ? "crit" : o.level === "watch" ? "warn" : "good")]), el("a", { class: "btn", href: "#/forecast", text: "Open outlook", style: "margin-top:8px" })); }).catch((e) => out.replaceChildren(el("p", { class: "hint", text: "Forecast unavailable right now: " + e.message })));
  const page = el("div", { class: "page" }, [
    el("div", {}, [el("p", { class: "greet", text: `${greet}${nm ? ", " + nm : ""}` }), el("p", { class: "sub", text: goal ? `Showing ${f.name}. You said ${GL[goal]} matters most, and the options below are ranked with that in mind.` : `Showing ${f.name}. ${app.user ? "Set what matters most under Profile to tune the ranking." : "Sign in to save your own fields and have advice remember them."}` })]),
    head(f.name, `${f.farm} · ${f.lat.toFixed(3)}, ${f.lon.toFixed(3)}${f.area_ha ? " · " + f.area_ha + " ha" : ""}`, el("div", { class: "toolbar" }, [el("a", { class: "btn", href: "#/fields", text: "Edit field" }), el("a", { class: "btn solid", href: "#/lab", text: "Open Rotation Lab" })])),
    f.note ? el("div", { class: "callout", text: f.note }) : null,
    el("div", { class: "grid g4" }, [
      el("div", { class: "card", style: "text-align:center" }, [el("span", { class: "hint", text: `Vulnerability (${v.vulnerability_for || "current rotation"})` }), gauge(v.overall, "Vulnerability"), badge(`${v.category} · confidence ${v.confidence}`, catKind(v.category))]),
      kpi(`${pct(cur.scores.overall)} → ${pct(best.scores.overall)}`, "Current vs best-match score", cropNames(best)),
      kpi(`${c.warming_trend_c_per_decade >= 0 ? "+" : ""}${c.warming_trend_c_per_decade.toFixed(2)} °C`, "Warming per decade", a.detection.shifts.find((s) => /Temp/.test(s.variable))?.verdict || ""),
      kpi(`${a.detection.drought.months_in_drought_last_24} / 24`, "Months in drought, last 2 years", `Longest dry spell in a typical year: ${a.detection.drought.longest_dry_spell_days_median} days`)]),
    evidence(a), out,
    el("div", { class: "grid g2" }, [
      card("Seasonal climate at this field", [climateChart(c, c.anomalies.monthly_risk)]),
      card("What stands out", [
        el("ul", { class: "list" }, [
          ...v.indicators.filter((i) => i.category !== "low").sort((x, y) => y.score - x.score).slice(0, 3).map((i) => el("li", {}, [badge(i.category, catKind(i.category)), " ", i.evidence])),
          a.ml_detection && a.ml_detection.reliable && a.ml_detection.unexplained_stress.length ? el("li", {}, [badge("satellite", "warn"), ` The learned model found ${a.ml_detection.unexplained_stress.length} months where crops were much less green than the weather explains. See Climate Risks.`]) : null,
          unusual.length ? el("li", {}, [badge("recent", ""), ` Unusual recent months: ${unusual.map((u) => `${u.month} ${u.year} (${u.kind})`).join(", ")}.`]) : null]),
        el("div", { class: "toolbar" }, [el("a", { class: "btn", href: "#/risks", text: "Climate Risks" }), el("a", { class: "btn", href: "#/planner", text: "Seasonal Planner" }), el("a", { class: "btn", href: "#/assistant", text: "Ask the assistant" })])])]),
    disclaimer(a)]);
  // Plain-language answer first: three big tiles. The numbers and charts wait in one folded section for people who want them.
  const idOf = (c) => c.id || String(c.name || "").toLowerCase(), cat = v.category, lvl = cat === "high" ? ["Danger", "🔥", 0.9, "crit"] : cat === "moderate" ? ["Watch", "👀", 0.55, "warn"] : ["Safe", "😊", 0.2, "good"];
  const tile = (cls, big, title, body, foot) => el("div", { class: "gtile " + cls }, [el("div", { class: "gbig", text: big }), el("h3", { text: title }), ...body, foot]);
  const glance = el("div", { class: "glance" }, [
    tile("g1", best.crops.map((c) => emoji(idOf(c))).join(" "), "What to grow", [el("p", { class: "gline", text: cropNames(best) }), el("p", { class: "hint", text: "Sow in " + best.crops.map((c) => MONTHS[c.sow_month - 1] || c.sow_month).join(" and ") })], el("a", { class: "btn solid", href: "#/lab", text: "See it in the Rotation Lab" })),
    tile("g2 " + lvl[3], lvl[1], "Risk to your farm: " + lvl[0], [el("div", { class: "gmeter" }, [el("i", { style: `--w:${lvl[2] * 100}%` })]), el("p", { class: "hint", text: "Green is safe, yellow needs watching, red needs action. Tap a tile to see why." })], el("a", { class: "btn", href: "#/risks", text: "Why?" })),
    tile("g3", "🎮", "See a season happen", [el("p", { class: "gline", text: "Pick a crop and watch it grow, or be lost, on your own weather." })], el("button", { class: "btn", type: "button", text: "▶ Start", onclick: () => app.startJourney && app.startJourney() }))]);
  page.insertBefore(glance, page.children[1] || null);
  const more = el("details", { class: "card gmore" }, [el("summary", { text: "For experts: all the numbers and charts" })]);
  [...page.querySelectorAll(":scope > .grid")].forEach((g) => more.append(g));
  page.insertBefore(more, page.lastElementChild);
  return page;
}
