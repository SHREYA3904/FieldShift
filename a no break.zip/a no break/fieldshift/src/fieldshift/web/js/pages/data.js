import { el, badge, MONTHS } from "../ui.js";
import { api } from "../api.js";
import { head, card } from "./common.js";

const table = (cols, rows) => el("div", { class: "tw" }, [el("table", { class: "t" }, [el("thead", {}, [el("tr", {}, cols.map((c) => el("th", { text: c })))]), el("tbody", {}, rows.map((r) => el("tr", {}, r.map((c) => el("td", {}, [c])))))])]);
const f1 = (v, d = 1) => (v == null ? "n/a" : (+v).toFixed(d));
const bar = (v) => el("span", { style: `display:inline-block;height:8px;width:${Math.round((v || 0) * 70)}px;background:${v >= .8 ? "var(--leaf)" : v >= .4 ? "var(--accent)" : "var(--crit)"};border-radius:4px;vertical-align:middle`, title: v == null ? "n/a" : v.toFixed(2) });

export async function render(app) {
  const root = el("div", { class: "page" }), [pack, a] = await Promise.all([api.datapack(), app.analyse().catch(() => null)]);
  const reg = a && a.region;
  root.append(head("Data & Sources", "Every dataset behind the numbers: what it is, what it was used for, and what it cannot tell you."));

  if (a) {
    const dq = a.data_quality, s = dq.soil || {};
    root.append(card("This field right now", [
      el("p", { text: `${a.field.name}: weather ${dq.first_weather_date} to ${dq.last_weather_date} (${dq.years} years). ${dq.bundled_weather ? "Live NASA POWER was not reachable, so the supplied NASA POWER file was used." : "Weather downloaded live from NASA POWER."}` }),
      el("p", { text: `Soil source: ${({ ssurgo: "USDA SSURGO (supplied)", soilgrids: "SoilGrids (live)", user: "chosen by you", assumed: "assumed loam" })[s.source] || s.source}. Sand ${s.sand_pct}%, clay ${s.clay_pct}%, water capacity ${s.awc_mm_per_m} mm/m${s.ph != null ? ", pH " + s.ph : ""}.` }),
      reg ? el("p", { class: "hint", text: reg.note }) : null,
      dq.live_vs_supplied ? el("div", { class: "callout" + (dq.live_vs_supplied.agrees ? "" : " warn") }, [el("b", { text: "Live vs supplied weather. " }), `${dq.live_vs_supplied.meaning} (${dq.live_vs_supplied.days_compared} days; temperature correlation ${dq.live_vs_supplied.temp_correlation}, rain correlation ${dq.live_vs_supplied.rain_correlation}.)`]) : null]));

    if (a.ecocrop && a.ecocrop.length) root.append(card("FAO EcoCrop: does the climate and soil fit each crop?", [
      el("p", { class: "hint", text: "Each factor is scored from 0 (outside the crop's absolute limit) to 1 (inside the optimal range). The overall score is the weakest factor. This is an envelope check, independent of the water simulation, and not a yield forecast. Rainfall uses rain plus irrigation per year." }),
      table(["Crop", "Fit", "Limiting factor", "Temp", "Water", "pH", "Texture", "Drainage", "Why"], a.ecocrop.map((e) => [el("span", {}, [e.name, el("div", { class: "hint", text: e.scientific_name })]), el("span", {}, [bar(e.score), " ", f1(e.score, 2)]), e.limiting_factor || "n/a",
        ...["temperature", "rainfall", "ph", "texture", "drainage"].map((k) => (e.factors[k] == null ? "n/a" : f1(e.factors[k], 2))), el("small", { text: e.reasons.join("; ") || "All assessed factors are in the optimal range." })])),
      el("p", { class: "hint", text: "Not assessed: salinity, fertility and soil depth (no data supplied)." })]));

    if (a.local_crops) root.append(card("What is actually grown nearby (USDA CDL, Eureka County)", [
      el("p", { class: "hint", text: "Acreage from satellite classification across the whole county. It feeds the market score for fields in this region as a proxy for local demand and know-how. It is not a price or a yield." }),
      table(["Crop class", "Mean acres, last 5 years", "Share of cropland", "Trend 2015-2024 (acres/yr)", "Reliable"], a.local_crops.map((c) => [c.category, Math.round(c.mean_5y_acres).toLocaleString(), (c.share_of_cropland_5y * 100).toFixed(1) + "%", (c.trend_acres_per_year_2015_2024 >= 0 ? "+" : "") + c.trend_acres_per_year_2015_2024, c.reliable ? "yes" : "no (tiny area)"])),
      ...pack.cdl.notes.map((n) => el("p", { class: "hint", text: n }))]));
  }

  const c = pack.climatology;
  root.append(card(`Reference climate, ${pack.region.name} (NASA POWER ${c.period})`, [
    table(["", ...MONTHS], [["Temperature °C", ...c.t2m_c.map((v) => f1(v))], ["Rain mm/month", ...c.rain_mm_month.map((v) => Math.round(v))]]),
    el("p", { class: "hint", text: `Annual: ${f1(c.annual_t_c)} °C, ${c.annual_rain_mm} mm rain. ${pack.daily_vs_climatology.note}` })]));

  const pj = pack.projections;
  root.append(card("Climate projections (NASA NEX-GDDP-CMIP6, Diamond Valley)", [
    table(["Scenario", ...pj.periods.map((p) => p + " (warming, rain)")], Object.entries(pj.scenarios).map(([k, n]) => [n, ...pj.periods.map((p) => { const t = pj.table[k][p]; return `+${t.annual_delta_t_c} °C, ${t.annual_rain_change_pct >= 0 ? "+" : ""}${t.annual_rain_change_pct}%`; })])),
    el("p", { class: "hint", text: pj.method }), ...pj.caveats.map((x) => el("p", { class: "hint", text: x })), el("p", { class: "hint", text: "Apply a projection in the Climate Simulator." })]));

  root.append(card("Supplied files and how each was used", [table(["File", "Dataset", "Rows", "Coverage", "Used for", "Limits"], pack.files.map((f) => [el("small", { text: f.file }), f.dataset, f.rows, f.coverage, f.used_for, el("small", { text: f.caveat })]))]));

  const groups = {}; pack.sources.forEach((s) => (groups[s.section] = groups[s.section] || []).push(s));
  root.append(card("Source catalogue (from dataset_sources.xlsx)", Object.entries(groups).map(([g, L]) => el("div", {}, [el("h4", { text: g }), el("ul", {}, L.map((s) => el("li", {}, [el("a", { href: s.url, target: "_blank", rel: "noopener", text: s.name }), s.description ? " — " + s.description : ""])))]))));
  return root;
}
