import { el, pct, badge, catKind, toast, MONTHS } from "../ui.js";
import { gauge } from "../charts.js";
import { head, card, hypo, byLabel, cropNames } from "./common.js";

export async function render(app) {
  const base = await app.analyse(), root = el("div", { class: "page" }), out = el("div", { class: "page", style: "padding:0" });
  const st = { temp: 0, rain: 0, ps: "", pp: "2041-2060", water: app.field().water_availability || "medium" };
  const slider = (label, min, max, step, key, unit) => { const o = el("output", { text: "0" + unit }); return el("label", { class: "field" }, [el("span", { style: "display:flex;justify-content:space-between" }, [label, o]), el("input", { type: "range", min, max, step, value: 0, oninput: (e) => { st[key] = +e.target.value; o.textContent = (st[key] > 0 ? "+" : "") + st[key] + unit; } })]); };
  const seg = el("div", { class: "seg", role: "radiogroup", "aria-label": "Water availability" }, ["low", "medium", "high"].map((w) => el("button", { type: "button", role: "radio", "aria-checked": st.water === w, text: w[0].toUpperCase() + w.slice(1), onclick: () => { st.water = w; seg.querySelectorAll("button").forEach((b) => b.setAttribute("aria-checked", b.textContent.toLowerCase() === w)); } })));
  function projBox() {
    const inR = base.region && base.region.in_region;
    if (!inR) return el("p", { class: "hint", text: "Climate-model projections (NASA NEX-GDDP-CMIP6) are supplied only for Diamond Valley, Nevada. This field is outside that area, so use the sliders for what-if tests." });
    const sc = el("select", { "aria-label": "Emissions scenario", onchange: (e) => (st.ps = e.target.value) }, [["", "No projection (use sliders only)"], ["ssp126", "SSP1-2.6 low emissions"], ["ssp245", "SSP2-4.5 middle road"], ["ssp370", "SSP3-7.0 high emissions"]].map(([v, t]) => el("option", { value: v, text: t })));
    const pe = el("select", { "aria-label": "Period", onchange: (e) => (st.pp = e.target.value) }, ["2021-2040", "2041-2060", "2061-2080", "2081-2100"].map((p) => el("option", { value: p, text: p, selected: p === st.pp })));
    return el("div", { class: "callout" }, [el("b", { text: "Future climate (NASA NEX-GDDP-CMIP6, Diamond Valley). " }), "Adds the model's change from 2015-2025 to the observed weather, month by month. Sliders stack on top. ", el("div", { class: "two", style: "margin-top:8px" }, [sc, pe]),
      el("p", { class: "hint", text: "One central ensemble estimate, not a forecast. Extremes are not modelled separately." })]);
  }
  async function run() {
    out.replaceChildren(el("p", { class: "hint", text: "Re-simulating every crop under this scenario…" }));
    try {
      const sc = await app.analyse({ rain_pct: st.rain, temp_c: st.temp, water_availability: st.water, ...(st.ps ? { projection_scenario: st.ps, projection_period: st.pp } : {}) });
      if (window.FSGlobe) window.FSGlobe.setClimate({ temp: st.temp, rain: st.rain });
      const rows = base.strategies.map((b, i) => [b, sc.strategies[i]]);
      out.replaceChildren(hypo(sc), el("div", { class: "grid g2" }, [
        card("Vulnerability, current rotation", [el("div", { class: "grid g2", style: "text-align:center" }, [el("div", {}, [el("p", { class: "hint", text: "Today" }), gauge(base.vulnerability.overall, "Baseline")]), el("div", {}, [el("p", { class: "hint", text: "Scenario" }), gauge(sc.vulnerability.overall, "Scenario")])]),
          el("p", { class: "hint", text: `Change: ${(sc.vulnerability.overall - base.vulnerability.overall >= 0 ? "+" : "") + (sc.vulnerability.overall - base.vulnerability.overall).toFixed(1)} points` })]),
        card("Satellite greenness response", sc.ml_detection && sc.ml_detection.scenario_response ? [el("p", { text: `Estimated average change in greenness: ${sc.ml_detection.scenario_response.mean_change_ndvi >= 0 ? "+" : ""}${sc.ml_detection.scenario_response.mean_change_ndvi}` }),
          el("div", { class: "seqbar" }, sc.ml_detection.scenario_response.by_month.map((v, i) => el("div", { style: `background:${v < 0 ? "var(--crit)" : "var(--leaf)"};opacity:${Math.min(1, .25 + Math.abs(v) * 6)}`, title: `${MONTHS[i]} ${v}`, text: MONTHS[i][0] }))), el("p", { class: "hint", text: sc.ml_detection.scenario_response.meaning })] : [el("p", { class: "hint", text: "Not available (needs a reliable learned model and satellite data)." })])]),
        card("How each strategy holds up", [el("div", { class: "tw" }, [el("table", { class: "t" }, [el("thead", {}, [el("tr", {}, ["Strategy", "Score today", "Score in scenario", "Irrigation needed (mm/yr)", "Rain covers (%)"].map((h) => el("th", { text: h })))]),
          el("tbody", {}, rows.map(([b, s]) => { const d = s.scores.overall - b.scores.overall; return el("tr", {}, [el("td", {}, [s.label, el("div", { class: "hint", text: cropNames(s) })]), el("td", { text: pct(b.scores.overall) }), el("td", {}, [pct(s.scores.overall) + " ", badge((d >= 0 ? "+" : "") + Math.round(d * 100), d < -.03 ? "crit" : d > .03 ? "good" : "")]),
            el("td", { text: `${Math.round(b.scores.irrigation_need_mm_per_year)} → ${Math.round(s.scores.irrigation_need_mm_per_year)}` }), el("td", { text: `${Math.round(b.scores.rain_covers_pct)} → ${Math.round(s.scores.rain_covers_pct)}` })]); }))])]),
          el("p", { class: "hint", text: "Weather is shifted uniformly across every historical year, then crops are re-simulated. This shows sensitivity, not what will happen." })]));
    } catch (e) { out.replaceChildren(el("div", { class: "callout crit", text: e.message })); }
  }
  root.append(head("Climate Simulator", "Ask what-if questions. Nothing here is a forecast."),
    card("Scenario", [el("div", { class: "grid g3" }, [slider("Temperature change", -3, 5, 0.5, "temp", " °C"), slider("Rain change", -30, 30, 5, "rain", "%"), el("div", { class: "field" }, ["Water available for irrigation", seg])]),
      projBox(),
      el("div", { class: "toolbar" }, [el("button", { class: "btn solid", text: "Run scenario", onclick: run }), el("span", { class: "badge warn", text: "Hypothetical" })])]), out);
  return root;
}
