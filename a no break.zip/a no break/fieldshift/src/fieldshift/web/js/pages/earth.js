import { el, MONTHS, badge } from "../ui.js";
import { climateChart, ndviBars } from "../charts.js";
import { head, card } from "./common.js";

const LAYERS = [
  { id: "power", name: "NASA POWER weather grid", km: 27.5, color: "#5ab6ff", res: "about 50 km cell. Weather is the same across the whole circle, so neighbouring fields share these values." },
  { id: "modis", name: "MODIS greenness (NDVI)", km: 0.125, color: "#a8d08d", res: "250 m pixel. Mixed pixels near field edges can blur the signal on small fields." },
  { id: "soil", name: "SoilGrids soil texture", km: 0.125, color: "#ffc766", res: "250 m model estimate. Replace with your own soil test when you have one." },
];
export async function render(app) {
  const a = await app.analyse(), f = app.field(), mapEl = el("div", { class: "mapbox tall", id: "emap" });
  const toggles = el("div", { class: "toolbar" });
  const wrap = el("div", { class: "page" }, [head("Earth Intelligence", `What NASA and partner datasets say about ${f.name}, and how coarse each one is.`),
    el("div", { class: "grid g2" }, [card("Map and layers", [mapEl, toggles, el("p", { class: "hint", id: "resnote", text: "Toggle a layer to see its footprint and what it can and cannot tell you at field scale." })]),
      card("This location", [el("ul", { class: "list" }, [
        el("li", { text: `Coordinates: ${a.location.lat.toFixed(3)}, ${a.location.lon.toFixed(3)}` }),
        el("li", { text: a.location.elevation_m != null ? `Elevation: ${Math.round(a.location.elevation_m)} m (Copernicus DEM via Open-Meteo, single point)` : "Elevation: not available" }),
        el("li", { text: `Soil: sand ${a.data_quality.soil.sand_pct}%, clay ${a.data_quality.soil.clay_pct}%, water holding ${Math.round(a.data_quality.soil.awc_mm_per_m)} mm per m ${a.data_quality.soil.measured ? "(SoilGrids)" : "(assumed loam because SoilGrids was unreachable)"}` }),
        el("li", { text: `${a.data_quality.days.toLocaleString()} days of weather, ${a.data_quality.pct_filled}% gap-filled. ${a.climate.years_of_data} years.` }),
        el("li", { text: a.satellite ? `Satellite greenness: ${a.satellite.years_used} years of MODIS 16-day composites.` : "Satellite greenness: not retrieved. Cropping-calendar checks use the weather only." })]),
        ...a.climate.notes.map((n) => el("div", { class: "callout", text: n, style: "margin-top:8px" }))])]),
    card("Climate through the year", [climateChart(a.climate, a.climate.anomalies.monthly_risk)]),
    a.satellite ? card("What satellites see: greenness by month", [ndviBars(a.satellite), el("p", { class: "hint", text: a.satellite.bare_months.length ? `Low-greenness months: ${a.satellite.bare_months.join(", ")}. This is observed, not assumed.` : "The land stays green all year." })]) : null,
    card("Dataset status", [el("div", { class: "tw" }, [el("table", { class: "t" }, [el("thead", {}, [el("tr", {}, ["Dataset", "Agency", "Provides", "Resolution", "Status"].map((h) => el("th", { text: h })))]),
      el("tbody", {}, a.datasets.map((d) => el("tr", {}, [el("td", { text: d.name }), el("td", { text: d.agency }), el("td", { text: d.provides }), el("td", { text: d.resolution }),
        el("td", {}, [badge(d.status === "live" ? "Live" : d.status === "fallback" ? "Fallback" : d.status === "not_connected" ? "Not connected" : "Unavailable", d.status === "live" ? "good" : d.status === "fallback" ? "warn" : ""), el("div", { class: "hint", text: d.note })])])))])]),
      el("p", { class: "hint", text: "Datasets marked Not connected need a free NASA Earthdata login and are not used in any score. They are listed so you can see what could be added." })])]);
  wrap._init = () => {
    if (!window.L) { mapEl.replaceChildren(el("p", { class: "hint", style: "padding:16px", text: "The map library did not load." })); return; }
    const map = L.map(mapEl).setView([f.lat, f.lon], 8);
    const osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap", maxZoom: 19 }).addTo(map);
    const sat = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", { attribution: "Esri World Imagery", maxZoom: 19 });
    const topo = L.tileLayer("https://tile.opentopomap.org/{z}/{x}/{y}.png", { attribution: "OpenTopoMap", maxZoom: 17 });
    L.control.layers({ Street: osm, Satellite: sat, Terrain: topo }).addTo(map);
    L.circleMarker([f.lat, f.lon], { radius: 7, color: "#fff", fillColor: "#f2a65a", fillOpacity: 1 }).addTo(map).bindTooltip(f.name);
    if (f.boundary && f.boundary.coordinates) L.polygon(f.boundary.coordinates[0].map((p) => [p[1], p[0]]), { color: "#f2a65a" }).addTo(map);
    const on = {}, circles = {};
    LAYERS.forEach((l) => {
      circles[l.id] = L.circle([f.lat, f.lon], { radius: l.km * 1000, color: l.color, weight: 2, fillOpacity: .12 });
      toggles.appendChild(el("label", { class: "check" }, [el("input", { type: "checkbox", onchange: (e) => { if (e.target.checked) { circles[l.id].addTo(map); document.getElementById("resnote").textContent = `${l.name}: ${l.res}`; if (l.km > 5) map.fitBounds(circles[l.id].getBounds()); } else map.removeLayer(circles[l.id]); } }), " " + l.name]));
    });
    setTimeout(() => map.invalidateSize(), 100);
  };
  return wrap;
}
export function after(n) { if (n._init) n._init(); }
