import { el, svg, toast } from "../ui.js";
import { api } from "../api.js";

const GOALS = [["water", "Save water"], ["soil", "Healthier soil"], ["income", "Higher income"], ["fodder", "Fodder for livestock"], ["balanced", "A bit of everything"]];
export const GOAL_PRI = { water: { water: 5, nfix: 3, erosion: 3, om: 3, forage: 1, market: 2 }, soil: { water: 3, nfix: 5, erosion: 5, om: 5, forage: 1, market: 2 }, income: { water: 3, nfix: 2, erosion: 2, om: 2, forage: 1, market: 5 }, fodder: { water: 3, nfix: 3, erosion: 3, om: 3, forage: 5, market: 2 }, balanced: { water: 3, nfix: 3, erosion: 3, om: 3, forage: 2, market: 3 } };

function strength(p) {
  let s = 0; if (p.length >= 8) s++; if (p.length >= 12) s++; if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++; if (/\d/.test(p)) s++; if (/[^A-Za-z0-9]/.test(p)) s++;
  return Math.min(s, 4);
}

export async function render(app) {
  if (app.user) { app.go("dashboard"); return el("div"); }
  const st = { step: 1, mode: "login", prof: { experience: "", main_goal: "", water_source: "" } };
  const card = el("div", { class: "auth-card" });
  const steps = () => el("div", { class: "steps" }, [1, 2].map((i) => el("i", { class: i <= st.step ? "on" : "" })));
  const err = el("p", { class: "hint", role: "alert", style: "color:var(--crit);min-height:1.2em;margin:0" });
  const chip = (list, key) => el("div", { class: "chips" }, list.map(([v, l]) => el("button", { type: "button", "aria-pressed": st.prof[key] === v, text: l, onclick: (e) => { st.prof[key] = v; e.target.parentNode.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", b === e.target)); } })));

  function step1() {
    const create = st.mode === "signup";
    const name = el("input", { type: "text", placeholder: "Your name", autocomplete: "name", maxlength: 80, "aria-label": "Your name" });
    const email = el("input", { type: "email", placeholder: "you@example.com", autocomplete: "email", required: true, "aria-label": "Email address" });
    const pw = el("input", { type: "password", placeholder: create ? "Choose a password (8+ characters)" : "Password", autocomplete: create ? "new-password" : "current-password", required: true, minlength: create ? 8 : 1, "aria-label": "Password" });
    const show = el("button", { type: "button", text: "Show", onclick: () => { const h = pw.type === "password"; pw.type = h ? "text" : "password"; show.textContent = h ? "Hide" : "Show"; } });
    const bar = el("i"), meter = el("div", { class: "strength" }, [bar]);
    pw.addEventListener("input", () => { const s = strength(pw.value); bar.style.width = (s / 4 * 100) + "%"; bar.style.background = ["#ff7b8a", "#ff7b8a", "#ffc766", "#a8d08d", "#a8d08d"][s]; });
    card.replaceChildren(el("h2", { text: create ? "Create your account" : "Welcome back" }), el("p", { class: "sub", text: create ? "Your fields, history and chats are saved to your account so TerraAdapt remembers you." : "Sign in to see your saved fields and pick up where you left off." }),
      el("div", { class: "seg", role: "radiogroup" }, [["login", "Sign in"], ["signup", "Create account"]].map(([v, l]) => el("button", { type: "button", role: "radio", "aria-checked": st.mode === v, text: l, onclick: () => { st.mode = v; step1(); } }))),
      el("form", { style: "display:grid;gap:12px", onsubmit: async (e) => {
        e.preventDefault(); err.textContent = ""; const b = e.target.querySelector("button[type=submit]"); b.disabled = true; const t0 = b.textContent; b.textContent = create ? "Creating…" : "Signing in…";
        try {
          const r = create ? await api.signup(email.value, pw.value, name.value) : await api.login(email.value, pw.value);
          await app.setUser(r.user); toast(create ? "Account created." : "Welcome back.");
          if (create) { st.step = 2; step2(); } else app.go(app.fields.length > 1 ? "dashboard" : "fields");
        } catch (ex) { err.textContent = ex.message; b.disabled = false; b.textContent = t0; }
      } }, [create ? name : null, email, el("div", { class: "pwrow" }, [pw, show]), create ? meter : null, el("button", { class: "btn solid", type: "submit", text: create ? "Create account" : "Sign in", style: "padding:12px" })].filter(Boolean)), err,
      !create ? el("p", { class: "hint", text: "Forgot your password? There is no email service connected, so ask whoever runs this server to run: python -m fieldshift.reset_password your@email" }) : null,
      el("a", { href: "#/dashboard", class: "hint", text: "Look around the demo without signing in →", style: "text-align:center" }));
    setTimeout(() => (create ? name : email).focus(), 60);
  }
  function step2() {
    const region = el("input", { type: "text", placeholder: "Village / district / state or country", maxlength: 120, "aria-label": "Where you farm" }), size = el("input", { type: "number", min: 0, step: "any", placeholder: "Total farm size in hectares (optional)", "aria-label": "Farm size in hectares" });
    card.replaceChildren(steps(), el("h2", { text: `Nice to meet you${app.first() ? ", " + app.first() : ""}` }), el("p", { class: "sub", text: "A few answers so advice fits your farm. You can change them any time under Profile." }),
      el("form", { style: "display:grid;gap:12px", onsubmit: async (e) => {
        e.preventDefault();
        try { await api.updateMe({ profile: { region: region.value.trim(), farm_size_ha: size.value ? +size.value : "", experience: st.prof.experience, main_goal: st.prof.main_goal, water_source: st.prof.water_source } });
          const me = await api.me(); await app.setUser(me.user); app.go("fields"); toast("Saved. Now add your first field."); } catch (ex) { err.textContent = ex.message; }
      } }, [region, size,
        el("p", { class: "hint", text: "Farming experience", style: "margin:2px 0 -6px" }), chip([["beginner", "Just starting"], ["some", "A few seasons"], ["experienced", "Experienced"]], "experience"),
        el("p", { class: "hint", text: "What matters most?", style: "margin:2px 0 -6px" }), chip(GOALS, "main_goal"),
        el("p", { class: "hint", text: "Water source", style: "margin:2px 0 -6px" }), chip([["rain", "Rain only"], ["well", "Well / borewell"], ["canal", "Canal / river"], ["mixed", "Mixed"]], "water_source"),
        el("button", { class: "btn solid", type: "submit", text: "Save and add my first field", style: "padding:12px" }),
        el("button", { class: "btn", type: "button", text: "Skip for now", onclick: () => app.go("fields") })]), err);
    setTimeout(() => region.focus(), 60);
  }
  step1();
  const orbit = svg("svg", { class: "orbit", viewBox: "-100 -100 200 200" });
  orbit.innerHTML = `<defs><linearGradient id="og" x1="0" x2="1"><stop offset="0" stop-color="#f2a65a"/><stop offset="1" stop-color="#8f7bff"/></linearGradient></defs>
    <g><ellipse rx="92" ry="34" fill="none" stroke="url(#og)" stroke-width="1.6"/></g><g><ellipse rx="92" ry="34" transform="rotate(60)" fill="none" stroke="#f2a65a" stroke-opacity=".6" stroke-width="1.2"/></g>
    <g><ellipse rx="92" ry="34" transform="rotate(120)" fill="none" stroke="#8f7bff" stroke-opacity=".7" stroke-width="1.2"/></g><circle r="22" fill="none" stroke="url(#og)" stroke-width="2"/><circle r="6" fill="#f2a65a"/>`;
  const contours = svg("svg", { class: "contours", viewBox: "0 0 600 800", preserveAspectRatio: "xMidYMid slice" });
  contours.innerHTML = [...Array(14)].map((_, i) => `<path d="M-20 ${60 + i * 52} C 120 ${20 + i * 52}, 220 ${110 + i * 52}, 340 ${60 + i * 52} S 560 ${10 + i * 52}, 640 ${70 + i * 52}" fill="none" stroke="#f2a65a" stroke-opacity=".45" stroke-width="1"/>`).join("");
  const art = el("div", { class: "auth-art", onpointermove: (e) => { const r = e.currentTarget.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; art.querySelectorAll(".blob").forEach((b, i) => (b.style.translate = `${x * (40 + i * 26)}px ${y * (40 + i * 26)}px`)); orbit.style.translate = `${x * -30}px ${y * -30}px`; } }, [
    el("div", { class: "blob b1" }), el("div", { class: "blob b2" }), el("div", { class: "blob b3" }), contours, orbit,
    el("h1", { text: "Know your land. Plan your season." }), el("p", { text: "NASA weather and satellite records, the next 16 days of forecast, and your own field history, in one place that remembers you." }),
    el("ul", {}, [el("li", { text: "Weather outlook for every field" }), el("li", { text: "Rotations compared with uncertainty" }), el("li", { text: "An assistant that knows your fields" })])]);
  return el("div", { class: "auth" }, [art, el("div", { class: "auth-side" }, [card])]);
}
