import { el, badge, loading, errorBox } from "../ui.js";
import { api } from "../api.js";
import { forecastChart } from "../charts.js";
import { head, card, kpi } from "./common.js";

const SEV = { crit: "Act soon", warn: "Watch", info: "Good to know" };
export async function render(app) {
  const f = app.field(), root = el("div", { class: "page" }), body = el("div", { class: "page", style: "padding:0" });
  root.append(head("Weather Outlook", `${f.name}: the next 16 days, compared with this field's 25-year NASA normals and the latest satellite state.`, el("button", { class: "btn", text: "Refresh", onclick: load })), body);
  async function load() {
    body.replaceChildren(loading("Fetching the 16-day forecast…"));
    try {
      const o = await api.forecast(f.id), st = o.stats;
      const top = o.actions.find((a) => a.severity !== "info");
      body.replaceChildren(
        el("div", { class: "lvl " + o.level }, [el("b", { text: o.level }), el("div", {}, [el("div", { style: "font-weight:600", text: top ? top.title : "Nothing unusual in the forecast for this field." }),
          el("div", { class: "hint", text: o.crop_now ? `Judged for what is growing now: ${o.crop_now}.` : "No crop is growing in your current rotation this month, so the field is treated as bare." })])]),
        el("div", { class: "grid g4" }, [
          kpi(`${st.rain_next7_mm.toFixed(0)} mm`, "Rain, next 7 days", st.normal_rain_next7_mm != null ? `Normal for these dates: ${st.normal_rain_next7_mm.toFixed(0)} mm` : ""),
          kpi(st.tmax_next7_c != null ? `${st.tmax_next7_c.toFixed(0)} °C` : "n/a", "Average high, next 7 days", st.normal_tmax_next7_c != null ? `Normal: ${st.normal_tmax_next7_c.toFixed(0)} °C` : ""),
          kpi(`${st.longest_dry_run_days} days`, "Longest dry run in 16 days", "Days under 1 mm of rain"),
          kpi(`${st.water_gap_16d_mm.toFixed(0)} mm`, "Water gap over 16 days", `Crop use about ${st.crop_water_use_16d_mm.toFixed(0)} mm vs ${st.rain_next16_mm.toFixed(0)} mm rain`)]),
        card("Day by day", [forecastChart(o.days, st), el("p", { class: "hint", text: o.confidence_note })]),
        card("What this means for your field", o.actions.length ? o.actions.map((a) => el("div", { class: "act " + a.severity, style: "margin-bottom:10px" }, [el("div", {}, [badge(SEV[a.severity], a.severity === "crit" ? "crit" : a.severity === "warn" ? "warn" : "good"), " ", el("b", { text: a.title })]), el("div", { class: "why", text: a.evidence }), a.action ? el("div", { class: "do", text: a.action }) : null])) : [el("p", { text: "No action needed from the forecast alone." })]),
        el("div", { class: "callout" }, [el("b", { text: "Where this comes from. " }), `Forecast: ${o.source}, fetched ${o.fetched_at}. This is not NASA data. NASA POWER supplies the 25-year normals it is compared with, and the satellite check uses the MODIS record. `, o.satellite ? `Latest usable satellite reading: ${o.satellite.date}, difference from expected ${o.satellite.gap_ndvi >= 0 ? "+" : ""}${o.satellite.gap_ndvi}.` : "No reliable satellite comparison was available, so only weather rules were applied.", " ", o.method]));
    } catch (e) { body.replaceChildren(errorBox(e.message, load)); }
  }
  load();
  return root;
}
