import { el, toast, pct } from "../ui.js";
import { api } from "../api.js";
import { head, card } from "./common.js";
import { GOAL_PRI } from "./login.js";

const PRI = [["water", "Save water"], ["nfix", "Fix nitrogen"], ["erosion", "Protect soil from erosion"], ["om", "Build organic matter"], ["forage", "Livestock fodder"], ["market", "Market value"], ["stability", "Stable yields"]];
const KM2 = (lat) => 111.32 * Math.cos(lat * Math.PI / 180);
function areaHa(ring) {   // local equirectangular approximation, fine for field scale
  if (ring.length < 3) return 0; const la0 = ring.reduce((s, p) => s + p[1], 0) / ring.length, kx = KM2(la0) * 1000, ky = 110.57 * 1000; let s = 0;
  for (let i = 0; i < ring.length; i++) { const [x1, y1] = [ring[i][0] * kx, ring[i][1] * ky], [x2, y2] = [ring[(i + 1) % ring.length][0] * kx, ring[(i + 1) % ring.length][1] * ky]; s += x1 * y2 - x2 * y1; }
  return Math.abs(s) / 2 / 10000;
}

export async function render(app) {
  const guest = !app.user;
  const wrap = el("div", { class: "page" }), q = new URLSearchParams(location.hash.split("?")[1] || "");
  let editing = q.get("lat") || app.field().id === "demo-field" ? null : app.field(), draft;
  const list = el("div", { class: "grid g3" }), formHost = el("div");
  const blank = () => ({ farm: "My farm", name: "", lat: parseFloat(q.get("lat")) || 20, lon: parseFloat(q.get("lon")) || 78, area_ha: null, soil: "auto", irrigation_mm: 0, water_availability: "medium", current: ["wheat", "chickpea"], history: [], priorities: { ...(GOAL_PRI[app.user && app.user.profile.main_goal] || { water: 3, nfix: 3, erosion: 3, om: 3, forage: 1, market: 3 }) }, soil_test: {}, boundary: null, note: "" });

  function drawList() {
    list.replaceChildren(...app.fields.map((f) => el("div", { class: "card fieldcard" + (f.id === app.fieldId ? " on" : ""), onclick: () => { app.fieldId = f.id; editing = f; app.drawFieldSelect(); drawList(); drawForm(); } }, [
      el("h3", { text: f.name, style: "font-size:17px" }), el("p", { class: "sub", text: `${f.farm}` }), el("p", { class: "hint", text: `${f.lat.toFixed(3)}, ${f.lon.toFixed(3)} · ${f.current.join(" → ")}${f.area_ha ? " · " + f.area_ha + " ha" : ""}` })])));
    list.appendChild(el("button", { class: "card fieldcard", style: "border-style:dashed;text-align:center;color:var(--accent);font-weight:700", onclick: () => { editing = null; drawForm(); }, text: "+ New field" }));
  }

  function drawForm() {
    draft = JSON.parse(JSON.stringify(editing || blank())); const isNew = !editing, isDemo = editing && editing.id === "demo-field";
    const inp = (label, key, type = "text", extra = {}) => el("label", { class: "field" }, [label, el("input", { type, value: draft[key] ?? "", step: "any", oninput: (e) => { draft[key] = type === "number" ? (e.target.value === "" ? null : parseFloat(e.target.value)) : e.target.value; if (key === "lat" || key === "lon") moveMarker(); }, ...extra })]);
    const sel = (label, key, opts) => el("label", { class: "field" }, [label, el("select", { onchange: (e) => (draft[key] = e.target.value) }, opts.map(([v, t]) => el("option", { value: v, text: t, selected: draft[key] === v })))]);
    const cropSel = (i) => el("select", { "aria-label": `Crop ${i + 1}`, onchange: (e) => (draft.current[i] = e.target.value) }, app.crops.map((c) => el("option", { value: c.id, text: c.name, selected: draft.current[i] === c.id })));
    const priHost = el("div", { style: "display:grid;gap:8px" });
    const dflt = (k) => (k === "stability" ? 0 : 3);
    const drawPriSliders = () => priHost.replaceChildren(...PRI.map(([k, l]) => { const v = draft.priorities[k] ?? dflt(k), out = el("output", { text: v }); return el("label", { class: "field" }, [el("span", { style: "display:flex;justify-content:space-between" }, [l, out]), el("input", { type: "range", min: 0, max: 5, step: 1, value: v, oninput: (e) => { draft.priorities[k] = +e.target.value; out.textContent = e.target.value; } })]); }));
    drawPriSliders();
    const mapEl = el("div", { class: "mapbox tall", id: "fmap" }), info = el("p", { class: "hint", text: "Click the map to place the field. Use Draw boundary to outline it." });
    const areaIn = inp("Area (hectares)", "area_ha", "number"), soc = el("input", { type: "number", step: "any", value: draft.soil_test.organic_carbon_pct ?? "", oninput: (e) => setSoil("organic_carbon_pct", e.target.value) }), ph = el("input", { type: "number", step: "any", value: draft.soil_test.ph ?? "", oninput: (e) => setSoil("ph", e.target.value) });
    const setSoil = (k, v) => { if (v === "") delete draft.soil_test[k]; else draft.soil_test[k] = parseFloat(v); };
    const msg = el("p", { class: "hint", role: "status" });
    const soilSel = () => {
      const s = el("select", { onchange: (e) => (draft.soil = e.target.value) }, [["auto", "Detect from SoilGrids"], ["loam", "Loam"], ["clay", "Clay"], ["sandy", "Sandy"]].map(([v, t]) => el("option", { value: v, text: t, selected: draft.soil === v })));
      const note = el("span", { class: "hint", text: "" });
      api.soils().then((L) => {
        const g = el("optgroup", { label: "USDA SSURGO map units (Diamond Valley, Nevada only)" }, L.filter((x) => x.usable).map((x) => el("option", { value: x.id, text: `${x.musym} · ${x.name} (sand ${x.sand_pct}%, clay ${x.clay_pct}%)`, selected: draft.soil === x.id })));
        s.appendChild(g); if (draft.soil && draft.soil.startsWith("ssurgo:")) s.value = draft.soil;
      }).catch(() => {});
      const upd = () => api.region(draft.lat, draft.lon).then((r) => { note.textContent = r.in_region ? "SSURGO map units apply near Diamond Valley. Pick the unit that matches your field." : "SSURGO map units are for Diamond Valley only; elsewhere use Detect or pick a type."; }).catch(() => {});
      upd();
      return el("label", { class: "field" }, ["Soil type", s, note]);
    };
    const impBox = el("div", { class: "callout" }, [el("b", { text: "Farmer priorities file" }), " ", el("a", { href: "/api/priorities/template", text: "Download the template" }), " (CSV), fill it in, then upload it here. ",
      el("input", { type: "file", accept: ".csv,text/csv", "aria-label": "Upload priorities CSV", onchange: async (e) => {
        const file = e.target.files[0]; if (!file) return;
        try {
          const r = await api.parsePriorities(await file.text());
          draft.priorities = { ...draft.priorities, ...r.priorities }; draft.constraints = { ...(draft.constraints || {}), ...r.constraints };
          const hist = (r.constraints.history || []).map((h) => h.crop); if (hist.length) draft.history = hist;
          rep.replaceChildren(el("p", { class: "hint", text: "Applied to the analysis (press Save to keep):" }), el("ul", {}, r.applied.map((x) => el("li", { text: `${x.row}: ${x.effect}` }))),
            r.not_modelled.length ? el("p", { class: "hint", text: "Recorded but not modelled:" }) : null, r.not_modelled.length ? el("ul", {}, r.not_modelled.map((x) => el("li", { text: `${x.row}: ${x.why}` }))) : null,
            r.warnings.length ? el("p", { class: "hint", style: "color:var(--crit)", text: r.warnings.join(" ") }) : null);
          drawPriSliders();
        } catch (er) { rep.replaceChildren(el("p", { class: "hint", style: "color:var(--crit)", text: er.message })); }
      } })]);
    const rep = el("div");
    const form = el("form", { class: "grid g2", onsubmit: async (e) => {
      e.preventDefault(); msg.textContent = "Saving…";
      try {
        const body = { ...draft }; delete body.created_at; delete body.updated_at;
        if (typeof body.history === "string") body.history = body.history.split(",").map((s) => s.trim()).filter(Boolean);
        if (isDemo) { delete body.id; }
        const saved = await api.saveField(isDemo ? body : body); await app.reloadFields(saved.id); toast("Field saved. Analysing it now."); app.go("dashboard");
      } catch (err) { msg.textContent = err.message; msg.style.color = "var(--crit)"; }
    } }, [
      el("div", { style: "display:grid;gap:0;align-content:start" }, [
        inp("Farm name", "farm"), inp("Field name", "name", "text", { required: true, maxlength: 120 }),
        el("button", { class: "btn", type: "button", text: "Use my current location", style: "margin:2px 0 10px", onclick: (e) => {
          const b = e.currentTarget; if (!navigator.geolocation) { toast("This browser cannot share location. Enter coordinates or click the map."); return; }
          b.disabled = true; b.textContent = "Locating…";
          navigator.geolocation.getCurrentPosition((p) => {
            draft.lat = +p.coords.latitude.toFixed(5); draft.lon = +p.coords.longitude.toFixed(5);
            const ins = document.querySelectorAll("form input[type=number]"); ins[0].value = draft.lat; ins[1].value = draft.lon;
            if (map) { map.setView([draft.lat, draft.lon], 15); marker.setLatLng([draft.lat, draft.lon]); }
            b.disabled = false; b.textContent = "Use my current location"; toast(`Location set (accuracy about ${Math.round(p.coords.accuracy)} m). Stand in the field, or adjust on the map.`);
          }, (er) => { b.disabled = false; b.textContent = "Use my current location"; toast(er.code === 1 ? "Location permission was blocked. Allow it in the browser address bar, or click the map." : "Could not get your location. Click the map instead."); }, { enableHighAccuracy: true, timeout: 15000 });
        } }),
        el("div", { class: "two" }, [inp("Latitude", "lat", "number", { min: -90, max: 90, required: true }), inp("Longitude", "lon", "number", { min: -180, max: 180, required: true })]),
        areaIn, soilSel(),
        el("div", { class: "two" }, [inp("Irrigation (mm / year)", "irrigation_mm", "number", { min: 0, max: 3000 }), sel("Water availability", "water_availability", [["low", "Low"], ["medium", "Medium"], ["high", "High"]])]),
        el("label", { class: "field" }, ["Current rotation (first crop, second crop)", el("div", { class: "two" }, [cropSel(0), cropSel(1)])]),
        el("label", { class: "field" }, ["Crop history (comma separated, optional)", el("input", { type: "text", value: (draft.history || []).join(", "), oninput: (e) => (draft.history = e.target.value.split(",").map((s) => s.trim()).filter(Boolean)) })]),
        el("div", { class: "two" }, [el("label", { class: "field" }, ["Soil organic carbon % (soil test)", soc]), el("label", { class: "field" }, ["Soil pH (soil test)", ph])]),
        el("span", { class: "hint", text: "Soil test values are optional. They sharpen the soil-fertility score and are never invented." })]),
      el("div", { style: "display:grid;gap:8px;align-content:start" }, [mapEl, info, el("div", { class: "toolbar", id: "drawbar" }), el("h4", { text: "What matters most? (0 to 5)" }), priHost, impBox, rep, el("label", { class: "field" }, ["Notes", el("textarea", { rows: 2, oninput: (e) => (draft.note = e.target.value) }, draft.note || "")]),
        el("div", { class: "toolbar" }, [el("button", { class: "btn solid", type: "submit", text: isNew ? "Create and analyse" : "Save and analyse" }),
          !isNew && !isDemo ? el("button", { class: "btn", type: "button", text: "Delete field", onclick: async () => { if (!confirm("Delete this field?")) return; await api.deleteField(editing.id); await app.reloadFields(); toast("Field deleted."); editing = app.field(); drawList(); drawForm(); } }) : null]), msg])]);
    formHost.replaceChildren(card(isNew ? "New field" : isDemo ? "Demonstration field (saving makes your own copy)" : "Edit field", [form]));
    setTimeout(() => initMap(mapEl, info, areaIn), 0);
  }

  let map, marker, poly, verts = [], drawing = false, layer;
  function moveMarker() { if (map && marker && isFinite(draft.lat) && isFinite(draft.lon)) { marker.setLatLng([draft.lat, draft.lon]); map.panTo([draft.lat, draft.lon]); } }
  function initMap(host, info, areaIn) {
    if (!window.L) { host.replaceChildren(el("p", { class: "hint", style: "padding:16px", text: "The map library did not load. You can still type coordinates." })); return; }
    if (map) { map.remove(); } 
    map = L.map(host).setView([draft.lat, draft.lon], draft.boundary ? 15 : 6);
    const osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap", maxZoom: 19 });
    const sat = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", { attribution: "Esri World Imagery", maxZoom: 19 });
    osm.addTo(map); L.control.layers({ Street: osm, Satellite: sat }).addTo(map);
    marker = L.circleMarker([draft.lat, draft.lon], { radius: 8, color: "#f2a65a", fillColor: "#f2a65a", fillOpacity: .8 }).addTo(map);
    layer = L.layerGroup().addTo(map); verts = []; drawing = false;
    if (draft.boundary && draft.boundary.coordinates) { verts = draft.boundary.coordinates[0].slice(0, -1).map((p) => [p[1], p[0]]); redraw(); map.fitBounds(L.polygon(verts).getBounds().pad(.3)); }
    const bar = document.getElementById("drawbar"), btn = (t, fn) => el("button", { class: "btn", type: "button", text: t, onclick: fn });
    const paint = () => bar.replaceChildren(drawing ? btn("Finish boundary", finish) : btn("Draw boundary", () => { drawing = true; verts = []; redraw(); info.textContent = "Click each corner of the field, then press Finish boundary."; paint(); }), btn("Clear boundary", () => { drawing = false; verts = []; draft.boundary = null; redraw(); paint(); }));
    const finish = () => {
      drawing = false; if (verts.length < 3) { info.textContent = "A boundary needs at least 3 corners."; paint(); return; }
      const ring = verts.map((v) => [+v[1].toFixed(6), +v[0].toFixed(6)]); draft.boundary = { type: "Polygon", coordinates: [[...ring, ring[0]]] };
      const ha = +areaHa(ring).toFixed(2); draft.area_ha = ha; areaIn.querySelector("input").value = ha;
      const cx = ring.reduce((s, p) => s + p[0], 0) / ring.length, cy = ring.reduce((s, p) => s + p[1], 0) / ring.length; draft.lat = +cy.toFixed(5); draft.lon = +cx.toFixed(5);
      document.querySelectorAll("form input[type=number]").forEach((i) => {}); info.textContent = `Boundary saved: ${ha} ha. Field centre set to ${draft.lat}, ${draft.lon}.`; marker.setLatLng([draft.lat, draft.lon]); redraw(); paint();
    };
    map.on("click", (e) => {
      if (drawing) { verts.push([e.latlng.lat, e.latlng.lng]); redraw(); return; }
      draft.lat = +e.latlng.lat.toFixed(5); draft.lon = +e.latlng.lng.toFixed(5); marker.setLatLng(e.latlng);
      const ins = document.querySelectorAll("form input[type=number]"); ins[0].value = draft.lat; ins[1].value = draft.lon;
    });
    paint();
  }
  function redraw() { layer.clearLayers(); if (verts.length) { (verts.length > 2 ? L.polygon(verts, { color: "#ffc766", fillOpacity: .25 }) : L.polyline(verts, { color: "#ffc766" })).addTo(layer); verts.forEach((v) => L.circleMarker(v, { radius: 4, color: "#ffc766" }).addTo(layer)); } }

  wrap.append(...[head("My Fields", "Create fields with a location, optional boundary, soil, water and goals. Every analysis uses the field's own coordinates. Saved fields are remembered for next time."),
    guest ? el("div", { class: "callout warn" }, [el("b", { text: "You are looking at the demo. " }), "Sign in to save your own fields. I will remember each one: Field 1, Field 2 and so on. ", el("a", { class: "btn solid", href: "#/login", text: "Sign in", style: "margin-left:8px" })]) : null, list, guest ? el("span") : formHost].filter(Boolean));
  drawList(); if (!guest) drawForm();
  return wrap;
}
