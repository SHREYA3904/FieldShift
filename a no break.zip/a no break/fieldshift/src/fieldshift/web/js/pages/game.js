import { el, svg, toast, MONTHS } from "../ui.js";
import { api } from "../api.js";
import { head, card } from "./common.js";
import { buildScene, draw, kindOf, stageLabel } from "../plants.js";
import { speak, translateLine } from "../terra.js";
import { lang } from "../i18n.js";
import { store } from "../api.js";
import { emoji, finishJourney, saveJourneyField } from "../journey.js";

const NS = "http://www.w3.org/2000/svg";
const dateLabel = (m, d, off) => { const t = new Date(Date.UTC(2001, m - 1, d + off)); return `${t.getUTCDate()} ${MONTHS[t.getUTCMonth()]}`; };
const lerp = (a, b, t) => Math.round(a + (b - a) * t);
const mix = (c1, c2, t) => `rgb(${lerp(c1[0], c2[0], t)},${lerp(c1[1], c2[1], t)},${lerp(c1[2], c2[2], t)})`;

export async function render(app) {
  const J = app.journey, root = el("div", { class: "page" }), f = J ? { id: J.fieldId, name: J.name } : app.field();
  root.append(J ? head(`${J.name}: what will happen?`, J.place ? `${J.place} · real NASA weather of your spot` : "Real NASA weather of your spot") : head("Season Challenge", "Replay a real past growing season from your field's NASA weather. You decide when to irrigate. Can you beat the autopilot?"));
  const crops = await api.gameCrops();
  const st = { crop: "wheat", month: ((new Date().getMonth() + 1) % 12) + 1, day: 15, caseNo: Math.floor(Math.random() * 50), doses: [], covers: [], scouts: [], mulch: null, now: 0, data: null, busy: false, auto: false, worst: false };
  if (J) { st.crop = J.crop; st.month = J.month; st.day = 15; document.body.classList.add("journeying"); }
  let voiceOn = store.get("ta-gamevoice", "1") === "1";
  const stage = el("div"); root.append(stage);

  async function call(extra = {}) {
    return api.game({ field_id: f.id, crop: st.crop, month: st.month, day: st.day, case: st.caseNo, doses: st.doses, covers: st.covers, scouts: st.scouts, mulch: st.mulch, auto: st.auto, worst: st.worst, ...extra });
  }
  const EMO = { wheat: "🌾", barley: "🌾", maize: "🌽", rice: "🌾", sorghum: "🌾", soybean: "🫘", groundnut: "🥜", chickpea: "🫘", pea: "🫛", mustard: "🌼", sunflower: "🌻", cotton: "☁️", potato: "🥔", alfalfa: "🌿", oats: "🌾", rye: "🌾", lentil: "🫘", canola: "🌼", proso_millet: "🌾", foxtail_millet: "🌾", apple: "🍎", grape: "🍇", tomato: "🍅" };
  function timeline(o, tl) {
    const n = Math.min(12, Math.max(1, Math.ceil((14 + o.season_days) / 30.4))), idx = Array.from({ length: n }, (_, k) => (st.month - 1 + k) % 12);
    tl.replaceChildren(el("div", { class: "tmonths" }, MONTHS.map((m, i) => { const k = idx.indexOf(i); const cls = k < 0 ? "off" : k === 0 ? "sow" : k === n - 1 ? "harv" : "grow"; return el("div", { class: "tm " + cls, style: `--k:${k < 0 ? 0 : k}` }, [el("small", { text: m }), el("span", { text: k === 0 ? "🌱" : k === n - 1 ? "🌾" : k > 0 ? "🌿" : "" })]); })),
      el("p", { class: "tcap", text: `Sow in ${MONTHS[idx[0]]} · harvest around ${MONTHS[idx[n - 1]]} · about ${o.season_days} days` }));
  }
  async function outlook(box, tl) {
    box.replaceChildren(el("p", { class: "hint", text: "Checking 25 years of your field's weather…" })); tl.replaceChildren();
    try {
      const o = await api.gameOutlook({ field_id: f.id, crop: st.crop, month: st.month, day: st.day });
      const col = { good: "#7bd88f", risky: "#f2c05a", poor: "#ef7a6a" }[o.verdict], ic = { good: "👍", risky: "⚠️", poor: "👎" }[o.verdict];
      if (o.season_days) timeline(o, tl);
      box.replaceChildren(el("div", { class: "callout", style: `border-left:4px solid ${col}` }, [el("b", { text: `${ic} ${o.headline}` }), el("p", { text: o.why }), o.place ? el("p", { class: "hint", text: `Weather used: ${o.place.source}. Field "${o.place.name}" at ${o.place.lat}°, ${o.place.lon}°. In ${o.place.years} years the coldest night was ${o.place.coldest_c} °C and the hottest day ${o.place.hottest_c} °C. If this is not your place, fix the field location in My Farm.` }) : null, o.note ? el("small", { text: o.note }) : null]));
    } catch (e) { box.replaceChildren(el("p", { class: "hint", text: e.message })); }
  }
  function setup() {
    const box = el("div", { role: "status" }), tl = el("div", { class: "tline" });
    const pick = (list, b) => list.forEach((x) => x.classList.toggle("on", x === b));
    const cropBtns = crops.map((c) => { const b = el("button", { type: "button", class: "cpick" + (c.id === st.crop ? " on" : ""), onclick: () => { st.crop = c.id; pick(cropBtns, b); outlook(box, tl); } }, [el("span", { class: "ce", text: EMO[c.id] || "🌱" }), el("small", { text: c.name })]); return b; });
    const monthBtns = MONTHS.map((m, i) => { const b = el("button", { type: "button", class: "mpick" + (i + 1 === st.month ? " on" : ""), text: m, onclick: () => { st.month = i + 1; pick(monthBtns, b); outlook(box, tl); } }); return b; });
    const how = el("div", { class: "hows" }, [["🌱", "1. Pick a crop and a month"], ["💧", "2. Every week: water it, or wait"], ["🌾", "3. Harvest and see your score"]].map(([ic, t], i) => el("div", { class: "how", style: `animation-delay:${i * 0.25}s` }, [el("span", { text: ic }), el("b", { text: t })])));
    stage.replaceChildren(card("A season, step by step", [how,
      el("h4", { text: "1. What do you want to grow?" }), el("div", { class: "cgrid" }, cropBtns),
      el("h4", { text: "2. In which month do you plant?" }), el("div", { class: "mgrid" }, monthBtns),
      el("h4", { text: "3. Your season" }), tl, box,
      el("div", { class: "toolbar" }, [el("button", { class: "btn solid big", text: "🎮 Play it myself", onclick: () => { st.auto = false; start(); } }), el("button", { class: "btn big", text: "🎬 Watch as a video (slow)", onclick: () => { st.auto = true; start(); } })]),
      el("p", { class: "hint", text: "Play: you have 6 irrigation doses of 25 mm and the year is hidden until harvest. Video: Terra waters the crop and you watch the whole season. The weather is real (NASA POWER); the score is a teaching index, not a yield forecast." })]));
    outlook(box, tl);
  }
  async function start() {
    st.doses = []; st.covers = []; st.scouts = []; st.mulch = null; st.now = 0; st.caseNo = Math.floor(Math.random() * 50);
    stage.replaceChildren(card("🌾 Getting this place's real weather…", [el("p", { class: "hint", text: "The first time for a new place this can take up to a minute. Please wait." })]));
    try { st.data = await call({ day_now: 0 }); } catch (e) {
      stage.replaceChildren(card("The season could not open", [el("p", { class: "callout crit", text: e.message || "Unknown problem." }), el("p", { class: "hint", text: "This usually means the server could not reach the weather service (NASA POWER, then the Open-Meteo backup). Check the internet connection of the computer running the app, then try again." }), el("div", { class: "toolbar" }, [el("button", { class: "btn solid big", type: "button", text: "Try again", onclick: () => (J ? journeyChoose() : start()) })])]));
      return;
    }
    play(); narrate(st.auto ? `Watch your ${st.data.crop.name} grow through a whole season.` : `Your ${st.data.crop.name} is sown. Press next week to watch it grow. Water it when the soil gets dry.`);
    if (st.auto) advance(300);
  }
  const dateText = (day) => `Day ${day.d + 1} · ${dateLabel(st.month, st.day, day.d)}`;
  const drawAt = (scene, days, i) => draw(scene, days, i, st.data.crop, dateText(days[i]));
  function hint(d) {
    if (!d) return "Your crop has just been sown. The soil starts about a third full. Press Next week to watch it grow.";
    if (d.stress > 0.05) return "The crop is stressed: the soil is too dry. Irrigation helps right away.";
    if (d.water < 0.4) return "The soil is getting dry. Crops start to suffer below about 40% water.";
    if (d.rain > 8) return "Good rain today. Do not spend a dose when the sky is doing the work.";
    if (d.tmax > 35) return "A hot spell. Heat during flowering costs points, and water helps the plant cope.";
    if (d.tmin < 2) return "A night too cold for this crop. It costs points and you cannot prevent it here.";
    return "All fine so far. Remember, you cannot see next week's weather.";
  }
  const stageIcons = (crop) => { const k = kindOf(crop); return k === "tree" ? ["🌰", "🌳", "🌸", "🍏", "🍎"] : k === "tomato" ? ["🌰", "🌱", "🌿", "🌼", "🍅"] : k === "vine" ? ["🌰", "🌱", "🍃", "🌸", "🍇"] : ["🌰", "🌱", "🌿", "🌸", "🌾"]; };
  function buildHud(crop) {
    const kind = kindOf(crop), icons = stageIcons(crop);
    const tank = svg("svg", { viewBox: "0 0 120 160", class: "tank", role: "img", "aria-label": "Soil water" });
    tank.innerHTML = `<defs><clipPath id="gl"><path d="M22 14 H98 L90 148 Q89 154 83 154 H37 Q31 154 30 148 Z"/></clipPath></defs><g clip-path="url(#gl)"><rect x="0" y="0" width="120" height="160" fill="rgba(255,255,255,.05)"/><g id="wlevel"><g class="wave"><path d="M-120 8 q15 -9 30 0 t30 0 t30 0 t30 0 t30 0 t30 0 t30 0 t30 0 V170 H-120Z" id="wfill" fill="#3d9bf0"/></g></g></g><path d="M22 14 H98 L90 148 Q89 154 83 154 H37 Q31 154 30 148 Z" fill="none" stroke="#dfe9ff" stroke-width="3"/><text id="wpct" x="60" y="92" text-anchor="middle" font-size="22" font-weight="800" fill="#fff"></text>`;
    const nodes = icons.map((ic) => el("span", { class: "gnode", text: ic })), word = el("b", { class: "wword" }), sl = el("b", { class: "gstage" });
    const node = el("div", { class: "hud" }, [el("div", { class: "hudc" }, [tank, word, el("small", { text: "Soil water" })]), el("div", { class: "hudc journey" }, [el("div", { class: "gtrack2" }, nodes), sl, el("small", { text: "Crop journey" })])]);
    return { node, update(day) {
      const w = Math.max(0, Math.min(1, day.water)), lvl = tank.querySelector("#wlevel"), fill = tank.querySelector("#wfill");
      lvl.style.transform = `translateY(${150 - w * 134}px)`; fill.setAttribute("fill", w > 0.5 ? "#3d9bf0" : w > 0.28 ? "#d9a441" : "#d9553f");
      tank.querySelector("#wpct").textContent = Math.round(w * 100) + "%";
      word.textContent = w > 0.6 ? "Plenty of water" : w > 0.4 ? "Water is OK" : w > 0.25 ? "Getting dry" : "Very dry!"; word.style.color = w > 0.4 ? "#7fc4ff" : w > 0.25 ? "#f2c05a" : "#ff8a78";
      const gi = day.growth < 0.12 ? 0 : day.growth < 0.38 ? 1 : day.growth < 0.55 ? 2 : day.growth < 0.85 ? 3 : 4;
      nodes.forEach((n, i) => { n.classList.toggle("done", i < gi); n.classList.toggle("now", i === gi); }); sl.textContent = stageLabel(kind, day.growth);
    } };
  }
  const clean = (s) => s.replace(/[\p{Extended_Pictographic}\u200d\ufe0f]/gu, "").replace(/\s+/g, " ").trim();
  async function narrate(txt) {
    if (!voiceOn) return;
    try { const l = lang(); const out = l === "English" || l === "Auto" ? txt : await translateLine(txt); speak(clean(out)); } catch (e) { /* voice is optional */ }
  }
  const voiceBtn = el("button", { class: "btn", type: "button", onclick: () => { voiceOn = !voiceOn; store.set("ta-gamevoice", voiceOn ? "1" : "0"); voiceBtn.textContent = voiceOn ? "🔊 Voice on" : "🔇 Voice off"; if (!voiceOn) { try { speechSynthesis.cancel(); } catch (e) { /* none */ } } } }, [voiceOn ? "🔊 Voice on" : "🔇 Voice off"]);
  let hud = null;
  function play() {
    const d = st.data, last = d.days[d.days.length - 1], scene = buildScene(), out = el("p", { class: "hint", role: "status" });
    const wk = Math.ceil(d.now / 7), left = d.doses_left; hud = buildHud(d.crop);
    const btn = (text, cls, fn, dis) => el("button", { class: "btn " + cls, type: "button", text, disabled: dis || st.busy, onclick: fn });
    stage.replaceChildren(card(`${d.crop.name}: week ${wk}`, [scene, hud.node,
      el("p", { class: "tsay", text: "Terra: " + hint(last) }), out,
      d.finished ? null : st.auto ? el("div", { class: "toolbar" }, [el("span", { class: "hint", text: "🎬 Watching: Terra is watering the crop for you." }), voiceBtn]) : el("div", { class: "gtools" }, [
        el("div", { class: "toolbar" }, [btn(`💧 Irrigate ${d.dose_mm} mm (${left} left)`, "", irrigate, left < 1), btn(`🔭 Scout 3 days ahead (${d.scouts_left} left)`, "", scout, d.scouts_left < 1), btn(`🧣 Cover the crop tonight (${d.covers_left} left)`, "", cover, d.covers_left < 1), btn(d.mulched ? "🌾 Mulched" : "🌾 Mulch the soil (once)", "", mulch, d.mulched)]),
        peekBox(d),
        el("div", { class: "toolbar" }, [btn("Next day ▶", "", () => advance(1)), btn("Next week ▶▶", "solid", () => advance(7)), btn("Skip to harvest ⏭", "", () => advance(300)), voiceBtn]),
        el("p", { class: "hint", text: "Game rules: a cover only helps on a night that really is too cold for the crop, so scout first. Mulch lowers water use by about a tenth for the rest of the season. Scouting shows the real next 3 days of this hidden year." })])]));
    if (last) { drawAt(scene, d.days, d.days.length - 1); hud.update(last); } else { const z = { d: 0, tmax: 22, tmin: 12, rain: 0, water: 0.3, stress: 0, growth: 0, irrigated: 0 }; draw(scene, [z], 0, d.crop, `Day 1 · ${dateLabel(st.month, st.day, 0)}`); hud.update(z); }
    if (d.finished) finish();
  }
  function peekBox(d) {
    const p = d.peeks[d.peeks.length - 1]; if (!p || p.from !== d.now - 1) return null;
    const bits = [`🌧️ ${p.rain_mm} mm rain`, `🌡️ high ${p.tmax} °C, low ${p.tmin} °C`];
    const cc = d.crop.cold_crit, warn = p.frost ? `🥶 A night below ${cc} °C is coming. That is too cold for this crop: cover it tonight!` : p.hot ? "🔥 A hot spell is coming. Keep the soil wet." : p.rain_mm >= 8 ? "☔ Rain is coming. Do not waste a dose." : "😌 Nothing dramatic in the next 3 days.";
    return el("div", { class: "callout peek" }, [el("b", { text: "🔭 Scouting report, next 3 days: " }), bits.join(" · "), el("p", { text: warn })]);
  }
  async function act(fn, say) {
    if (st.busy) return; st.busy = true;
    try { const nd = await call({ day_now: st.data.now }); st.data = nd; if (say) narrate(say(nd)); } catch (e) { fn(); toast(e.message); }
    st.busy = false; play();
  }
  const scout = () => { st.scouts.push(st.data.now - 1); return act(() => st.scouts.pop(), (nd) => { const p = nd.peeks[nd.peeks.length - 1]; return p ? `Scouting: ${p.rain_mm} millimetres of rain, high ${p.tmax}, low ${p.tmin} in the next three days.` : ""; }); };
  const cover = () => { st.covers.push(st.data.now); return act(() => st.covers.pop(), () => "The cover is on for tonight."); };
  const mulch = () => { st.mulch = st.data.now; return act(() => { st.mulch = null; }, () => "The soil is mulched. The crop will use a little less water."); };
  async function irrigate() {
    if (st.busy) return; st.doses.push(st.data.now); st.busy = true;
    try { st.data = await call({ day_now: st.data.now }); narrate(`Irrigating ${st.data.dose_mm} millimetres. ${st.data.doses_left} doses left.`); } catch (e) { st.doses.pop(); toast(e.message); }
    st.busy = false; play();
  }
  async function advance(n) {
    if (st.busy) return; st.busy = true; const before = st.data.days.length;
    try { const nd = await call({ day_now: Math.min(300, st.data.now + n) }); st.busy = false; await animate(nd, before); st.data = nd; const sv = nd.days.slice(before).filter((x) => x.saved).length; if (sv) { toast("🧣 Your cover saved the crop from the cold night!"); narrate("Your cover saved the crop tonight."); } if (!st.auto && !nd.finished) { const l = nd.days[nd.days.length - 1]; narrate(`Week ${Math.ceil(nd.now / 7)}. ${hint(l)}`); } } catch (e) { st.busy = false; toast(e.message); return; }
    play();
  }
  async function animate(nd, from) {                   // time-based: always finishes in a fixed time, however slow the computer draws
    const scene = stage.querySelector("svg[role=img]"); if (!scene) return;
    const N = nd.days.length, span = N - from, total = st.auto ? (J ? 11000 : 16000) : Math.min(3200, 600 + span * 40); let mark = 0;
    const t0 = performance.now(), frame = (i) => { draw(scene, nd.days, i, nd.crop, `Day ${nd.days[i].d + 1} · ${dateLabel(st.month, st.day, nd.days[i].d)}`); hud && hud.update(nd.days[i]); };
    for (;;) {
      const k = Math.min(1, (performance.now() - t0) / total), i = Math.min(N - 1, from + Math.floor(k * span));
      frame(i);
      if (st.auto && i / N >= 0.25 * (mark + 1) && mark < 3) { mark++; narrate(`Week ${Math.ceil((i + 1) / 7)}. ${hint(nd.days[i])}`); }
      if (k >= 1) break;
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 30)));
    }
    frame(N - 1);
  }
  function countUp(node, to) { const t0 = performance.now(); const tick = (t) => { const k = Math.min(1, (t - t0) / 1400); node.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(tick); }; requestAnimationFrame(tick); }
  function journeyEnd(r) {
    const sc = st.auto ? r.autopilot.score : r.score, name = st.data.crop.name, lost = sc < 45, weak = sc < 70;
    const big = el("div", { class: "jend " + (lost ? "lost" : weak ? "weak" : "won") }, [el("div", { class: "jicon", text: lost ? "💔" : weak ? "🌾" : "🎉" }),
      el("h2", { text: lost ? `Your ${name} would have been lost` : weak ? `Your ${name} would give a weak harvest` : `Your ${name} would be harvested` }),
      el("p", { text: lost ? "The weather at your spot was too hard for this crop in this season. See what would work better." : weak ? "It survives, but water or heat or cold hold it back. A better month or crop could do much better." : "Good weather and smart watering carried it to harvest. Here is how to make it even safer." }),
      el("p", { class: "hint", text: `Season score ${sc} out of 100 (a teaching index, not a yield forecast).` })]);
    const rec = el("div", { class: "jrec" }, [el("p", { class: "hint", text: "Checking which month and crop suit your spot best…" })]);
    api.recommend({ field_id: f.id, crop: st.crop, month: st.month, day: 15 }).then((o) => {
      const chip = (x, label) => el("button", { type: "button", class: "jchip " + x.verdict, onclick: () => { st.crop = x.crop; st.month = x.month; stage.replaceChildren(); start(); } }, [el("span", { text: emoji(x.crop) }), el("b", { text: label }), el("small", { text: ({ good: "good choice", risky: "risky", poor: "poor choice" })[x.verdict] + " · " + x.score + "/100" })]);
      rec.replaceChildren(el("h3", { text: `Best time to plant ${name} here` }), el("div", { class: "jchips" }, o.best_months.map((x) => chip(x, `Plant in ${MONTHS[x.month - 1]}`))),
        el("h3", { text: `Other crops that suit ${MONTHS[st.month - 1]} here` }), el("div", { class: "jchips" }, o.other_crops.map((x) => chip(x, x.name))),
        el("p", { class: "hint", text: "Tap any choice to watch that season. " + o.note }));
      narrate(`${lost ? "Your crop would have been lost." : weak ? "A weak harvest." : "Harvest!"} The best month to plant ${name} here is ${MONTHS[o.best_months[0].month - 1]}. ${o.other_crops[0] ? o.other_crops[0].name + " is also a good idea." : ""}`);
    }).catch((e) => rec.replaceChildren(el("p", { class: "hint", text: e.message })));
    const go = el("button", { class: "btn solid big", type: "button", text: "✅ Save my field and open my farm", onclick: async () => {
      go.disabled = true; try { await saveJourneyField(app, st.crop); } catch (e) { toast(e.message); }
      app.journey = null; finishJourney(); if (!app.user) toast("You are in demo mode. Sign in to keep this field."); app.go("dashboard"); } });
    return el("section", { class: "card jendcard" }, [big, rec, el("div", { class: "toolbar" }, [go, el("button", { class: "btn big", type: "button", text: "▶ Try another crop", onclick: () => { stage.replaceChildren(); setup(); } })])]);
  }
  function finish() {
    const r = st.data.result, you = r.score, ap = r.autopilot.score, rf = r.rainfed.score, fct = r.facts;
    const verdict = st.auto ? `Season complete. Terra's watering scored ${ap}, rain alone ${rf}.` : you > ap + 2 ? "🏆 You beat the autopilot!" : you >= ap - 2 ? "👏 You matched the autopilot." : you > rf ? "🙂 Better than rain alone, but the autopilot did better." : "🌵 Rain alone did as well or better. Water more wisely next time.";
    const rows = st.auto ? [["🤖", "Terra watering", ap], ["🌧️", "Rain only", rf]] : [["🧑‍🌾", "You", you], ["🤖", "Terra autopilot", ap], ["🌧️", "Rain only", rf]], best = Math.max(...rows.map((x) => x[2]));
    const meds = rows.map(([ic, label, v], i) => { const num = el("strong", { class: "mnum", text: "0" }); const m = el("div", { class: "medal" + (v === best ? " win" : ""), style: `animation-delay:${i * 0.18}s` }, [v === best ? el("span", { class: "crown", text: "🏆" }) : null, el("span", { class: "mi", text: ic }), el("b", { text: label }), num, el("small", { text: "out of 100" })]); setTimeout(() => countUp(num, v), 300 + i * 180); return m; });
    const conf = el("div", { class: "confetti", "aria-hidden": "true" }, Array.from({ length: 46 }, (_, i) => el("i", { style: `left:${(i * 37) % 100}%;background:hsl(${(i * 53) % 360},85%,60%);animation-delay:${(i % 10) * 0.12}s` })));
    const win = st.auto || you >= ap - 2;
    const c = card("Harvest day 🌾", [win ? conf : null, el("h3", { text: verdict, style: "font-size:22px" }), el("div", { class: "medals" }, meds),
      el("div", { class: "callout" }, [el("b", { text: `The year was ${r.year}${st.worst ? ", the hardest one this place had in the weather record" : ""}. ` }), `That season had ${fct.rain_mm} mm of rain, ${fct.hot_days_over_35} days above 35 °C, and an average daytime high of ${fct.mean_tmax} °C. ${st.auto ? "" : `You used ${r.irrigation_used_mm} mm of irrigation, the autopilot ${r.autopilot.irrigation_used_mm} mm. `}Data: ${r.source}.`]),
      el("p", { class: "hint", text: `Score = share of the crop's water need met, minus 5% per very hot day and 10% per night too cold for this crop. ${r.heat_days} very hot days and ${r.cold_days} too-cold nights this season. It is a game index, not a yield forecast.` }),
      el("div", { class: "toolbar" }, [el("button", { class: "btn solid", type: "button", text: "▶ Play another season", onclick: () => { st.caseNo += 1; start(); } }), el("button", { class: "btn", type: "button", text: "Change crop or month", onclick: setup })])]);
    if (J) { stage.replaceChildren(journeyEnd(r)); return; }
    stage.append(c); c.scrollIntoView({ behavior: "smooth", block: "nearest" });
    narrate(`${clean(verdict)} The year was ${r.year}. ` + (st.auto ? `Terra's watering scored ${ap} out of 100, and rain alone ${rf}.` : `You scored ${you}. The autopilot scored ${ap}. Rain alone scored ${rf}.`));
  }
  function journeyChoose() {
    const emo = EMO[st.crop] || "🌱";
    stage.replaceChildren(card(`${emo} ${J.name}: your season is ready`, [el("p", { class: "tsay", text: "Terra: Do you want to farm this season yourself, or watch it as a video?" }),
      el("div", { class: "toolbar" }, [el("button", { class: "btn solid big", type: "button", text: "🎮 I will farm it myself", onclick: () => { st.auto = false; st.worst = false; start(); } }), el("button", { class: "btn big", type: "button", text: "🌪 Survive your worst year", onclick: () => { st.auto = false; st.worst = true; start(); } }), el("button", { class: "btn big", type: "button", text: "🎬 Just watch", onclick: () => { st.auto = true; st.worst = false; start(); } })]),
      el("p", { class: "hint", text: "Survive your worst year: the harshest season this very spot had in the last 20 years, hidden until harvest. Can you beat what rain alone would have done?" }),
      el("p", { class: "hint", text: "Farming it yourself: water, scout ahead, cover on cold nights and mulch. The weather is real, the year is hidden until harvest." })]));
    narrate("Do you want to farm this season yourself, or just watch?");
  }
  if (J) journeyChoose(); else setup();
  return root;
}
