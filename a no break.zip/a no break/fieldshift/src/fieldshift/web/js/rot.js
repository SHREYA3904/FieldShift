// Plain-picture version of a crop rotation: your field month by month, plants growing, a sun sweeping through the year.
import { el, MONTHS } from "./ui.js";
import { emoji } from "./journey.js";

const idOf = (c) => c.id || (c.crop_id) || String(c.name || "").toLowerCase();
const STAGE = ["🌱", "🌿", "🌿", "🌾"];
export function farmYear(s, opts = {}) {
  const cells = s.calendar.map((k, m) => {
    const c = k === "A" ? s.crops[0] : k === "B" ? s.crops[1] : null;
    let run = 0; if (c) { for (let j = m; j >= 0 && s.calendar[j] === k; j--) run++; }
    let total = 0; if (c) { let a = m; while (a > 0 && s.calendar[a - 1] === k) a--; let b = m; while (b < 11 && s.calendar[b + 1] === k) b++; total = b - a + 1; }
    const f = c ? run / Math.max(1, total) : 0, last = c && run === total, ic = !c ? "" : last ? emoji(idOf(c)) : STAGE[Math.min(2, Math.floor(f * 3))];
    return { m, c, k, run, total, f, ic, last };
  });
  const grid = el("div", { class: "ryear", role: "img", "aria-label": "Your field through the year" }, cells.map((x) => el("div", { class: "rcell " + (x.c ? (x.k === "A" ? "ra" : "rb") : "rbare"), style: `--d:${x.m * 70}ms;--g:${0.5 + x.f * 0.9}` }, [
    el("span", { class: "rm", text: MONTHS[x.m] }), el("span", { class: "rp", text: x.ic || "🟫" }), el("i", { class: "rground" })])));
  const cap = el("p", { class: "rcap", "aria-live": "off" }), sun = el("div", { class: "rsun", text: "☀️" });
  const say = (x) => !x.c ? `${MONTHS[x.m]}: the field rests. ${s.interventions && s.interventions.length ? "A cover crop or mulch would protect the soil." : "Keep the soil covered if you can."}`
    : x.run === 1 ? `${MONTHS[x.m]}: sow ${x.c.name}. 🌱` : x.last ? `${MONTHS[x.m]}: ${x.c.name} is ready. Harvest! ${emoji(idOf(x.c))}` : `${MONTHS[x.m]}: ${x.c.name} is growing.`;
  let i = opts.start ?? 0; const cs = [...grid.children];
  const tick = () => { if (!grid.isConnected && i > 0) { clearInterval(t); return; } cs.forEach((c, j) => c.classList.toggle("now", j === i)); cap.textContent = say(cells[i]); sun.style.left = ((i + 0.5) / 12 * 100) + "%"; i = (i + 1) % 12; };
  const t = setInterval(tick, opts.speed || 1400); tick();
  return el("div", { class: "rfilm" }, [el("div", { class: "rsky" }, [sun]), grid, cap]);
}

// "Today vs the best match" in one picture and one sentence.
export function compareHero(cur, best) {
  const w = Math.round(cur.scores.irrigation_need_mm_per_year - best.scores.irrigation_need_mm_per_year), same = cur === best;
  const name = (s) => s.crops.map((c) => c.name).join(" then ");
  const line = same ? "Your current rotation is already the best match for your field. Keep it up!"
    : `Switching to ${name(best)} fits your field ${Math.round((best.scores.overall - cur.scores.overall) * 100)} points better` + (w > 15 ? ` and saves about ${w} mm of irrigation water a year.` : w < -15 ? `, but needs about ${-w} mm more irrigation water a year.` : ".");
  return el("section", { class: "card rhero" }, [el("h3", { text: "Your year, in pictures" }), el("p", { class: "rline", text: line }),
    el("div", { class: "rpair" }, [el("div", {}, [el("h4", { class: "rtag now", text: "🧑‍🌾 What you do now: " + name(cur) }), farmYear(cur)]),
      same ? null : el("div", {}, [el("h4", { class: "rtag best", text: "✨ Better idea: " + name(best) }), farmYear(best, { start: 3 })])]),
    el("p", { class: "hint", text: "Brown squares mean the field is empty. Watch the sun move through the year." })]);
}
