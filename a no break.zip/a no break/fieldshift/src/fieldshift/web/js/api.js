const KEYN = "ta-gemini-key", MODELN = "ta-gemini-model", LANGN = "ta-lang", THREEN = "ta-3d", FIELDN = "ta-field";
export const store = {
  get(k, d = "") { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} },
};
export const keys = { KEYN, MODELN, LANGN, THREEN, FIELDN };
const BASE = location.protocol === "file:" ? "http://127.0.0.1:8000" : "";

async function call(path, method = "GET", body, ai = false) {
  const headers = { "Content-Type": "application/json" };
  const k = store.get(KEYN); if (ai && k) { headers["X-AI-Key"] = k; const m = store.get(MODELN); if (m) headers["X-AI-Model"] = m; }
  let r;
  try { r = await fetch(BASE + path, { method, headers, credentials: "same-origin", body: body ? JSON.stringify(body) : undefined }); }
  catch (e) { throw new Error("Cannot reach the TerraAdapt server. Is it running?"); }
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) { const err = new Error((j && typeof j.detail === "string" && j.detail) || (j && Array.isArray(j.detail) && j.detail.map((d) => d.msg).join("; ")) || `Request failed (${r.status})`); err.status = r.status; throw err; }
  return j;
}
export const api = {
  health: () => call("/api/health"),
  crops: () => call("/api/crops"),
  gameCrops: () => call("/api/game/crops"),
  gameWarm: (lat, lon) => call(`/api/game/warm?lat=${lat}&lon=${lon}`, "POST"),
  gameOutlook: (body) => call("/api/game/outlook", "POST", body),
  recommend: (body) => call("/api/game/recommend", "POST", body),
  game: (body) => call("/api/game/play", "POST", body),
  datapack: () => call("/api/datapack"),
  soils: () => call("/api/datapack/soils"),
  region: (lat, lon) => call(`/api/datapack/region?lat=${lat}&lon=${lon}`),
  parsePriorities: (text) => call("/api/priorities/parse", "POST", { text }),
  me: () => call("/api/me"),
  signup: (email, password, name) => call("/api/auth/signup", "POST", { email, password, name: name || "" }),
  guest: () => call("/api/auth/guest", "POST"),
  login: (email, password) => call("/api/auth/login", "POST", { email, password }),
  logout: () => call("/api/auth/logout", "POST"),
  updateMe: (body) => call("/api/me", "PUT", body),
  memory: () => call("/api/me/memory"),
  forget: (kind) => call("/api/me/memory" + (kind ? `?kind=${kind}` : ""), "DELETE"),
  fields: () => call("/api/fields"),
  saveField: (f) => (f.id && f.id !== "demo-field" ? call(`/api/fields/${f.id}`, "PUT", f) : call("/api/fields", "POST", f)),
  deleteField: (id) => call(`/api/fields/${id}`, "DELETE"),
  analyse: (id, sc) => call(`/api/fields/${id}/analyse`, "POST", sc || {}),
  forecast: (id) => call(`/api/fields/${id}/forecast`),
  translate: (language, texts) => call("/api/translate", "POST", { language, texts }, true),
  transcribe: (audio_b64, mime, language) => call("/api/transcribe", "POST", { audio_b64, mime, language }, true),
  ask: (body) => call("/api/assistant", "POST", body, true),
  explain: (body) => call("/api/explain", "POST", body, true),
};
