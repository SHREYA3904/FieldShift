// First-run journey: from space to your farm. Allow location -> the Earth spins and dives to your spot -> name your field and pick a crop
// -> watch that crop's real season (harvest or loss) -> get a recommendation -> the rest of the app.
import { el, MONTHS, toast } from "./ui.js";
import { api, store } from "./api.js";
import { speak, translateLine } from "./terra.js";
import { lang, setLang, LANGS } from "./i18n.js";

const EMO = { wheat: "🌾", barley: "🌾", maize: "🌽", rice: "🌾", sorghum: "🌾", soybean: "🫘", groundnut: "🥜", chickpea: "🫘", pea: "🫛", mustard: "🌼", sunflower: "🌻", cotton: "☁️", potato: "🥔", apple: "🍎", grape: "🍇", tomato: "🍅", canola: "🌼", oat: "🌾", lentil: "🫘", sugarcane: "🎋" };
export const emoji = (id) => EMO[id] || "🌱";
const TEX = "vendor/tex/earth_atmos_2048.jpg";
const DEMO = { lat: 36.5, lon: -116.3 };
export const journeyDone = () => store.get("ta-journey") === "1";
export const finishJourney = () => { store.set("ta-journey", "1"); document.body.classList.remove("journeying"); };

const pos = (lat, lon, k) => {                       // background-position percentages that centre the picture on (lat, lon) at zoom k
  const u = (lon + 180) / 360, v = (90 - Math.max(-60, Math.min(60, lat))) / 180;
  const px = (k * u - 0.5) / (k - 1), py = Math.max(0, Math.min(1, ((k / 2) * v - 0.5) / (k / 2 - 1)));
  return `${(px * 100).toFixed(2)}% ${(py * 100).toFixed(2)}%`;
};
async function placeName(lat, lon) {
  try {
    const c = new AbortController(); setTimeout(() => c.abort(), 3500);
    const j = await (await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&zoom=15&lat=${lat}&lon=${lon}`, { signal: c.signal })).json();
    const a = j.address || {}; return [a.suburb || a.neighbourhood || a.village || a.town || a.city_district || a.city || a.county || a.state_district, a.city && (a.suburb || a.neighbourhood) ? a.city : a.state, a.country].filter(Boolean).slice(0, 3).join(", ") || "";
  } catch (e) { return ""; }
}
async function searchPlaces(q) {                     // up to 5 matches, so a common name never silently lands on the wrong town
  try {
    const j = await (await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=5&addressdetails=1&q=${encodeURIComponent(q)}`)).json();
    return j.map((x) => ({ lat: +x.lat, lon: +x.lon, label: x.display_name.split(",").map((s) => s.trim()).filter((s, i, a) => i < 2 || i === a.length - 1 || i === a.length - 2).slice(0, 4).join(", ") }));
  } catch (e) { return []; }
}
const say = async (t) => { try { const l = lang(); speak(l === "English" || l === "Auto" ? t : await translateLine(t)); } catch (e) { /* voice is optional */ } };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export async function journey(app) {
  if (document.getElementById("journey")) return;
  const root = el("div", { id: "journey", role: "dialog", "aria-label": "Your journey" });
  const stars = el("div", { class: "jstars" });
  const earth = el("div", { class: "jearth" }, [el("div", { class: "jmap" }), el("div", { class: "jshade" }), el("div", { class: "jclouds" })]);
  const farm = el("div", { class: "jfarm" }, [el("div", { class: "jpatch" }, Array.from({ length: 24 }, (_, i) => el("i", { style: `--c:${["#7cc06a", "#c9b45a", "#5aa05a", "#a97f4a", "#8fc56e", "#d8c46a"][(i * 7 + (i >> 2)) % 6]};--d:${(i % 8) * 60}ms` }))), el("div", { class: "jpin", text: "📍" })]);
  const panel = el("div", { class: "jpanel" });
  const skip = el("button", { class: "jskip", type: "button", text: "Skip for now", onclick: () => { finishJourney(); root.remove(); } });
  root.append(stars, earth, farm, panel, skip); document.body.append(root); document.body.classList.add("journeying");
  const map = earth.querySelector(".jmap"); map.style.backgroundImage = `url(${TEX})`;
  const st = { lat: DEMO.lat, lon: DEMO.lon, place: "", crop: "wheat", month: new Date().getMonth() + 1, name: "My field", verdict: null };
  const T = async (s) => { const l = lang(); return l === "English" || l === "Auto" ? s : (await translateLine(s)); };

  function showDemo() {                                    // the demo place: opens at once, no questions
    if (app.fields && app.fields.find((f) => f.id === "demo-field")) { app.fieldId = "demo-field"; try { store.set("ta-field", "demo-field"); } catch (e) {} if (app.drawFieldSelect) app.drawFieldSelect(); }
    store.set("ta-lang-asked", "1"); root.classList.add("leaving");
    setTimeout(() => { root.remove(); if (location.hash === "#/dashboard") window.dispatchEvent(new HashChangeEvent("hashchange")); else location.hash = "#/dashboard"; }, 250);
  }
  const demoBtn = () => el("button", { type: "button", class: "btn big", text: "🌾 Show the demo place", onclick: showDemo });
  function welcome() {
    panel.replaceChildren(el("h1", { text: "Welcome to Earth 🌍" }), el("p", { text: "Allow your location and Terra will fly you to your own farm." }),
      el("div", { class: "jbtns" }, [el("button", { class: "btn solid big", type: "button", text: "📍 Fly me to my farm", onclick: () => { st.asked = true; locate(); } }), el("button", { class: "btn big", type: "button", text: "Choose a place", onclick: () => { st.asked = true; choose(); } }), demoBtn()]),
      el("small", { text: "Your location is only used to read the weather of your spot. Nothing is shared." }));
    say("Welcome to Earth. Allow your location and I will fly you to your farm.");
  }
  function choose(msg) {
    const inp = el("input", { class: "jinput", placeholder: "Village, town or city", "aria-label": "Place" });
    const list = el("div", { class: "jresults", role: "list" });
    const pickPlace = (r) => { st.lat = +r.lat.toFixed(4); st.lon = +r.lon.toFixed(4); st.picked = r.label; fly(); };
    const go = async () => {
      const q = inp.value.trim(); if (!q) return; list.replaceChildren(el("p", { class: "hint", text: "Searching…" }));
      const rs = await searchPlaces(q);
      if (!rs.length) { list.replaceChildren(el("p", { class: "hint", text: "I could not find that place. Try the town and country, for example: Howrah, India. Or use the demo place." })); return; }
      if (rs.length === 1) { pickPlace(rs[0]); return; }
      list.replaceChildren(el("p", { class: "hint", text: "Which one is your place? Tap it." }), ...rs.map((r) => el("button", { type: "button", class: "jres", onclick: () => pickPlace(r) }, [el("b", { text: "📍 " + r.label }), el("small", { text: `${r.lat.toFixed(2)}°, ${r.lon.toFixed(2)}°` })])));
    };
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") go(); });
    panel.replaceChildren(el("h1", { text: "Where is your farm?" }), typeof msg === "string" ? el("p", { text: msg }) : null, inp,
      el("div", { class: "jbtns" }, [el("button", { class: "btn solid big", type: "button", text: "✈ Fly there", onclick: go }), el("button", { class: "btn big", type: "button", text: "Use the demo place", onclick: () => { st.lat = DEMO.lat; st.lon = DEMO.lon; st.picked = ""; fly(); } })]), list);
    inp.focus();
  }
  function locate() {
    if (!navigator.geolocation) { choose("This browser cannot share your location. Type your place instead."); return; }
    panel.replaceChildren(el("h1", { text: "Finding you…" }), el("p", { text: "Please press Allow when your browser asks." }));
    navigator.geolocation.getCurrentPosition((p) => { st.picked = ""; st.acc = Math.round(p.coords.accuracy || 0); st.lat = +p.coords.latitude.toFixed(4); st.lon = +p.coords.longitude.toFixed(4); fly(); },
      () => choose("I could not get your location. Type your place instead, or use the demo place."), { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  }
  async function fly() {
    api.gameWarm(st.lat, st.lon).catch(() => {});   // start downloading this spot's weather now, so the game opens fast
    panel.replaceChildren(el("h1", { text: "Flying to your farm…" }), el("p", { class: "jcoord", text: `${st.lat.toFixed(2)}°, ${st.lon.toFixed(2)}°` }));
    say("Flying to your farm.");
    root.classList.add("flying"); map.style.setProperty("--k", "1");
    map.style.transition = "none"; map.style.backgroundSize = "200% 100%"; map.style.backgroundPosition = pos(st.lat, st.lon, 2); void map.offsetWidth;
    map.style.transition = "background-size 3.4s cubic-bezier(.6,0,.25,1), background-position 3.4s cubic-bezier(.6,0,.25,1)";
    map.style.backgroundSize = "2400% 1200%"; map.style.backgroundPosition = pos(st.lat, st.lon, 24);
    const nm = placeName(st.lat, st.lon);
    await wait(2600); root.classList.add("landed"); st.place = st.picked || await Promise.race([nm, wait(1500).then(() => "")]); await wait(900);
    named();
  }
  async function named() {
    const inp = el("input", { class: "jinput", value: st.name, "aria-label": "Field name", maxlength: "60" });
    const crops = await api.gameCrops(), lead = ["wheat", "rice", "maize", "cotton", "potato", "tomato", "apple", "grape", "soybean", "mustard", "chickpea", "sugarcane"];
    const sorted = [...crops].sort((a, b) => (lead.indexOf(a.id) < 0 ? 99 : lead.indexOf(a.id)) - (lead.indexOf(b.id) < 0 ? 99 : lead.indexOf(b.id)));
    const note = el("div", { class: "jnote", role: "status" });
    const btns = sorted.map((c) => el("button", { type: "button", class: "jcrop" + (c.id === st.crop ? " on" : ""), onclick: () => { st.crop = c.id; btns.forEach((b) => b.classList.toggle("on", b === btns[sorted.indexOf(c)])); check(); } }, [el("span", { text: emoji(c.id) }), el("small", { text: c.name })]));
    const months = MONTHS.map((m, i) => el("button", { type: "button", class: "jmonth" + (i + 1 === st.month ? " on" : ""), text: m, onclick: () => { st.month = i + 1; months.forEach((b, j) => b.classList.toggle("on", j === i)); check(); } }));
    let tok = 0;
    async function check() {
      const t = ++tok; note.className = "jnote"; note.textContent = "Checking 25 years of weather at your spot…";
      try { const o = await api.gameOutlook({ field_id: `geo:${st.lat},${st.lon}`, crop: st.crop, month: st.month, day: 15 }); if (t !== tok) return; st.verdict = o; note.className = "jnote " + o.verdict; note.textContent = ({ good: "👍 ", risky: "⚠️ ", poor: "👎 " }[o.verdict]) + o.headline + ". " + o.why; }
      catch (e) { if (t === tok) { note.textContent = e.message; } }
    }
    const wrong = el("div", { class: "jnote" + (st.acc > 1500 ? " risky" : ""), role: "note" }, [
      el("span", { text: st.acc > 1500 ? `Your computer only knows your place to about ${(st.acc / 1000).toFixed(1)} km, so this may be a nearby area. ` : "Not your place? " }),
      el("button", { type: "button", class: "btn", text: "📍 Change place", onclick: () => { st.asked = true; choose(); } })]);
    panel.replaceChildren(el("h1", { text: st.place ? `You are in ${st.place} 📍` : "You have arrived 📍" }), wrong,
      el("label", { class: "jlabel", text: "Name your field" }), inp,
      el("label", { class: "jlabel", text: "What do you want to grow?" }), el("div", { class: "jcrops" }, btns),
      el("label", { class: "jlabel", text: "When will you plant it?" }), el("div", { class: "jmonths" }, months), note,
      el("div", { class: "jbtns" }, [el("button", { class: "btn solid big", type: "button", text: "▶ Show me what will happen", onclick: () => { st.name = inp.value.trim() || "My field"; begin(); } })]));
    say(st.place ? `You are in ${st.place}. Name your field, and tell me what you want to grow.` : "You have arrived. Name your field, and tell me what you want to grow.");
    check();
  }
  function begin() {
    app.journey = { fieldId: `geo:${st.lat},${st.lon}`, lat: st.lat, lon: st.lon, name: st.name, place: st.place, crop: st.crop, month: st.month };
    store.set("ta-home", JSON.stringify({ lat: st.lat, lon: st.lon, name: st.name, place: st.place, crop: st.crop, month: st.month }));   // next launch goes straight back to this place
    saveJourneyField(app, st.crop).then((s) => { if (s) toast("Saved as your field: " + st.name); else toast("Your place is kept on this device."); }).catch(() => {});
    root.classList.add("leaving"); setTimeout(() => { root.remove(); location.hash = "#/game"; }, 600);
  }
  function afterLanguage() {
    welcome();
    setTimeout(() => { if (document.getElementById("journey") && !st.asked) { st.asked = true; locate(); } }, 900);   // then ask the browser (Edge, Chrome...) for the current location
  }
  let home = null; try { home = JSON.parse(store.get("ta-home", "null")); } catch (e) { home = null; }
  if (home && !(isFinite(home.lat) && isFinite(home.lon))) home = null;
  function welcomeBack() {                                 // a saved place: no questions, straight to the game
    api.gameWarm(home.lat, home.lon).catch(() => {});
    const go = () => { app.journey = { fieldId: `geo:${home.lat},${home.lon}`, lat: home.lat, lon: home.lon, name: home.name, place: home.place, crop: home.crop, month: home.month, saved: true }; root.classList.add("leaving"); setTimeout(() => { root.remove(); location.hash = "#/game"; }, 400); };
    panel.replaceChildren(el("h1", { text: `Welcome back 🌾` }), el("p", { text: `${home.name}${home.place ? " · " + home.place : ""}` }),
      el("div", { class: "jbtns" }, [el("button", { class: "btn solid big", type: "button", text: "▶ Play now", onclick: go }), el("button", { class: "btn big", type: "button", text: "📍 Change place", onclick: () => { st.asked = true; choose(); } }), demoBtn()]));
    say("Welcome back. Let's go.");
  }
  const STATE_LANG = { "west bengal": "Bengali", tripura: "Bengali", bangladesh: "Bengali", maharashtra: "Marathi", "tamil nadu": "Tamil", telangana: "Telugu", "andhra pradesh": "Telugu", gujarat: "Gujarati", karnataka: "Kannada", punjab: "Punjabi", kerala: "Malayalam", odisha: "Odia", assam: "Assamese", "uttar pradesh": "Hindi", bihar: "Hindi", delhi: "Hindi", rajasthan: "Hindi", "madhya pradesh": "Hindi", haryana: "Hindi", jharkhand: "Hindi", chhattisgarh: "Hindi", uttarakhand: "Hindi", nepal: "Nepali", "sri lanka": "Sinhala", pakistan: "Urdu", germany: "German", france: "French", spain: "Spanish", brazil: "Portuguese", italy: "Italian", kenya: "Swahili", tanzania: "Swahili" };
  function suggestedLang() {                               // from the saved place, else the browser's own language
    const p = (home && home.place || "").toLowerCase(); for (const k in STATE_LANG) if (p.includes(k)) return STATE_LANG[k];
    const code = ((navigator.languages || [navigator.language || "en"])[0] || "en").slice(0, 2).toLowerCase(), hit = LANGS.find(([, , c]) => c && c.slice(0, 2).toLowerCase() === code);
    return hit && hit[0] !== "Auto" ? hit[0] : "English";
  }
  function langStep() {                                   // first question of all, on every launch: which language, shown in each language's own letters
    if (home) api.gameWarm(home.lat, home.lon).catch(() => {});      // start fetching the weather while they choose
    const pick = (v) => { store.set("ta-lang-asked", "1"); if (app.applyLang) app.applyLang(v); else setLang(v); setTimeout(home ? welcomeBack : afterLanguage, 300); };
    panel.replaceChildren(el("h1", { text: "🌐 Your language · आपकी भाषा · আপনার ভাষা" }), el("p", { text: "Tap yours and let's go!" }),
      (() => { const sg = suggestedLang(), row = LANGS.find(([v]) => v === sg); return row ? el("div", { class: "jbtns" }, [el("button", { type: "button", class: "btn solid big", onclick: () => pick(sg) }, [el("span", { text: "★ " }), el("b", { text: row[1] })])]) : null; })(),
      el("div", { class: "jbtns" }, [demoBtn()]),
      el("div", { class: "jlangs" }, LANGS.filter(([v]) => v !== "Auto").map(([v, native]) => el("button", { type: "button", class: "jres jlang", lang: v === "English" ? "en" : undefined, onclick: () => pick(v) }, [el("b", { text: native })]))));
  }
  langStep();
}

// Called when the season is over: save the spot as the farmer's real field (account) or keep it until they sign in.
export async function saveJourneyField(app, crop) {
  const j = app.journey; if (!j) return null;
  const ids = app.crops.map((c) => c.id), a = ids.includes(crop) ? crop : "wheat", b = ids.find((x) => x !== a) || "chickpea";
  const body = { farm: "My farm", name: j.name, lat: j.lat, lon: j.lon, area_ha: null, soil: "auto", irrigation_mm: 0, water_availability: "medium", current: [a, b], history: [], priorities: { water: 3, nfix: 3, erosion: 3, om: 3, forage: 1, market: 3 }, soil_test: {}, boundary: null, note: j.place ? `Created from your journey near ${j.place}.` : "Created from your journey." };
  if (!app.user) {                                                          // no account yet: make a private device account so the field is really saved
    try { const g = await api.guest(); app.user = g.user; if (app.setUser) await app.setUser(g.user); }
    catch (e) { store.set("ta-pending-field", JSON.stringify(body)); j.saved = true; return null; }
  }
  if (j.saved) return j.saved === true ? null : j.saved;                      // already saved when the journey started: never twice
  const saved = await api.saveField(body); j.saved = saved; await app.reloadFields(saved.id); return saved;
}
