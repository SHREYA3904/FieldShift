// Built-in translations (Hindi, Bengali, German) shipped with the app: no AI or internet call needed.
const FILES = { Hindi: "hi", Bengali: "bn", German: "de" };
const store = {};   // language -> { exact: Map, patterns: [[RegExp, template, order]] }
const esc = (s) => s.replace(/[.*+?^$()|[\]\\]/g, "\\$&");

export const hasLocale = (language) => language in FILES;
export async function loadLocale(language) {
  if (!(language in FILES)) return null;
  if (store[language]) return store[language];
  try {
    const d = await (await fetch(new URL(`../locales/${FILES[language]}.json`, import.meta.url))).json();
    const exact = new Map(), patterns = [];
    for (const [en, tr] of Object.entries(d)) {
      if (!/\{\d+\}/.test(en)) { exact.set(en, tr); continue; }
      const parts = en.split(/\{\d+\}/), order = [...en.matchAll(/\{(\d+)\}/g)].map((m) => +m[1]);
      patterns.push([new RegExp("^" + parts.map((p) => esc(p).replace(/\{/g, "\\{").replace(/\}/g, "\\}")).join("([\\s\\S]*?)") + "$"), tr, order, parts.join("").length]);
    }
    patterns.sort((a, b) => b[0].source.length - a[0].source.length);
    store[language] = { exact, patterns };
  } catch (e) { store[language] = { exact: new Map(), patterns: [] }; }
  return store[language];
}
// Returns the translation, or undefined when the app has none for this exact sentence.
export function lookup(language, text, depth = 0) {
  const L = store[language]; if (!L) return undefined;
  const t = text.trim(); if (L.exact.has(t)) return L.exact.get(t);
  if (depth > 3) return undefined;
  for (const [re, tr, order, fixed] of L.patterns) {
    const m = t.match(re); if (!m) continue;
    const vals = {}; let ok = true;
    order.forEach((n, i) => {
      const raw = m[i + 1], sub = raw.trim() ? lookup(language, raw, depth + 1) : undefined;
      // Short templates such as "{0} and {1}" only fire when each piece is translatable or a plain number/unit, so a long English sentence is never half-translated.
      if (sub === undefined && fixed < 14 && !/^[\d\s.,:%+\-–—°/()×·→]{1,16}$/.test(raw)) ok = false;
      vals[n] = sub !== undefined ? sub : raw;
    });
    if (!ok) continue;
    return tr.replace(/\{(\d+)\}/g, (_, n) => vals[n] ?? "");
  }
  return undefined;
}
