// "Hello Terra": a voice assistant that floats above every screen. Tap the orb, or (if switched on) just say "Hello Terra".
// A web page can only listen while it is open in a browser tab or an installed app window; the page cannot listen once it is closed.
import { el, toast } from "./ui.js";
import { api, store } from "./api.js";
import { t, voiceCode, lang, LANGS } from "./i18n.js";

const SR = window.SpeechRecognition || window.webkitSpeechRecognition, TTS = "speechSynthesis" in window;
const WAKE = /(hello|hey|hi|ok|okay|helo|hallo)\s*(terra|tera|tara|terra's)|(हैलो|हेलो|हे|हाय)\s*(टेरा|तेरा)|(হ্যালো|হেলো)\s*(টেরা)|(ஹலோ)\s*(டெர்ரா)|(hola|ola|olá|bonjour|salut|مرحبا)\s*(terra|تيرا)/i;
let app, panel, orb, log, inp, statusEl, wakeRec, cmdRec, wakeOn = false, here = null, speakReplies = store.get("ta-readaloud", "1") === "1";

const SCRIPTS = [[/[\u0980-\u09FF]/, "Bengali"], [/[\u0B80-\u0BFF]/, "Tamil"], [/[\u0C00-\u0C7F]/, "Telugu"], [/[\u0C80-\u0CFF]/, "Kannada"], [/[\u0D00-\u0D7F]/, "Malayalam"], [/[\u0A80-\u0AFF]/, "Gujarati"], [/[\u0A00-\u0A7F]/, "Punjabi"], [/[\u0B00-\u0B7F]/, "Odia"], [/[\u0900-\u097F]/, "Hindi"], [/[\u0600-\u06FF]/, "Arabic"], [/[\u0400-\u04FF]/, "Russian"], [/[\u3040-\u30FF]/, "Japanese"], [/[\u4E00-\u9FFF]/, "Chinese"], [/[\uAC00-\uD7AF]/, "Korean"], [/[\u0E00-\u0E7F]/, "Thai"]];
// The language to answer in: the one chosen in the app, or (when "Auto" or English) the language the farmer wrote or spoke in.
export function langOf(text) { const l = lang(); if (l !== "Auto" && l !== "English") return l; const hit = SCRIPTS.find(([re]) => re.test(text || "")); return hit ? hit[1] : l; }
const codeOf = (name) => { const r = LANGS.find((x) => x[0] === name); return r ? r[2] : navigator.language || "en-IN"; };
let speakAs = null;
const speechLang = () => (speakAs ? codeOf(speakAs) : lang() === "Auto" ? navigator.language || "en-IN" : voiceCode());
import { loadLocale, lookup } from "./locale.js";
export async function translateLine(text) {
  const l = lang(); if (l === "English" || l === "Auto" || !text) return text;
  await loadLocale(l); const b = lookup(l, text); if (b !== undefined) return b;
  try { const r = await api.translate(l, [text]); return r.translations[text] || text; } catch (e) { return text; }
}
let voices = [];
if (TTS) { const load = () => { voices = speechSynthesis.getVoices(); }; load(); speechSynthesis.onvoiceschanged = load; }
// Prefer the natural-sounding neural/cloud voices (Google, Microsoft "Online (Natural)", Apple Enhanced) in the farmer's language.
function pickVoice(code) {
  const pre = code.slice(0, 2).toLowerCase(), ok = voices.filter((v) => v.lang.toLowerCase().startsWith(pre));
  const score = (v) => (/natural|neural|online/i.test(v.name) ? 6 : 0) + (/google/i.test(v.name) ? 5 : 0) + (/enhanced|premium/i.test(v.name) ? 4 : 0) + (v.lang.toLowerCase() === code.toLowerCase() ? 3 : 0) + (v.localService ? 0 : 1);
  return ok.sort((a, b) => score(b) - score(a))[0] || null;
}
let audioCtx;
function chime(up = true) {
  try { audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)(); const o = audioCtx.createOscillator(), g = audioCtx.createGain(), n = audioCtx.currentTime;
    o.frequency.setValueAtTime(up ? 660 : 880, n); o.frequency.exponentialRampToValueAtTime(up ? 990 : 540, n + 0.14); g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(0.12, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + 0.18);
    o.connect(g).connect(audioCtx.destination); o.start(n); o.stop(n + 0.2); } catch (e) { /* sound is optional */ }
}
const sentences = (s) => (s.match(/[^.!?\u0964\u06D4]+[.!?\u0964\u06D4]*/g) || [s]).map((x) => x.trim()).filter(Boolean);
export function speak(txt, asLang) {
  if (!TTS || !txt) return Promise.resolve();
  speakAs = asLang || null; speechSynthesis.cancel(); const code = speechLang(), v = pickVoice(code); orb && orb.classList.add("speaking");
  return new Promise((res) => {
    const q = sentences(txt); let i = 0;
    const next = () => { if (i >= q.length) { orb && orb.classList.remove("speaking"); res(); return; }
      const u = new SpeechSynthesisUtterance(q[i++]); u.lang = v ? v.lang : code; if (v) u.voice = v; u.rate = 1.0; u.pitch = 1.05; u.onend = next; u.onerror = next; speechSynthesis.speak(u); };
    next();
  });
}
const STOP = /^(stop|thanks|thank you|that'?s all|bye|goodbye|cancel|no thanks|ok thanks|धन्यवाद|बस|রাখো|ধন্যবাদ|நன்றி|ధన్యవాదాలు|gracias|merci|obrigad|asante|شكرا|terima kasih|danke|спасибо|谢谢|ありがとう|감사)/i;

export function getHere(ask = false) {
  if (here) return Promise.resolve(here);
  try { const c = JSON.parse(store.get("ta-loc", "null")); if (c && Date.now() - c.t < 6 * 3600e3) { here = c; return Promise.resolve(c); } } catch (e) { /* no saved location */ }
  if (!ask || !navigator.geolocation) return Promise.resolve(null);
  return new Promise((res) => navigator.geolocation.getCurrentPosition((p) => { here = { lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4), t: Date.now() }; store.set("ta-loc", JSON.stringify(here)); res(here); }, () => res(null), { timeout: 12000, maximumAge: 600000 }));
}
export const useHere = (field) => { const v = store.get("ta-usehere", "auto"); return v === "on" || (v === "auto" && field && field.id === "demo-field"); };

export async function askTerra(app_, q, opts = {}) {
  const f = app_.field(), uh = useHere(f), h = uh ? await getHere(true) : null;
  const ql = langOf(q), body = { field_id: f.id, question: q, language: ql === "English" || ql === "Auto" ? app_.lang() : ql, voice: !!opts.voice, ...(h ? { here_lat: h.lat, here_lon: h.lon, use_here: true } : {}) };
  const r = await api.ask(body);
  if (r.mode !== "ai" && ql !== "English" && ql !== "Auto" && lang() === ql) {          // template answers are English: translate them when a key is available
    try { const both = [r.text, r.spoken].filter(Boolean), tr = await api.translate(lang(), both); if (tr.translations[r.text]) r.text = tr.translations[r.text]; if (r.spoken && tr.translations[r.spoken]) r.spoken = tr.translations[r.spoken]; } catch (e) { /* keep English */ }
  }
  r._lang = ql; return r;
}

function add(cls, text) { const m = el("div", { class: "tmsg " + cls, translate: "no" }, [el("span", { text })]); log.appendChild(m); log.scrollTop = log.scrollHeight; return m; }
async function ask(q, byVoice) {
  if (!q.trim()) return; add("u", q); inp.value = "";
  const w = add("a", "…"); statusEl.textContent = t("Ask") + "…"; orb.classList.add("thinking");
  let r = null;
  try {
    r = await askTerra(app, q, { voice: byVoice });
    w.firstChild.textContent = r.text; if (r.mode === "template" && r.note) w.appendChild(el("small", { class: "ainote", text: "⚙ Built-in answer, not AI. " + r.note })); else if (r.mode === "ai" && r.note) w.appendChild(el("small", { class: "ainote", text: "✨ " + r.note })); if (r.place) w.appendChild(el("small", { text: r.place.note }));
    w.appendChild(el("button", { class: "btn say", type: "button", text: "🔊 " + t("Listen"), onclick: () => speak(r.spoken || r.text, r._lang) }));
    statusEl.textContent = "";
  } catch (e) { w.firstChild.textContent = e.message; statusEl.textContent = ""; }
  orb.classList.remove("thinking"); log.scrollTop = log.scrollHeight;
  if (r && (byVoice || speakReplies)) { await speak(r.spoken || r.text, r._lang); if (byVoice && convo) listenOnce(); }    // keep the conversation going like a voice assistant
  else if (!r && byVoice && wakeOn) setTimeout(startWake, 800);
}
let convo = false, hello = null;
const HI = { Hindi: "नमस्ते {n}! मैं आपकी कैसे मदद कर सकती हूँ?", Bengali: "নমস্কার {n}! আমি আপনাকে কীভাবে সাহায্য করতে পারি?", Marathi: "नमस्कार {n}! मी तुम्हाला कशी मदत करू?", Tamil: "வணக்கம் {n}! நான் உங்களுக்கு எப்படி உதவலாம்?", Telugu: "నమస్కారం {n}! నేను మీకు ఎలా సహాయం చేయగలను?", Gujarati: "નમસ્તે {n}! હું તમને કેવી રીતે મદદ કરી શકું?", Kannada: "ನಮಸ್ಕಾರ {n}! ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?", Punjabi: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ {n}! ਮੈਂ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦੀ ਹਾਂ?", Spanish: "¡Hola {n}! ¿Cómo puedo ayudarte?", French: "Bonjour {n} ! Comment puis-je vous aider ?" };
// "Hi [name], how can I help you?": shown, spoken in the farmer's language, then Terra listens.
async function greetPopup() {
  if (store.get("ta-journey") !== "1") return;     // the first-run journey is the welcome
  if (store.get("ta-greet", "1") !== "1" || hello) return;
  while (document.body.classList.contains("intro-on")) await new Promise((r) => setTimeout(r, 300));
  const n = (app.first && app.first()) || "", l = lang(); let text = HI[l] ? HI[l].replace("{n}", n || "").replace("  ", " ") : null;
  if (!text) text = await translateLine(n ? `Hi ${n}! How can I help you?` : "Hi there! How can I help you?");
  if (!text) return;
  let started = false;
  const begin = (ev) => { if (started || (ev && ev.target && ev.target.closest && ev.target.closest(".terra-hello .x"))) return; started = true; removeEventListener("pointerdown", begin); removeEventListener("keydown", begin); open(text); };
  hello = el("div", { class: "terra-hello", role: "alertdialog", "aria-label": "Terra", translate: "no" }, [el("div", { class: "av", text: "T" }), el("div", {}, [el("p", { text }), el("small", { text: navigator.userActivation && navigator.userActivation.hasBeenActive ? "" : "Tap anywhere to talk to me" }),
    el("div", { class: "hb" }, [el("button", { class: "go", type: "button", text: "🎤", "aria-label": "Speak", onclick: (e) => { e.stopPropagation(); begin(); } }), el("button", { class: "x", type: "button", text: "✕", "aria-label": "Close", onclick: (e) => { e.stopPropagation(); started = true; hello.remove(); hello = null; removeEventListener("pointerdown", begin); removeEventListener("keydown", begin); } })])])]);
  document.body.appendChild(hello);
  if (navigator.userActivation && navigator.userActivation.hasBeenActive) setTimeout(begin, 600); else { addEventListener("pointerdown", begin); addEventListener("keydown", begin); }
}
const hear = (done) => {           // browser speech engine first; Gemini transcription as the fallback
  if (!SR) return false;
  cmdRec = new SR(); cmdRec.lang = speechLang(); cmdRec.interimResults = true; let final = "", failed = null;
  cmdRec.onresult = (ev) => { const r = ev.results[ev.results.length - 1]; statusEl.textContent = "🎤 " + r[0].transcript; if (r.isFinal) final = r[0].transcript; };
  cmdRec.onerror = (e) => { failed = e.error; };
  cmdRec.onend = () => done(final, failed);
  try { cmdRec.start(); return true; } catch (e) { return false; }
};
async function recordFallback(done) {
  let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { done("", "not-allowed"); return; }
  const mr = new MediaRecorder(stream), chunks = []; mr.ondataavailable = (e) => chunks.push(e.data);
  const ctx = new (window.AudioContext || window.webkitAudioContext)(), an = ctx.createAnalyser(); ctx.createMediaStreamSource(stream).connect(an); const buf = new Uint8Array(an.fftSize);
  let started = Date.now(), lastVoice = 0, spoke = false;
  const tick = setInterval(() => { an.getByteTimeDomainData(buf); const lvl = Math.max(...buf.map((v) => Math.abs(v - 128))); if (lvl > 14) { lastVoice = Date.now(); spoke = true; }
    if ((spoke && Date.now() - lastVoice > 1300) || Date.now() - started > 10000 || (!spoke && Date.now() - started > 6000)) mr.stop(); }, 120);
  mr.onstop = async () => {
    clearInterval(tick); stream.getTracks().forEach((x) => x.stop()); ctx.close();
    if (!spoke) { done("", "no-speech"); return; }
    const blob = new Blob(chunks, { type: mr.mimeType || "audio/webm" }), b64 = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(",")[1]); fr.readAsDataURL(blob); });
    try { const r = await api.transcribe(b64, (mr.mimeType || "audio/webm").split(";")[0], lang()); done(r.text || "", null); } catch (e) { statusEl.textContent = e.message; done("", "transcribe"); }
  };
  mr.start();
}
function listenOnce() {
  stopWake(); TTS && speechSynthesis.cancel(); chime(true); panel.classList.add("hearing"); statusEl.textContent = "🎤 …"; let engine = "browser";
  const finish = (final, err) => {
    panel.classList.remove("hearing");
    if (err && engine === "browser" && ["network", "service-not-allowed", "language-not-supported", "audio-capture"].includes(err) || (!SR && engine === "browser")) { engine = "gemini"; statusEl.textContent = "🎤 …"; chime(true); panel.classList.add("hearing"); recordFallback(finish); return; }
    chime(false);
    if (err === "not-allowed") { statusEl.textContent = "Allow the microphone in the browser address bar, then tap the microphone again."; convo = false; }
    else if (final && STOP.test(final.trim())) { statusEl.textContent = ""; convo = false; speak(app.lang() === "Hindi" ? "ठीक है." : "Okay."); }
    else if (final) { statusEl.textContent = ""; convo = true; ask(final, true); return; }
    else { statusEl.textContent = err === "transcribe" ? statusEl.textContent : "I did not hear anything. Tap the microphone to try again."; convo = false; }
    if (wakeOn) setTimeout(startWake, 800);
  };
  if (!hear(finish)) { engine = "gemini"; recordFallback(finish); }
}
function startWake() {
  if (!SR || !wakeOn || (wakeRec && wakeRec.running)) return;
  wakeRec = new SR(); wakeRec.lang = speechLang(); wakeRec.continuous = true; wakeRec.interimResults = true; wakeRec.running = true;
  wakeRec.onresult = (ev) => { const txt = [...ev.results].slice(ev.resultIndex).map((r) => r[0].transcript).join(" "); if (WAKE.test(txt)) { wakeRec.onend = null; wakeRec.running = false; try { wakeRec.stop(); } catch (e) { /* already stopped */ } open(true); } };
  wakeRec.onend = () => { wakeRec.running = false; if (wakeOn) setTimeout(startWake, 600); };
  wakeRec.onerror = (e) => { if (e.error === "network") { wakeOn = false; store.set("ta-wake", "0"); syncToggle(); toast("This browser cannot listen for Hello Terra (its speech service is offline). Use Google Chrome for the wake phrase, or tap the microphone."); } if (e.error === "not-allowed" || e.error === "service-not-allowed") { wakeOn = false; store.set("ta-wake", "0"); syncToggle(); toast("Microphone is blocked. Allow it in the address bar to use Hello Terra."); } };
  try { wakeRec.start(); } catch (e) { wakeRec.running = false; }
}
function stopWake() { if (wakeRec) { wakeRec.onend = null; wakeRec.running = false; try { wakeRec.stop(); } catch (e) { /* not running */ } } }
let wakeBox;
function syncToggle() { if (wakeBox) wakeBox.checked = wakeOn; orb.classList.toggle("armed", wakeOn); orb.title = wakeOn ? 'Say "Hello Terra"' : "Ask Terra"; }

function open(byVoice) {
  const hb = document.getElementById("here-box"); if (hb) hb.checked = useHere(app.field());
  panel.hidden = false; orb.setAttribute("aria-expanded", "true"); if (!log.children.length) add("a", greet());
  getHere(true); hello && hello.remove(); if (byVoice) { convo = true; chime(true); (typeof byVoice === "string" ? Promise.resolve(byVoice) : translateLine("Hi, I am Terra. How can I help?")).then((g) => speak(g)).then(() => listenOnce()); } if (!byVoice) inp.focus();
}
function close() { convo = false; panel.hidden = true; orb.setAttribute("aria-expanded", "false"); speechSynthesis && speechSynthesis.cancel(); try { cmdRec && cmdRec.abort(); } catch (e) { /* idle */ } if (wakeOn) startWake(); }
const greet = () => { const n = app.first && app.first(); return (n ? `Hi ${n}. ` : "Hi. ") + "I am Terra. Ask me about the weather where you are, what to plant, or when to irrigate."; };

export function mountTerra(appRef) {
  app = appRef;
  orb = el("button", { id: "terra-orb", class: "terra-orb", type: "button", "aria-label": "Ask Terra", "aria-expanded": "false", translate: "no", onclick: () => (panel.hidden ? open(false) : close()) }, [el("i"), el("b", { text: "T" })]);
  log = el("div", { class: "tlog", role: "log", "aria-live": "polite" }); statusEl = el("p", { class: "tstatus", role: "status" });
  inp = el("input", { type: "text", maxlength: 400, placeholder: t("Ask") + "…", "aria-label": t("Ask") });
  wakeBox = el("input", { type: "checkbox", id: "wake-box", onchange: (e) => { wakeOn = e.target.checked; store.set("ta-wake", wakeOn ? "1" : "0"); if (wakeOn) { if (!SR) { toast("This browser cannot listen for Hello Terra. Use Chrome or Edge."); wakeOn = false; } else startWake(); } else stopWake(); syncToggle(); } });
  const hereBox = el("input", { type: "checkbox", id: "here-box", onchange: (e) => { store.set("ta-usehere", e.target.checked ? "on" : "off"); if (e.target.checked) getHere(true); } });
  const chips = ["What can I plant now?", "Should I irrigate now?", "What is the weather outlook this week?"].map((q) => el("button", { type: "button", class: "btn", text: t(q), onclick: () => ask(q, false) }));
  panel = el("section", { class: "terra-panel", hidden: true, role: "dialog", "aria-label": "Terra assistant" }, [
    el("header", {}, [el("b", { text: "Terra", translate: "no" }), el("button", { class: "icon-btn", type: "button", "aria-label": "Close", onclick: close, text: "✕" })]), log, statusEl,
    el("div", { class: "tchips" }, chips),
    el("form", { class: "tin", onsubmit: (e) => { e.preventDefault(); ask(inp.value, false); } }, [inp, (SR || (navigator.mediaDevices && window.MediaRecorder)) ? el("button", { class: "btn mic", type: "button", "aria-label": t("Speak"), text: "🎤", onclick: () => { convo = true; listenOnce(); } }) : null, el("button", { class: "btn solid", type: "submit", text: t("Ask") })].filter(Boolean)),
    el("label", { class: "topt" }, [wakeBox, ' Say "Hello Terra" to open me (while this page is open)']), el("label", { class: "topt" }, [el("input", { type: "checkbox", checked: speakReplies, onchange: (e) => { speakReplies = e.target.checked; store.set("ta-readaloud", speakReplies ? "1" : "0"); if (!speakReplies) speechSynthesis.cancel(); } }), " Read answers aloud"]), el("label", { class: "topt" }, [el("input", { type: "checkbox", checked: store.get("ta-greet", "1") === "1", onchange: (e) => store.set("ta-greet", e.target.checked ? "1" : "0") }), " Greet me when I open the app"]), el("label", { class: "topt" }, [hereBox, " Use my current location for weather questions"])]);
  document.body.append(orb, panel);
  hereBox.checked = store.get("ta-usehere", "auto") === "on" || (store.get("ta-usehere", "auto") === "auto" && app.field() && app.field().id === "demo-field");
  addEventListener("keydown", (e) => { if (e.key === "Escape" && !panel.hidden) close(); });
  if (store.get("ta-wake", "0") === "1" && SR) { wakeOn = true; startWake(); } syncToggle(); greetPopup();
  if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("sw.js", { scope: "./" }).catch(() => {});
}
