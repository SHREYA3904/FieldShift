import { setTranslation } from "./domtr.js";
import { mountTerra } from "./terra.js";
import { LANGS, t as tr, setLang, lang as curLang, bigText, bigOn } from "./i18n.js";
import { $, el, icon, toast, loading, errorBox } from "./ui.js";
import { api, store, keys } from "./api.js";
import { initFx, enter } from "./fx.js";
import { intro } from "./intro.js";
import { journey, journeyDone, saveJourneyField } from "./journey.js";
intro();

function applyLogo() { const p = store.get("ta-logo", "logo.svg"), i = document.getElementById("logo"), f = document.getElementById("favicon"); if (i) i.src = p; if (f) f.href = p; }

const NAV = [["dashboard", "Overview", "overview"], ["forecast", "Weather Outlook", "earth"], ["fields", "My Fields", "fields"], ["earth", "Earth Intelligence", "earth"], ["risks", "Climate Risks", "risks"],
  ["lab", "Rotation Lab", "lab"], ["season", "My Season", "planner"], ["planner", "Seasonal Planner", "planner"], ["simulator", "Climate Simulator", "simulator"], ["game", "Season Challenge", "lab"], ["data", "Data & Sources", "earth"], ["assistant", "AI Assistant", "assistant"], ["profile", "Profile & Memory", "fields"]];
const MAIN = ["dashboard", "lab", "season", "fields", "assistant"], EXPERT = ["forecast", "risks", "planner", "simulator", "game"];
const NAMES = { dashboard: "Home", lab: "Rotation Lab", season: "My Season", fields: "My Farm", assistant: "Ask Terra" };
const PAGES = { dashboard: "overview", forecast: "forecast", fields: "fields", earth: "earth", risks: "risks", lab: "lab", planner: "planner", simulator: "simulator", season: "season", game: "game", data: "data", assistant: "assistant", profile: "profile", login: "login" };

export const app = {
  user: null, fields: [], crops: [], fieldId: null, cache: new Map(),
  field() { return this.fields.find((f) => f.id === this.fieldId) || this.fields[0]; },
  async analyse(sc = {}, fid) {
    const id = fid || this.field().id, k = id + JSON.stringify(sc);
    if (!this.cache.has(k)) this.cache.set(k, api.analyse(id, sc).catch((e) => { this.cache.delete(k); throw e; }));
    return this.cache.get(k);
  },
  async reloadFields(select) {
    this.fields = await api.fields(); this.cache.clear();
    if (select) this.fieldId = select;
    if (!this.fields.find((f) => f.id === this.fieldId)) this.fieldId = this.fields[0].id;
    store.set(keys.FIELDN, this.fieldId); this.drawFieldSelect();
  },
  async setUser(u) { this.user = u; drawUser(); await this.reloadFields(); },
  drawFieldSelect() {
    const s = $("field-select"); s.innerHTML = "";
    this.fields.forEach((f) => s.appendChild(el("option", { value: f.id, text: f.name + (f.id === "demo-field" ? " (demo)" : ""), selected: f.id === this.fieldId })));
  },
  go(r) { location.hash = "#/" + r; },
  serverAi: false,
  aiOn() { return !!store.get(keys.KEYN) || this.serverAi; },
  lang() { return curLang(); },
  first() { return (this.user && this.user.name ? this.user.name.split(" ")[0] : ""); },
};

function badge() {
  const b = $("ai-badge"), on = app.aiOn();
  b.textContent = on ? "AI on" : "AI off"; b.className = "pill" + (on ? " on" : "");
  b.title = on ? (store.get(keys.KEYN) ? "Your API key is set in this browser." : (app.aiProv ? `AI is running: ${app.aiProv}.` : "The Gemini key is set on the server (.env).")) : "No API key set. " + (app.aiHint || "") + " Click to learn how.";
  b.onclick = on ? null : () => toast(app.aiHint || "Open Settings (gear icon), paste your Gemini key and press Save.");
}
function drawUser() {
  const slot = $("user-slot"); slot.replaceChildren();
  document.querySelectorAll(".usermenu").forEach((m) => m.remove());
  const u = app.user, guest = u && /@guest\.terraadapt\.local$/.test(u.email || ""), nm = u ? (u.name || (guest ? "This device" : (u.email || u.phone)) || "Account") : "Account";
  const btn = el("button", { class: "userbtn", "aria-haspopup": "menu", "aria-label": "Account and more", onclick: (e) => {
    e.stopPropagation(); const ex = document.querySelector(".usermenu"); if (ex) { ex.remove(); return; }
    const close = () => document.querySelectorAll(".usermenu").forEach((x) => x.remove());
    const item = (href, t) => el("a", { href: "#/" + href, text: tr(t), onclick: close });
    const m = el("div", { class: "usermenu", role: "menu" }, [u ? el("small", { text: guest ? "Saved on this device. Create an account to keep it everywhere." : (u.email || u.phone || nm) }) : el("small", { text: tr("You are not signed in") }),
      u ? item("profile", "👤 Profile & memory") : item("login", "🔑 Sign in or create account"), guest ? item("login", "🔑 Sign in or create account") : null, item("fields", "🌾 My fields"), item("data", "📚 About our data"),
      el("small", { text: tr("For experts: detailed pages") }), item("forecast", "Weather details"), item("risks", "Risk details"), item("planner", "Planner details"), item("simulator", "Simulator details"), item("earth", "Earth intelligence"),
      u ? el("button", { text: tr("Sign out"), onclick: async () => { await api.logout(); close(); await app.setUser(null); toast("Signed out."); app.go(""); } }) : null]);
    document.body.appendChild(m);
  } }, [el("i", { text: u ? nm[0].toUpperCase() : "👤" }), u ? nm.split(" ")[0].slice(0, 14) : tr("Account")]);
  slot.appendChild(btn);
}
document.addEventListener("click", () => document.querySelectorAll(".usermenu").forEach((m) => m.remove()));

function settings() {
  const d = $("settings");
  $("settings-btn").onclick = () => {
    $("key").value = store.get(keys.KEYN); $("model").value = store.get(keys.MODELN); $("lang").value = app.lang(); $("logo-pick").value = store.get("ta-logo", "logo.svg"); $("three").checked = store.get(keys.THREEN, "1") === "1";
    $("key-state").textContent = app.aiOn() ? "A key is saved in this browser." : "No key saved."; d.showModal();
  };
  $("key-save").onclick = () => {
    const k = $("key").value.trim(), md = $("model").value.trim(); if (k) store.set(keys.KEYN, k); else store.del(keys.KEYN); if (md) store.set(keys.MODELN, md); else store.del(keys.MODELN);
    app.applyLang($("lang").value); store.set("ta-logo", $("logo-pick").value); applyLogo(); store.set(keys.THREEN, $("three").checked ? "1" : "0"); badge(); toast(k ? "Saved. AI answers are on." : "Saved.");
  };
  const say = (t) => { $("key-state").textContent = t; };
  $("key-test").onclick = async () => { say("Testing…"); const k = $("key").value.trim() || store.get(keys.KEYN) || ""; try { const r = await fetch("/api/ai/test", { method: "POST", headers: { ...(k ? { "x-ai-key": k } : {}) } }).then((x) => x.json()); say((r.ok ? "✅ " : "❌ ") + r.message); } catch (e) { say("Could not reach the app."); } };
  $("key-env").onclick = async () => { const k = $("key").value.trim(); if (!k) { say("Paste the key in the box first."); return; } try { const r = await fetch("/api/ai/save-key", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: k }) }); const j = await r.json(); if (!r.ok) { say("❌ " + (j.detail || "Could not save.")); return; } store.set(keys.KEYN, k); app.serverAi = true; badge(); say("✅ Saved in " + j.file + ". You never need to enter it again."); } catch (e) { say("Could not reach the app."); } };
  $("key-clear").onclick = () => { store.del(keys.KEYN); $("key").value = ""; badge(); $("key-state").textContent = "Key removed."; };
}

function placeLine() {
  const line = $("tl-line"), a = document.querySelector(".toplinks a.on");
  if (!a) { line.style.width = "0"; return; }
  line.style.left = a.offsetLeft + 16 + "px"; line.style.width = a.offsetWidth - 32 + "px";
}
function cursor() {
  if (matchMedia("(hover:none)").matches || matchMedia("(prefers-reduced-motion:reduce)").matches) return;
  const ring = el("div", { class: "cursor" }), dot = el("div", { class: "cursor-dot" }); document.body.append(ring, dot);
  let x = -100, y = -100, rx = -100, ry = -100;
  addEventListener("pointermove", (e) => { x = e.clientX; y = e.clientY; dot.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%)`; ring.style.opacity = 1; });
  addEventListener("pointerdown", () => ring.classList.add("down")); addEventListener("pointerup", () => ring.classList.remove("down"));
  document.addEventListener("pointerover", (e) => ring.classList.toggle("hot", !!e.target.closest("a,button,select,input,label,summary,.fieldcard,[role=button]")));
  (function f() { rx += (x - rx) * 0.18; ry += (y - ry) * 0.18; ring.style.transform = `translate(${rx}px,${ry}px) translate(-50%,-50%)`; requestAnimationFrame(f); })();
}

const modules = {};
async function load(name) { return modules[name] || (modules[name] = await import(`./pages/${name}.js`)); }

let token = 0;
async function route() {
  const t = ++token, h = location.hash.replace(/^#\/?/, "").split("?")[0], main = $("main");
  document.querySelectorAll(".toplinks a").forEach((a) => a.classList.toggle("on", a.dataset.r === h || (a.dataset.r === "dashboard" && h !== "" && h !== "forecast" && h !== "login")));
  const landing = h === "", auth = h === "login";
  if (h === "profile" && !app.user) { app.go("login"); return; }
  $("side").hidden = landing || auth; $("shell").classList.toggle("ws", !landing && !auth);
  document.body.classList.toggle("is-landing", landing); document.body.classList.toggle("is-auth", auth);
  if (!landing && !auth) {
    const nav = $("nav"); nav.innerHTML = "";
    const on = (r) => h === r || (r === "season" && EXPERT.includes(h));
    MAIN.forEach((r) => { const [, l, ic] = NAV.find((n) => n[0] === r); nav.appendChild(el("a", { href: "#/" + r, class: on(r) ? "on" : "", "aria-current": on(r) ? "page" : false }, [icon(ic), tr(NAMES[r] || l)])); });
  }
  placeLine();
  const name = PAGES[landing ? "" : h] || (landing ? "landing" : null);
  if (!name) { main.replaceChildren(errorBox("That page does not exist.")); return; }
  if (main.childNodes.length && !landing) { main.classList.add("out"); await new Promise((r) => setTimeout(r, 150)); if (t !== token) return; }
  const ld = loading(landing ? "Starting…" : "Reading Earth's signals for this field. The first time for a place can take a little while; after that it is instant.");
  main.classList.remove("out"); main.replaceChildren(ld);          // the loading message must be visible at once (it used to stay faded out = a blank page)
  const sec = el("p", { class: "hint", style: "text-align:center" }); let s0 = 0; const tick = setInterval(() => { s0++; sec.textContent = s0 > 3 ? `Still working… ${s0} s. Sources that are slow are skipped after a short wait.` : ""; }, 1000);
  if (!landing) ld.append(sec);
  try {
    const m = await load(name);
    const node = await m.render(app).finally(() => clearInterval(tick));
    if (t !== token) return;
    main.classList.remove("out"); main.replaceChildren(node); if (m.after) m.after(node, app); enter(node);
    scrollTo(0, 0); main.focus({ preventScroll: true });
  } catch (e) { clearInterval(tick); main.classList.remove("out"); if (t === token) main.replaceChildren(errorBox(e.message, route)); }
}

async function boot() {
  settings(); badge(); cursor(); initFx(); applyLogo();
  api.health().then((h) => { app.serverAi = !!h.ai_enabled; app.aiHint = h.ai_hint || ""; app.aiProv = h.ai_provider === "local" ? `local model ${h.ai_model}` : h.ai_provider === "gemini" ? "Gemini key on the server" : ""; badge(); }).catch(() => {});
  const ql = $("quick-lang"); let tTimer = null, tShown = false;
  const tstat = (s, msg) => { const b = $("tr-note"); if (!b) return;                      // steady badge: shown only if translating takes a while, never flickers
    if (s === "working") { if (!tTimer && !tShown) tTimer = setTimeout(() => { tTimer = null; tShown = true; b.hidden = false; b.textContent = "🌐 Translating…"; }, 900); return; }
    clearTimeout(tTimer); tTimer = null;
    if (s === "off") { tShown = false; b.hidden = true; return; }
    if (s === "error") { b.hidden = false; b.style.cursor = "pointer"; b.textContent = "⚠ Some text could not be translated. Tap to retry"; b.title = msg || ""; b.onclick = () => { tstat.shown = false; setTranslation(curLang(), tstat); }; if (!tstat.shown) { tstat.shown = true; toast(msg); } return; }
    if (tShown) { b.textContent = "🌐 Translated"; b.title = "Built-in word lists, plus machine translation for the rest. It can contain mistakes."; b.style.cursor = "default"; b.onclick = null; setTimeout(() => { if (!tTimer) b.hidden = true; tShown = false; }, 2500); } };
  const fillLangs = (sel, cur) => { sel.replaceChildren(...LANGS.map(([v, label]) => el("option", { value: v, text: v === "Auto" ? "🌐 " + label : label, selected: v === cur }))); };
  fillLangs(ql, curLang()); if ($("lang")) fillLangs($("lang"), curLang());
  const applyLang = (v) => { setLang(v); ql.value = v; if ($("lang")) $("lang").value = v; document.querySelector('label[for="field-select"]').textContent = tr("Active field"); tstat.shown = false; app.cache.clear(); route(); setTimeout(() => setTranslation(v, tstat), 60); };
  app.applyLang = applyLang; ql.onchange = () => applyLang(ql.value);
  setTimeout(() => setTranslation(curLang(), tstat), 800);
  mountTerra(app);
  bigText(bigOn()); $("big-btn").onclick = () => bigText(!bigOn()); document.querySelector('label[for="field-select"]').textContent = tr("Active field");
  $("field-select").onchange = (e) => { app.fieldId = e.target.value; store.set(keys.FIELDN, app.fieldId); route(); };
  addEventListener("hashchange", route); addEventListener("resize", placeLine);
  try {
    const me = await api.me(); app.user = me.user;
    [app.fields, app.crops] = await Promise.all([api.fields(), api.crops()]);
    app.fieldId = store.get(keys.FIELDN) || app.fields[0].id;
    if (!app.fields.find((f) => f.id === app.fieldId)) app.fieldId = app.fields[0].id;
    app.drawFieldSelect(); drawUser();
    const pend = store.get("ta-pending-field");
    if (pend && app.user) { try { const saved = await api.saveField(JSON.parse(pend)); store.del("ta-pending-field"); await app.reloadFields(saved.id); toast("Your journey field was saved."); } catch (e) { /* keep it for next time */ } }
  } catch (e) { $("main").replaceChildren(errorBox(e.message, () => location.reload())); return; }
  app.startJourney = () => { store.del("ta-journey"); journey(app); };
  const so = $("start-over"); if (so) so.onclick = () => app.startJourney();            // always one tap away: language, place, game
  route();
  if (!/login/.test(location.hash) && !sessionStorage.getItem("ta-skip")) journey(app);        // every launch: TerraAdapt splash, then language, then your saved place (or a new one), then the game
}
boot();
