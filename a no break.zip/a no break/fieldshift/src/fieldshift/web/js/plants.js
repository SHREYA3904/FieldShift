// Realistic-looking field scene: the crop's colour, posture and fruit follow the real simulated water stress, heat and frost.
import { svg } from "./ui.js";

const mixc = (a, b, t) => { t = Math.max(0, Math.min(1, t)); return [0, 1, 2].map((i) => Math.round(a[i] + (b[i] - a[i]) * t)); };
const rgb = (c) => `rgb(${c[0]},${c[1]},${c[2]})`;
const rng = (seed) => { let s = (seed * 9301 + 49297) % 233280; return () => ((s = (s * 9301 + 49297) % 233280) / 233280); };
const KIND = { apple: "tree", grape: "vine", tomato: "tomato", maize: "maize", sunflower: "sunflower", potato: "bush", cotton: "bush", alfalfa: "low", groundnut: "bush" };
export const kindOf = (crop) => KIND[crop.id] || (crop.family === "cereal" ? "cereal" : crop.family === "forage" ? "low" : "bush");

// Colour of leaves for this plant: lush green -> yellow -> dry brown -> dead; pale and frosted when frozen.
function leafPalette(dmg, wilt, frost) {
  const lush = [[34, 120, 46], [92, 176, 66]], yellow = [[150, 150, 50], [205, 190, 80]], dry = [[105, 78, 44], [150, 112, 62]], dead = [[70, 56, 44], [96, 78, 58]];
  const t = Math.max(dmg, wilt * 0.6);
  let a = t < 0.5 ? mixc(lush[0], yellow[0], t * 2) : mixc(yellow[0], dry[0], (t - 0.5) * 2), b = t < 0.5 ? mixc(lush[1], yellow[1], t * 2) : mixc(yellow[1], dry[1], (t - 0.5) * 2);
  if (dmg >= 0.9) { a = dead[0]; b = dead[1]; }
  if (frost > 0) { a = mixc(a, [150, 170, 168], frost * 0.8); b = mixc(b, [215, 232, 232], frost * 0.8); }
  return [rgb(a), rgb(b)];
}
const blade = (len, w, ang, col, col2, curl = 0) => `<g transform="rotate(${ang})"><path d="M0 0 Q ${len * 0.35} ${-w} ${len} ${curl} Q ${len * 0.4} ${w * 0.6} 0 0Z" fill="${col}"/><path d="M0 0 Q ${len * 0.5} ${-w * 0.25} ${len} ${curl}" stroke="${col2}" stroke-width="${Math.max(0.6, w * 0.22)}" fill="none" opacity=".75"/></g>`;
const leaf = (len, w, ang, col, col2) => `<g transform="rotate(${ang})"><ellipse cx="${len / 2}" cy="0" rx="${len / 2}" ry="${w}" fill="${col}"/><path d="M0 0 L${len} 0" stroke="${col2}" stroke-width="${Math.max(.6, w * .25)}" opacity=".7"/></g>`;

function cereal(r, g, dmg, wilt, frost, sc, id) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (16 + g * 78) * sc; let o = "";
  const ripe = Math.max(0, (g - 0.55) / 0.45), earCol = dmg >= 0.9 ? "#5a4630" : rgb(mixc([132, 178, 78], [224, 182, 66], ripe * (1 - dmg * 0.6)));
  for (let s = 0; s < 4; s++) {
    const x = (s - 1.5) * 5 * sc, lean = (r() - 0.5) * 8 + wilt * (s % 2 ? 22 : -22) * (1 + dmg), top = H * (0.85 + r() * 0.2);
    o += `<g transform="translate(${x},0)"><path d="M0 0 Q ${lean * 0.3} ${-top * 0.5} ${lean} ${-top}" stroke="${c1}" stroke-width="${1.7 * sc}" fill="none" stroke-linecap="round"/>`;
    for (let k = 1; k <= 3; k++) { const y = -top * (k * 0.24), side = k % 2 ? 1 : -1; o += `<g transform="translate(${lean * k * 0.08},${y})">${blade(top * (0.5 - k * 0.07), 2.6 * sc * (1 - wilt * 0.4), side > 0 ? -28 + wilt * 70 : 208 - wilt * 70, c1, c2, wilt * 8 * side)}</g>`; }
    if (g > 0.5) o += `<g transform="translate(${lean},${-top}) rotate(${lean * 0.8})"><ellipse cx="0" cy="${-7 * sc}" rx="${2.6 * sc}" ry="${8 * sc}" fill="${earCol}"/>${[-1, 1].map((m) => [0, 1, 2, 3].map((q) => `<path d="M${m * 1.4 * sc} ${-3 * sc - q * 3.3 * sc} l${m * 2 * sc} ${-7 * sc}" stroke="${earCol}" stroke-width=".6"/>`).join("")).join("")}</g>`;
    o += "</g>";
  }
  return o;
}
function maize(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (14 + g * 100) * sc; let o = `<path d="M0 0 L${wilt * -6} ${-H}" stroke="${c1}" stroke-width="${3 * sc}" stroke-linecap="round"/>`;
  for (let k = 1; k <= 6; k++) { const y = -H * (k * 0.14), side = k % 2 ? 1 : -1; o += `<g transform="translate(${wilt * -k},${y})">${blade(H * 0.42, 4.2 * sc * (1 - wilt * 0.4), side > 0 ? -22 + wilt * 60 : 202 - wilt * 60, c1, c2, side * (4 + wilt * 12))}</g>`; }
  if (g > 0.5) o += `<g transform="translate(${wilt * -6},${-H})">${[-30, -8, 14].map((a) => `<path d="M0 0 l${Math.sin(a / 60) * 16 * sc} ${-15 * sc}" stroke="#d9c58a" stroke-width="1.1"/>`).join("")}</g>`;
  if (g > 0.68) { const ripe = (g - 0.68) / 0.32; o += `<g transform="translate(${3 * sc},${-H * 0.5}) rotate(20)"><ellipse rx="${3 * sc}" ry="${10 * sc}" fill="${dmg >= 0.9 ? "#5a4630" : "#7da64b"}"/><ellipse rx="${1.9 * sc}" ry="${7.5 * sc}" cx="0" cy="${-2 * sc}" fill="${rgb(mixc([205, 212, 120], [236, 190, 52], ripe))}" opacity="${dmg >= 0.9 ? 0 : 1}"/></g>`; }
  return o;
}
function sunflower(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (14 + g * 96) * sc, bend = wilt * 24 + dmg * 14; let o = `<path d="M0 0 Q ${bend * 0.2} ${-H * 0.6} ${bend} ${-H}" stroke="${c1}" stroke-width="${3 * sc}" fill="none" stroke-linecap="round"/>`;
  for (let k = 1; k <= 4; k++) { const y = -H * k * 0.2, side = k % 2 ? 1 : -1; o += `<g transform="translate(${bend * k * 0.06},${y})">${leaf(H * 0.28, 6 * sc * (1 - wilt * 0.4), side > 0 ? -20 + wilt * 55 : 200 - wilt * 55, c1, c2)}</g>`; }
  if (g > 0.4) { const open = Math.min(1, (g - 0.4) / 0.3), pet = dmg >= 0.9 ? "#7a6a45" : "#f1c232"; o += `<g transform="translate(${bend},${-H}) rotate(${bend * 1.2})">${Array.from({ length: 14 }, (_, i) => `<ellipse cx="0" cy="${-(8 + 5 * open) * sc}" rx="${2.4 * sc * open}" ry="${6 * sc * open}" fill="${pet}" transform="rotate(${i * 25.7})"/>`).join("")}<circle r="${7 * sc}" fill="${g > 0.85 ? "#4a3220" : "#6b4a1e"}"/></g>`; }
  return o;
}
function bush(r, g, dmg, wilt, frost, sc, id) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (8 + g * 40) * sc; let o = "";
  for (let k = 0; k < 11; k++) { const a = -150 + k * 12 + (r() - 0.5) * 8 + wilt * (k < 5 ? -25 : 25); o += `<g transform="translate(0,${-2 * sc}) rotate(${a})">${leaf(H * (0.7 + r() * 0.5), 4.4 * sc * (1 - wilt * 0.45), 0, c1, c2)}</g>`; }
  if (g > 0.35 && g < 0.75 && dmg < 0.8) o += Array.from({ length: 5 }, (_, i) => `<circle cx="${(r() - 0.5) * H * 1.6}" cy="${-H * (0.4 + r() * 0.6)}" r="${1.8 * sc}" fill="${id === "potato" ? "#e8e0f5" : "#f4efe0"}"/>`).join("");
  if (g >= 0.75 && dmg < 0.9) o += Array.from({ length: 4 }, () => `<ellipse cx="${(r() - 0.5) * H * 1.4}" cy="${-H * (0.15 + r() * 0.25)}" rx="${1.6 * sc}" ry="${3.2 * sc}" fill="#b8a05a"/>`).join("");
  return o;
}
function low(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (6 + g * 24) * sc; let o = "";
  for (let k = 0; k < 16; k++) { const a = -165 + k * 10 + (r() - 0.5) * 6 + wilt * (k < 8 ? -18 : 18); o += `<g transform="rotate(${a})">${leaf(H * (0.8 + r() * 0.6), 3 * sc, 0, c1, c2)}</g>`; }
  if (g > 0.4 && dmg < 0.8) o += Array.from({ length: 6 }, () => `<circle cx="${(r() - 0.5) * H * 1.8}" cy="${-H * (0.7 + r() * 0.5)}" r="${1.7 * sc}" fill="#9a6fd0"/>`).join("");
  return o;
}
function tomato(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (10 + g * 60) * sc; let o = `<path d="M${-8 * sc} 0 L${-8 * sc} ${-H * 1.05}" stroke="#a98253" stroke-width="1.6"/><path d="M0 0 Q ${wilt * -8} ${-H * 0.6} ${wilt * -14} ${-H}" stroke="${c1}" stroke-width="${2.2 * sc}" fill="none"/>`;
  for (let k = 0; k < 12; k++) { const y = -H * (0.15 + k * 0.075), side = k % 2 ? 1 : -1; o += `<g transform="translate(${wilt * -k},${y})">${leaf(H * 0.3, 3.6 * sc * (1 - wilt * 0.4), side > 0 ? -35 + wilt * 60 : 215 - wilt * 60, c1, c2)}</g>`; }
  if (dmg < 0.9) for (let k = 0; k < 6; k++) {
    const x = (r() - 0.5) * H * 0.7, y = -H * (0.25 + r() * 0.5);
    if (g > 0.28 && g < 0.5) o += `<circle cx="${x}" cy="${y}" r="${1.8 * sc}" fill="#f3d23a"/>`;
    else if (g >= 0.5) o += `<circle cx="${x}" cy="${y}" r="${(2.2 + (g - 0.5) * 5) * sc}" fill="${rgb(mixc([110, 170, 70], [214, 48, 38], (g - 0.62) / 0.3))}"/>`;
  }
  return o;
}
function vine(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (14 + g * 40) * sc; let o = `<path d="M${-32 * sc} ${-48 * sc} L${32 * sc} ${-48 * sc}" stroke="#8d6b45" stroke-width=".8"/><path d="M${-32 * sc} 0 L${-32 * sc} ${-52 * sc} M${32 * sc} 0 L${32 * sc} ${-52 * sc}" stroke="#7a5a38" stroke-width="2.4"/><path d="M0 0 Q 3 ${-H * 0.5} 0 ${-H}" stroke="#6b4b2e" stroke-width="${2.2 * sc}" fill="none"/>`;
  for (let k = 0; k < 16; k++) { const x = (r() - 0.5) * 60 * sc, y = -H * (0.35 + r() * 0.7); o += `<g transform="translate(${x},${y}) rotate(${r() * 360})"><circle r="${(4 + g * 2.5) * sc * (1 - wilt * 0.35)}" fill="${c1}"/><circle r="${2 * sc}" cx="${sc}" cy="${-sc}" fill="${c2}" opacity=".6"/></g>`; }
  if (g > 0.55 && dmg < 0.9) for (let k = 0; k < 5; k++) { const x = (r() - 0.5) * 44 * sc, y = -H * 0.55, col = rgb(mixc([120, 170, 80], [76, 38, 110], (g - 0.7) / 0.28)); o += `<g transform="translate(${x},${y})">${[[0, 0], [-2, 3], [2, 3], [0, 6], [-1.5, 9]].map(([a, b]) => `<circle cx="${a * sc}" cy="${b * sc}" r="${2.1 * sc}" fill="${col}"/>`).join("")}</g>`; }
  return o;
}
function tree(r, g, dmg, wilt, frost, sc) {
  const [c1, c2] = leafPalette(dmg, wilt, frost), H = (26 + g * 26) * sc, R = (9 + Math.min(1, g * 1.6) * 26) * sc, bare = dmg >= 0.9 || g < 0.12; let o = `<path d="M${-3 * sc} 0 Q ${-2 * sc} ${-H * 0.5} ${-sc} ${-H} L${2 * sc} ${-H} Q ${3 * sc} ${-H * 0.5} ${4 * sc} 0Z" fill="#6a4a2c"/><path d="M0 ${-H * 0.7} l${-12 * sc} ${-9 * sc} M0 ${-H * 0.8} l${12 * sc} ${-10 * sc}" stroke="#6a4a2c" stroke-width="${2 * sc}" stroke-linecap="round"/>`;
  const cx = 0, cy = -H - R * 0.35;
  if (!bare) { for (let k = 0; k < 15; k++) { const a = r() * 6.283, d = Math.sqrt(r()) * R; o += `<circle cx="${cx + Math.cos(a) * d * 1.15}" cy="${cy + Math.sin(a) * d * 0.8 + wilt * R * 0.25 * (Math.sin(a) > 0 ? 1 : 0)}" r="${R * 0.34}" fill="${k % 3 ? c1 : c2}"/>`; } }
  else o += Array.from({ length: 6 }, () => `<path d="M0 ${-H} l${(r() - 0.5) * R * 2} ${-R * (0.5 + r() * 0.7)}" stroke="#6a4a2c" stroke-width="1.3"/>`).join("");
  if (g >= 0.15 && g < 0.38 && dmg < 0.8) o += Array.from({ length: 16 }, () => `<circle cx="${(r() - 0.5) * R * 2}" cy="${cy + (r() - 0.5) * R * 1.4}" r="${1.7 * sc}" fill="${r() > 0.5 ? "#fff6f6" : "#f6c9d6"}"/>`).join("");
  if (g >= 0.38 && dmg < 0.9) { const rip = Math.max(0, (g - 0.72) / 0.28), col = rgb(mixc([120, 170, 70], [208, 36, 36], rip)); o += Array.from({ length: 9 }, () => `<circle cx="${(r() - 0.5) * R * 1.7}" cy="${cy + (r() - 0.3) * R * 1.2}" r="${(2 + rip * 2.6) * sc}" fill="${col}"/>`).join(""); }
  return o;
}
const DRAW = { cereal, maize, sunflower, bush, low, tomato, vine, tree };

export function stageLabel(kind, g) {
  const t = kind === "tree" ? ["Dormant buds", "In blossom", "Fruit setting", "Fruit growing", "Ripe, ready to pick"] : kind === "cereal" ? ["Seedling", "Growing", "Flowering", "Grain filling", "Ripening"] : ["Seedling", "Growing", "Flowering", "Fruit/pod filling", "Ripening"];
  return t[g < 0.12 ? 0 : g < 0.38 ? 1 : g < 0.55 ? 2 : g < 0.85 ? 3 : 4];
}

export function buildScene() {
  const s = svg("svg", { viewBox: "0 0 600 300", role: "img", "aria-label": "Field scene", style: "width:100%;border-radius:14px;display:block" });
  s.innerHTML = `<defs><linearGradient id="gsky" x1="0" y1="0" x2="0" y2="1"><stop id="sky1" offset="0" stop-color="#5b8fd6"/><stop id="sky2" offset="1" stop-color="#cfe6ff"/></linearGradient>
    <linearGradient id="gsoil" x1="0" y1="0" x2="0" y2="1"><stop id="soil1" offset="0" stop-color="#6b4a2f"/><stop id="soil2" offset="1" stop-color="#3f2a1a"/></linearGradient>
    <radialGradient id="gsun"><stop offset="0" stop-color="#fff7c2"/><stop offset="1" stop-color="#ffd36b" stop-opacity="0"/></radialGradient></defs>
    <rect width="600" height="300" fill="url(#gsky)"/><circle id="sunglow" cx="500" cy="58" r="70" fill="url(#gsun)"/><circle id="sun" cx="500" cy="58" r="24" fill="#ffd36b"/>
    <path d="M0 196 Q 90 168 190 190 T 400 184 T 600 192 L600 215 L0 215Z" fill="#6f8f7a" opacity=".55"/><path d="M0 206 Q 120 186 260 204 T 600 200 L600 220 L0 220Z" fill="#587a5e" opacity=".7"/>
    <g class="drift"><g id="clouds"></g></g><rect id="soil" y="212" width="600" height="88" fill="url(#gsoil)"/><g id="furrows"></g><g id="cracks"></g><rect id="frostsoil" y="212" width="600" height="88" fill="#e8f3ff" opacity="0"/>
    <g class="sway"><g id="plants"></g></g><g id="heat"></g><g class="fall"><g id="rain"></g></g><rect id="frostveil" width="600" height="300" fill="#dff0ff" opacity="0"/>
    <rect x="10" y="10" width="250" height="52" rx="10" fill="#0b0b18" opacity=".45"/><text id="daytxt" x="22" y="32" fill="#fff" font-size="16" font-weight="700"></text><text id="tmptxt" x="22" y="52" fill="#e8ecff" font-size="13"></text>
    <g id="chip"><rect id="chipbg" x="10" y="262" width="270" height="28" rx="14" fill="#1f7a3a"/><text id="chiptxt" x="24" y="281" fill="#fff" font-size="14" font-weight="700"></text></g>`;
  return s;
}

// days: all days played so far, i: index to draw. crop: {id, family, cold_crit, heat_crit}. irrigatedNow: show sprinklers.
export function draw(scene, days, i, crop, dateText) {
  const d = days[i], q = (id) => scene.querySelector("#" + id), kind = kindOf(crop);
  // Real frost = at or below 0 °C (and below the crop's limit). Merely cooler than a tropical crop likes is "chill": it weakens, never destroys.
  let cum = 0, frostHits = 0, chillHits = 0; for (let k = 0; k <= i; k++) { cum += days[k].stress; if (days[k].tmin <= 0 && days[k].tmin < crop.cold_crit) frostHits++; else if (days[k].tmin < crop.cold_crit) chillHits++; }
  const frostNow = d.tmin <= 0 && d.tmin < crop.cold_crit, chillNow = !frostNow && d.tmin < crop.cold_crit, frostDmg = Math.min(1, frostHits / 3), chillDmg = Math.min(0.55, chillHits * 0.04);
  const dmg = Math.max(Math.min(1, (cum / Math.max(i + 1, 40)) / 0.45), frostDmg, chillDmg), wilt = Math.min(1, d.stress * 3), g = d.growth;
  const heat = Math.max(0, Math.min(1, (d.tmax - 15) / 28)), cold = d.tmax < 6 ? 1 : 0;
  q("sky1").setAttribute("stop-color", rgb(frostNow || cold ? [128, 150, 178] : mixc([86, 140, 214], [232, 132, 70], Math.max(0, heat - 0.45) * 2)));
  q("sky2").setAttribute("stop-color", rgb(frostNow || cold ? [214, 226, 238] : mixc([205, 230, 255], [255, 214, 160], Math.max(0, heat - 0.45) * 2)));
  q("sun").setAttribute("fill", rgb(mixc([255, 232, 150], [255, 120, 44], heat))); q("sun").setAttribute("r", 20 + heat * 12); q("sunglow").setAttribute("opacity", d.rain > 1 ? 0.15 : 0.9);
  let cl = ""; const cr = rng(3), nCl = d.rain > 0.5 ? 6 : 3, dark = d.rain > 0.5 ? mixc([225, 232, 244], [112, 124, 144], Math.min(1, d.rain / 14)) : [244, 248, 255];
  for (let k = 0; k < nCl; k++) { const x = 40 + k * (500 / nCl) + cr() * 30, y = 40 + cr() * 50, s = 0.8 + cr() * 0.7; cl += `<g opacity="${d.rain > 0.5 ? 0.95 : 0.55}" fill="${rgb(dark)}"><ellipse cx="${x}" cy="${y}" rx="${50 * s}" ry="${15 * s}"/><ellipse cx="${x + 24 * s}" cy="${y - 10 * s}" rx="${32 * s}" ry="${15 * s}"/><ellipse cx="${x - 22 * s}" cy="${y - 5 * s}" rx="${26 * s}" ry="${12 * s}"/></g>`; }
  q("clouds").innerHTML = cl;
  // soil: darker when wet, cracked when dry
  const wet = d.water; q("soil1").setAttribute("stop-color", rgb(mixc([160, 120, 76], [74, 50, 32], wet))); q("soil2").setAttribute("stop-color", rgb(mixc([116, 84, 52], [44, 30, 20], wet)));
  let fur = ""; for (let k = 0; k < 5; k++) fur += `<path d="M${-40 + k * 20} 300 L${300 + (k - 2) * 52} 214" stroke="#000" stroke-opacity=".12" stroke-width="3"/>`; q("furrows").innerHTML = fur;
  let cr2 = "", cc = rng(11); if (wet < 0.3) for (let k = 0; k < 14 * (0.3 - wet) / 0.3 + 3; k++) { const x = cc() * 600, y = 222 + cc() * 70; cr2 += `<path d="M${x} ${y} l${cc() * 18 - 9} ${cc() * 8} l${cc() * 16 - 8} ${cc() * 10}" stroke="#2a1a0e" stroke-width="1.2" fill="none" opacity="${0.6 * (1 - wet / 0.3)}"/>`; } q("cracks").innerHTML = cr2;
  q("frostsoil").setAttribute("opacity", frostNow ? 0.55 : 0); q("frostveil").setAttribute("opacity", frostNow ? 0.18 : 0);
  // plants in perspective rows
  let pl = "", rows = kind === "tree" ? [[212, 0.62, 3, 100], [236, 0.85, 3, 60], [270, 1.15, 2, 120]] : kind === "vine" ? [[226, 0.7, 3, 100], [262, 1.0, 3, 60]] : [[222, 0.55, 12, 20], [242, 0.78, 9, 30], [272, 1.05, 7, 40]];
  let seed = 1; for (const [y, sc, n, pad] of rows) for (let k = 0; k < n; k++) { const x = pad + (k + 0.5) * ((600 - 2 * pad) / n) + ((seed * 13) % 7 - 3); pl += `<g transform="translate(${x},${y})" opacity="${kind === "tree" || sc > .9 ? 1 : .95}">${DRAW[kind](rng(seed++), g, dmg, wilt, frostNow ? 1 : 0, sc * (kind === "tree" ? 1 : 1), crop.id)}</g>`; }
  if (frostNow) pl += Array.from({ length: 40 }, (_, k) => `<circle cx="${(k * 53) % 600}" cy="${180 + (k * 37) % 110}" r="1.3" fill="#fff" opacity=".9"/>`).join("");
  q("plants").innerHTML = pl;
  // heat shimmer
  q("heat").innerHTML = d.tmax >= crop.heat_crit - 2 ? [0, 1, 2, 3].map((k) => `<path d="M0 ${200 + k * 9} q 20 -6 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0" stroke="#fff" stroke-opacity=".12" stroke-width="2" fill="none"/>`).join("") : "";
  // rain and irrigation
  let rn = "", rr = rng(Math.round(d.rain * 10) + i); const drops = Math.min(90, Math.round(d.rain * 6));
  for (let k = 0; k < drops; k++) { const x = rr() * 620, y = 60 + rr() * 170; rn += `<line x1="${x}" y1="${y}" x2="${x - 6}" y2="${y + 18}" stroke="#d6ecff" stroke-width="1.6" opacity="${0.4 + rr() * 0.5}"/>`; }
  if (d.irrigated) for (let k = 0; k < 5; k++) { const x = 60 + k * 120; rn += `<rect x="${x - 2}" y="196" width="4" height="18" fill="#8a8f99"/>` + Array.from({ length: 9 }, (_, j) => `<path d="M${x} 196 q ${(j - 4) * 9} ${-26 - (j % 3) * 8} ${(j - 4) * 16} 36" stroke="#8fd1ff" stroke-width="1.6" fill="none" opacity=".8"/>`).join(""); }
  q("rain").innerHTML = rn;
  q("daytxt").textContent = dateText; q("tmptxt").textContent = `${d.tmin}° to ${d.tmax}°C · rain ${d.rain} mm`;
  let label, col;
  if (dmg >= 0.9) { label = frostHits >= 3 ? "❄ Frost has destroyed the crop" : "☠ Crop lost to drought"; col = "#7a2a22"; }
  else if (frostNow) { label = "❄ Frost tonight: leaves damaged"; col = "#2b5f8f"; }
  else if (chillNow) { label = "🥶 Too cold for this crop at night"; col = "#3f6f9a"; }
  else if (d.tmax >= crop.heat_crit) { label = "🔥 Heat stress: " + stageLabel(kind, g); col = "#b5651d"; }
  else if (d.stress > 0.15) { label = "🥀 Wilting: needs water now"; col = "#a8431f"; }
  else if (d.stress > 0.05) { label = "💧 Thirsty: leaves curling"; col = "#a07a1a"; }
  else if (dmg > 0.35) { label = "⚠ Weakened by earlier stress · " + stageLabel(kind, g); col = "#8a6a1a"; }
  else { label = "🌱 Healthy · " + stageLabel(kind, g); col = "#1f7a3a"; }
  q("chiptxt").textContent = label; q("chipbg").setAttribute("fill", col); q("chipbg").setAttribute("width", Math.max(200, label.length * 8.2 + 30));
}
