// Ambient motion: particle field that reacts to the cursor and scroll, magnetic buttons, card spotlight, scroll progress,
// parallax, chart entrance animations. Everything respects prefers-reduced-motion.
const reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
const mouse = { x: -1000, y: -1000, vx: 0, vy: 0 };
let scrollV = 0, lastY = scrollY;

export function initFx() {
  const bar = document.createElement("div"); bar.id = "progress"; document.body.appendChild(bar);
  const cv = document.createElement("canvas"); cv.id = "fx"; document.body.prepend(cv);
  const g = cv.getContext("2d"); let W = 0, H = 0, P = [];
  const resize = () => {
    const d = Math.min(devicePixelRatio || 1, 3); W = innerWidth; H = innerHeight; cv.width = W * d; cv.height = H * d; cv.style.width = W + "px"; cv.style.height = H + "px"; g.setTransform(d, 0, 0, d, 0, 0);
    const n = reduce ? 30 : Math.min(150, Math.round(W * H / 14000));
    P = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, z: Math.random() * 0.8 + 0.2, a: Math.random() * 6.28, c: Math.random() < 0.28 ? 1 : 0 }));
  };
  resize(); addEventListener("resize", resize);
  addEventListener("pointermove", (e) => { mouse.vx = e.clientX - mouse.x; mouse.vy = e.clientY - mouse.y; mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
  addEventListener("pointerleave", () => { mouse.x = mouse.y = -1000; });
  let on = true; document.addEventListener("visibilitychange", () => { on = !document.hidden; if (on) requestAnimationFrame(tick); });
  function tick(t) {
    if (!on) return; requestAnimationFrame(tick);
    g.clearRect(0, 0, W, H);
    scrollV += (Math.abs(scrollY - lastY) - scrollV) * 0.12; lastY = scrollY;
    const boost = 1 + Math.min(scrollV * 0.15, 5);
    for (const p of P) {
      p.a += 0.002 * p.z; p.x += Math.cos(p.a + t * 0.00012) * 0.18 * p.z * boost; p.y += Math.sin(p.a * 1.3 + t * 0.00009) * 0.18 * p.z * boost - scrollV * 0.04 * p.z * Math.sign(scrollY - lastY || 1) * 0;
      const dx = p.x - mouse.x, dy = p.y - mouse.y, d2 = dx * dx + dy * dy;
      if (d2 < 18000 && !reduce) { const f = (1 - d2 / 18000) * 1.6; p.x += dx / Math.sqrt(d2 + 1) * f; p.y += dy / Math.sqrt(d2 + 1) * f; }
      if (p.x < -10) p.x = W + 10; if (p.x > W + 10) p.x = -10; if (p.y < -10) p.y = H + 10; if (p.y > H + 10) p.y = -10;
      const near = d2 < 26000 ? 1 - d2 / 26000 : 0;
      g.beginPath(); g.fillStyle = p.c ? `rgba(155,123,255,${0.25 + p.z * 0.4 + near * 0.4})` : `rgba(242,166,90,${0.2 + p.z * 0.4 + near * 0.5})`;
      g.arc(p.x, p.y, 0.8 + p.z * 1.4 + near * 1.6, 0, 6.283); g.fill();
      if (near > 0.25 && !reduce) { g.strokeStyle = `rgba(242,166,90,${near * 0.35})`; g.lineWidth = 0.6; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(mouse.x, mouse.y); g.stroke(); }
    }
  }
  requestAnimationFrame(tick);

  // occasional shooting star
  if (!reduce) {
    const shoot = () => {
      if (!document.hidden) {
        const e = document.createElement("div"); e.className = "shoot"; const y = Math.random() * innerHeight * 0.5, x = innerWidth * (0.3 + Math.random() * 0.6), ang = 18 + Math.random() * 14;
        e.style.cssText = `left:${x}px;top:${y}px;rotate:${ang}deg`; document.body.appendChild(e);
        e.animate([{ opacity: 0, transform: "translateX(0)" }, { opacity: 1, offset: 0.15 }, { opacity: 0, transform: "translateX(-380px)" }], { duration: 1100, easing: "ease-out" }).onfinish = () => e.remove();
      }
      setTimeout(shoot, 7000 + Math.random() * 9000);
    };
    setTimeout(shoot, 4000);
  }

  // scroll progress and landing parallax
  const onScroll = () => {
    const m = document.documentElement.scrollHeight - innerHeight; bar.style.transform = `scaleX(${m > 0 ? scrollY / m : 0})`;
    if (document.body.classList.contains("is-landing") && !reduce) document.querySelectorAll(".story").forEach((s) => { const r = s.getBoundingClientRect(), c = (r.top + r.height / 2 - innerHeight / 2) / innerHeight; s.querySelectorAll(".inner>*").forEach((n, i) => n.style.setProperty("--py", (c * (i ? -50 : 36)).toFixed(1) + "px")); });
  };
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  // magnetic buttons and card spotlight
  document.addEventListener("pointermove", (e) => {
    const card = e.target.closest && e.target.closest(".card");
    if (card) { const r = card.getBoundingClientRect(); card.style.setProperty("--mx", e.clientX - r.left + "px"); card.style.setProperty("--my", e.clientY - r.top + "px"); }
    if (reduce) return;
    document.querySelectorAll(".mag.on").forEach((b) => { if (b !== (e.target.closest && e.target.closest(".mag"))) { b.classList.remove("on"); b.style.transform = ""; } });
    const b = e.target.closest && e.target.closest(".mag");
    if (b) { const r = b.getBoundingClientRect(); b.classList.add("on"); b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.18}px,${(e.clientY - r.top - r.height / 2) * 0.28}px)`; }
  }, { passive: true });
}

// wrap text into words/letters for staggered entrance
export function splitText(node) {
  if (node.dataset.split) return node; node.dataset.split = "1";
  const walk = (n, state) => {
    [...n.childNodes].forEach((c) => {
      if (c.nodeType === 3) {
        const frag = document.createDocumentFragment();
        c.textContent.split(/(\s+)/).forEach((w) => {
          if (!w) return; if (/^\s+$/.test(w)) { frag.appendChild(document.createTextNode(" ")); return; }
          const wd = document.createElement("span"); wd.className = "word";
          [...w].forEach((ch) => { const s = document.createElement("span"); s.className = "ch"; s.style.setProperty("--c", state.i++); s.textContent = ch; wd.appendChild(s); });
          frag.appendChild(wd);
        });
        n.replaceChild(frag, c);
      } else if (c.nodeType === 1) walk(c, state);
    });
  };
  node.setAttribute("aria-label", node.textContent); walk(node, { i: 0 }); return node;
}

// after a page mounts: stagger its blocks, draw lines, count numbers
export function enter(root) {
  root.querySelectorAll(".page > *").forEach((n, i) => n.style.setProperty("--i", Math.min(i, 10)));
  root.querySelectorAll(".heat .c").forEach((n, i) => n.style.setProperty("--i", i));
  root.querySelectorAll(".btn.solid, .hero-cta .btn").forEach((b) => b.classList.add("mag"));
  if (reduce) return;
  requestAnimationFrame(() => {
    root.querySelectorAll(".chart svg polyline").forEach((pl) => {
      if (pl.getAttribute("stroke-dasharray")) return;
      try { const L = pl.getTotalLength(); pl.animate([{ strokeDasharray: `${L} ${L}`, strokeDashoffset: L }, { strokeDasharray: `${L} ${L}`, strokeDashoffset: 0 }], { duration: 1500, easing: "cubic-bezier(.2,.8,.2,1)", fill: "none" }); } catch (e) { /* ignore */ }
    });
    root.querySelectorAll(".kpi b").forEach((b) => {
      const m = b.textContent.match(/^([+-]?)(\d+(?:\.\d+)?)(.*)$/); if (!m) return;
      const to = parseFloat(m[2]), dec = (m[2].split(".")[1] || "").length, t0 = performance.now();
      (function f(t) { const k = Math.min(1, (t - t0) / 1100), e = 1 - Math.pow(1 - k, 3); b.textContent = m[1] + (to * e).toFixed(dec) + m[3]; if (k < 1) requestAnimationFrame(f); })(t0);
    });
  });
}
