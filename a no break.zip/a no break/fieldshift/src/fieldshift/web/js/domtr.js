// Translates everything on screen into the chosen language, on demand, using the farmer's Gemini key.
// Original English is remembered per node, so switching languages (or back to English) always starts from the English source.
import { api, store, keys } from "./api.js";
import { lang } from "./i18n.js";
import { loadLocale, lookup } from "./locale.js";

const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "CODE", "OUTPUT", "OPTION_NO"]);
const ATTRS = ["placeholder", "title", "aria-label"];
const orig = new WeakMap(), origAttr = new WeakMap(), pending = new Map();
const outs = new Set();
const tried = new Set();                               // strings already asked for once: never asked again, so the badge cannot flicker
let obs, timer, busy = 0, current = "English", cache = {}, warned = false, onStatus = () => {};

const goodTr = (v) => typeof v === "string" && v.trim() !== "" && !/^(null|none|undefined|nan)$/i.test(v.trim());
const needs = (s) => /[A-Za-z]{2,}/.test(s) && !/^[\d\s.,:%+\-–—°/()×·→]+$/.test(s);
const skipEl = (e) => { for (let n = e; n && n !== document.body; n = n.parentElement) { if (SKIP.has(n.tagName) || n.getAttribute("translate") === "no" || n.classList.contains("leaflet-container")) return true; } return false; };
const key = (l, s) => l + "\u0001" + s;
const loadCache = (l) => { try { const o = JSON.parse(localStorage.getItem("ta-tr-" + l) || "{}"); Object.keys(o).forEach((k) => { if (!goodTr(o[k])) delete o[k]; }); return o; } catch (e) { return {}; } };
const saveCache = (l) => { try { localStorage.setItem("ta-tr-" + l, JSON.stringify(cache)); } catch (e) { /* storage full: still works this session */ } };

function collect(root) {
  const out = [];
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const src = orig.has(n) ? orig.get(n) : n.nodeValue;
    if (!orig.has(n) && !needs(n.nodeValue)) continue;
    if (!n.parentElement || skipEl(n.parentElement)) continue;
    if (!orig.has(n)) orig.set(n, n.nodeValue);
    out.push([n, src.trim()]);
  }
  if (root.querySelectorAll) root.querySelectorAll("[placeholder],[title],[aria-label]").forEach((e) => { if (skipEl(e)) return; ATTRS.forEach((a) => { const v = e.getAttribute(a); if (v == null) return; const o = (origAttr.get(e) || {})[a] ?? v; if (!needs(o)) return; const m = origAttr.get(e) || {}; m[a] = o; origAttr.set(e, m); out.push([{ el: e, attr: a }, o.trim()]); }); });
  return out;
}
function apply(target, src, t) {
  if (target.nodeType === 3) { const o = orig.get(target) || ""; const v = o.replace(src, t); outs.add(v.trim()); target.nodeValue = v; }
  else target.el.setAttribute(target.attr, t);
}
function restore(root) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) if (orig.has(n)) n.nodeValue = orig.get(n);
  root.querySelectorAll("[placeholder],[title],[aria-label]").forEach((e) => { const m = origAttr.get(e); if (m) Object.entries(m).forEach(([a, v]) => e.setAttribute(a, v)); });
}

async function run(items, L) {
  await loadLocale(L);
  const fill = () => { if (L !== current) return; items.forEach(([t, s]) => { if (cache[s] !== undefined) apply(t, s, cache[s]); }); };
  items.forEach(([, s]) => { if (cache[s] === undefined) { const b = lookup(L, s); if (b !== undefined) cache[s] = b; } });
  fill();                                             // built-in translations show at once, even if the AI step below fails
  const need = [...new Set(items.filter(([, s]) => cache[s] === undefined && !tried.has(L + "|" + s)).map(([, s]) => s))];
  for (let i = 0; i < need.length && L === current; i += 40) {
    const chunk = need.slice(i, i + 40); chunk.forEach((s) => tried.add(L + "|" + s)); busy++; onStatus("working");
    try { const r = await api.translate(L, chunk); Object.entries(r.translations || {}).forEach(([k, v]) => { if (goodTr(v)) cache[k] = v; }); saveCache(L); fill(); }
    catch (e) { busy--; onStatus("error", e.message); return; }
    busy--;
  }
  if (L !== current) return;
  fill();
  if (!busy && need.length) onStatus("done");
}
function schedule(items) { items.forEach(([t, s]) => pending.set(t, s)); clearTimeout(timer); timer = setTimeout(() => { const it = [...pending].map(([t, s]) => [t, s]); pending.clear(); run(it, current); }, 250); }

export function setTranslation(language, status) {
  onStatus = status || onStatus; obs && obs.disconnect(); clearTimeout(timer); pending.clear();
  restore(document.body); current = language; warned = false;
  if (language === "English" || language === "Auto") { onStatus("off"); return; }
  cache = loadCache(language);
  loadLocale(language).then(() => { if (current === language) { const it = collect(document.body); it.forEach(([t, s]) => { const b = lookup(language, s); if (b !== undefined) { cache[s] = b; apply(t, s, b); } }); } });
  const first = collect(document.body);
  first.forEach(([t, s]) => { if (cache[s] !== undefined) apply(t, s, cache[s]); });
  schedule(first.filter(([, s]) => cache[s] === undefined));
  obs = new MutationObserver((ms) => {
    const items = [];
    ms.forEach((m) => { m.addedNodes.forEach((n) => { if (n.nodeType === 3) { if (n.parentElement && !skipEl(n.parentElement) && needs(n.nodeValue) && !orig.has(n)) { orig.set(n, n.nodeValue); items.push([n, n.nodeValue.trim()]); } } else if (n.nodeType === 1 && !skipEl(n)) items.push(...collect(n)); });
      if (m.type === "characterData" && m.target.parentElement && !skipEl(m.target.parentElement) && needs(m.target.nodeValue) && orig.get(m.target) !== m.target.nodeValue && !outs.has(m.target.nodeValue.trim())) { orig.set(m.target, m.target.nodeValue); items.push([m.target, m.target.nodeValue.trim()]); } });
    items.forEach(([, s]) => { if (cache[s] === undefined) { const b = lookup(language, s); if (b !== undefined) cache[s] = b; } });
    const cached = items.filter(([, s]) => cache[s] !== undefined); cached.forEach(([t, s]) => apply(t, s, cache[s]));
    const rest = items.filter(([, s]) => cache[s] === undefined); if (rest.length) schedule(rest);
  });
  obs.observe(document.body, { childList: true, subtree: true, characterData: true });
}
