import { svg, css, tip, el, MONTHS, pct } from "./ui.js";

export function climateChart(c, risk) {
  const W = 760, H = 250, m = { l: 44, r: 44, t: 16, b: 58 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
  const s = svg("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Monthly rain and temperature" });
  const rmax = Math.max(...c.monthly_rain_mm, 10) * 1.15, tmin = Math.min(...c.monthly_temp_c) - 3, tmax = Math.max(...c.monthly_temp_c) + 3, bw = iw / 12;
  const mut = css("--muted"), grid = css("--line");
  [0, .5, 1].forEach((f) => {
    const y = m.t + ih * (1 - f);
    s.appendChild(svg("line", { x1: m.l, x2: W - m.r, y1: y, y2: y, stroke: grid }));
    const a = svg("text", { x: m.l - 6, y: y + 4, "text-anchor": "end", fill: mut, "font-size": 11 }); a.textContent = Math.round(rmax * f); s.appendChild(a);
    const b = svg("text", { x: W - m.r + 6, y: y + 4, fill: mut, "font-size": 11 }); b.textContent = Math.round(tmin + (tmax - tmin) * f) + "°"; s.appendChild(b);
  });
  c.monthly_rain_mm.forEach((r, i) => {
    const h = ih * r / rmax, x = m.l + i * bw + bw * .18;
    const bar = svg("rect", { x, y: m.t + ih - h, width: bw * .64, height: Math.max(h, 1), rx: 4, fill: css("--water"), opacity: .85 });
    bar.addEventListener("mousemove", (ev) => tip(ev, `${MONTHS[i]}: ${r.toFixed(0)} mm rain, ${c.monthly_temp_c[i].toFixed(1)} °C` + (risk ? `. Unusually dry in ${pct(risk.dry[i])}% of years, hot in ${pct(risk.hot[i])}%` : "")));
    bar.addEventListener("mouseleave", () => tip());
    s.appendChild(bar);
    const t = svg("text", { x: m.l + i * bw + bw / 2, y: H - 36, "text-anchor": "middle", fill: mut, "font-size": 11 }); t.textContent = MONTHS[i]; s.appendChild(t);
    if (risk) [["dry", css("--sun"), 0], ["hot", css("--crit"), 1]].forEach(([k, col, o]) => {
      const v = risk[k][i]; s.appendChild(svg("rect", { x: m.l + i * bw + bw * .18 + o * bw * .33, y: H - 28, width: bw * .31, height: 4 + 18 * Math.min(v / .5, 1), rx: 2, fill: col, opacity: v < .05 ? .2 : .9 }));
    });
  });
  const pts = c.monthly_temp_c.map((t, i) => [m.l + i * bw + bw / 2, m.t + ih * (1 - (t - tmin) / (tmax - tmin))]);
  s.appendChild(svg("polyline", { points: pts.map((p) => p.join(",")).join(" "), fill: "none", stroke: css("--sun"), "stroke-width": 3, "stroke-linejoin": "round", "stroke-linecap": "round" }));
  pts.forEach((p) => s.appendChild(svg("circle", { cx: p[0], cy: p[1], r: 3.5, fill: css("--surface"), stroke: css("--sun"), "stroke-width": 2 })));
  const w = el("div", { class: "chart" }, [s, el("div", { class: "legend" }, [
    el("span", {}, [el("i", { style: `background:${css("--water")}` }), "Rain (mm per month)"]), el("span", {}, [el("i", { style: `background:${css("--sun")}` }), "Temperature (°C)"]),
    risk ? el("span", {}, [el("i", { style: `background:${css("--crit")}` }), "Under each month: chance of unusually dry (orange) or hot (red)"]) : null])]);
  return w;
}

export function gauge(score, label) {
  const R = 70, C = Math.PI * R, v = Math.max(0, Math.min(100, score)) / 100;
  const col = score < 33 ? css("--good") : score < 66 ? css("--warn") : css("--crit");
  const s = svg("svg", { viewBox: "0 0 180 110", role: "img", "aria-label": `${label} ${Math.round(score)} out of 100`, style: "max-width:240px" });
  s.appendChild(svg("path", { d: "M20 95 A70 70 0 0 1 160 95", fill: "none", stroke: css("--line"), "stroke-width": 14, "stroke-linecap": "round" }));
  s.appendChild(svg("path", { d: "M20 95 A70 70 0 0 1 160 95", fill: "none", stroke: col, "stroke-width": 14, "stroke-linecap": "round", "stroke-dasharray": `${C * v} ${C}` }));
  const t = svg("text", { x: 90, y: 82, "text-anchor": "middle", "font-size": 34, "font-family": "Bahnschrift,DIN Alternate,Segoe UI,Arial,sans-serif", fill: css("--ink") }); t.textContent = Math.round(score); s.appendChild(t);
  const u = svg("text", { x: 90, y: 102, "text-anchor": "middle", "font-size": 11, fill: css("--muted") }); u.textContent = "out of 100"; s.appendChild(u);
  return s;
}

export function ring(s) {
  const cx = 150, cy = 150, R = 130, r = 80, sv = svg("svg", { viewBox: "0 0 300 300", style: "max-width:260px;width:100%", role: "img", "aria-label": `Calendar: ${s.crops[0].name}, ${s.crops[1].name}, bare field` });
  const col = { A: css("--leaf"), B: css("--water"), bare: css("--sun") }, nm = { A: s.crops[0].name, B: s.crops[1].name, bare: "Bare field" };
  s.calendar.forEach((k, i) => {
    const a0 = i / 12 * 2 * Math.PI - Math.PI / 2 + .012, a1 = (i + 1) / 12 * 2 * Math.PI - Math.PI / 2 - .012, p = (rad, a) => `${(cx + rad * Math.cos(a)).toFixed(1)} ${(cy + rad * Math.sin(a)).toFixed(1)}`;
    const path = svg("path", { d: `M${p(R, a0)} A${R} ${R} 0 0 1 ${p(R, a1)} L${p(r, a1)} A${r} ${r} 0 0 0 ${p(r, a0)}Z`, fill: col[k], opacity: k === "bare" ? .45 : .95 });
    path.addEventListener("mousemove", (ev) => tip(ev, `${MONTHS[i]}: ${nm[k]}`)); path.addEventListener("mouseleave", () => tip());
    sv.appendChild(path);
    const am = (a0 + a1) / 2, t = svg("text", { x: cx + (R + 12) * Math.cos(am), y: cy + (R + 12) * Math.sin(am) + 4, "text-anchor": "middle", "font-size": 10, fill: css("--muted") }); t.textContent = MONTHS[i][0]; sv.appendChild(t);
  });
  const a = svg("text", { x: cx, y: cy, "text-anchor": "middle", "font-size": 34, "font-family": "Bahnschrift,DIN Alternate,Segoe UI,Arial,sans-serif", fill: css("--ink") }); a.textContent = pct(s.scores.overall); sv.appendChild(a);
  const b = svg("text", { x: cx, y: cy + 22, "text-anchor": "middle", "font-size": 11, fill: css("--muted") }); b.textContent = "overall score"; sv.appendChild(b);
  return sv;
}

export function radar(items) {   // items: [{name, color, values:[0..1]}], labels shared
  const labels = ["Climate fit", "Water efficiency", "Erosion protection", "Soil organic matter", "Nitrogen", "Market"];
  const keys = ["climate_fit", "water_efficiency", "erosion_protection", "soil_organic_matter", "nitrogen", "market"];
  const cx = 170, cy = 150, R = 105, s = svg("svg", { viewBox: "-40 0 420 310", role: "img", "aria-label": "Radar chart comparing rotation strategies" });
  const pt = (i, v) => { const a = -Math.PI / 2 + i * 2 * Math.PI / 6; return [cx + R * v * Math.cos(a), cy + R * v * Math.sin(a)]; };
  [.25, .5, .75, 1].forEach((f) => s.appendChild(svg("polygon", { points: keys.map((_, i) => pt(i, f).join(",")).join(" "), fill: "none", stroke: css("--line") })));
  keys.forEach((_, i) => { const p = pt(i, 1), q = pt(i, 1.2); s.appendChild(svg("line", { x1: cx, y1: cy, x2: p[0], y2: p[1], stroke: css("--line") }));
    const t = svg("text", { x: q[0], y: q[1] + 4, "text-anchor": q[0] < cx - 5 ? "end" : q[0] > cx + 5 ? "start" : "middle", "font-size": 11, fill: css("--muted") }); t.textContent = labels[i]; s.appendChild(t); });
  items.forEach((it) => {
    const pts = keys.map((k, i) => pt(i, Math.max(0.02, it.s.scores.components[k])).join(",")).join(" ");
    s.appendChild(svg("polygon", { points: pts, fill: it.color, "fill-opacity": .14, stroke: it.color, "stroke-width": 2.2 }));
  });
  return el("div", { class: "chart" }, [s, el("div", { class: "legend" }, items.map((it) => el("span", {}, [el("i", { style: `background:${it.color}` }), it.s.label])))]);
}

export function rangeBars(strats, selected, onPick) {
  const W = 700, rowH = 44, H = strats.length * rowH + 30, m = { l: 190, r: 24 }, iw = W - m.l - m.r;
  const s = svg("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Overall score with uncertainty range per strategy" });
  for (let g = 0; g <= 100; g += 25) { const x = m.l + iw * g / 100; s.appendChild(svg("line", { x1: x, x2: x, y1: 6, y2: H - 22, stroke: css("--line") })); const t = svg("text", { x, y: H - 6, "text-anchor": "middle", "font-size": 11, fill: css("--muted") }); t.textContent = g; s.appendChild(t); }
  strats.forEach((st, i) => {
    const y = 18 + i * rowH, u = st.uncertainty, sc = st.scores.overall;
    const lab = svg("text", { x: m.l - 10, y: y + 5, "text-anchor": "end", "font-size": 12.5, fill: i === selected ? css("--ink") : css("--muted"), "font-weight": i === selected ? 700 : 500 }); lab.textContent = st.label.length > 24 ? st.label.slice(0, 23) + "…" : st.label; s.appendChild(lab);
    s.appendChild(svg("rect", { x: m.l, y: y - 8, width: iw * sc, height: 16, rx: 6, fill: i === selected ? css("--leaf") : css("--forest"), opacity: .9 }));
    const lx = m.l + iw * u.overall_p10, hx = m.l + iw * u.overall_p90;
    s.appendChild(svg("line", { x1: lx, x2: hx, y1: y, y2: y, stroke: css("--ink"), "stroke-width": 2 }));
    [lx, hx].forEach((x) => s.appendChild(svg("line", { x1: x, x2: x, y1: y - 6, y2: y + 6, stroke: css("--ink"), "stroke-width": 2 })));
    const v = svg("text", { x: Math.min(m.l + iw * sc + 8, W - 40), y: y + 4, "font-size": 12, fill: css("--ink") }); v.textContent = pct(sc); s.appendChild(v);
    const hit = svg("rect", { x: 0, y: y - 20, width: W, height: rowH - 6, fill: "transparent", style: "cursor:pointer" });
    hit.addEventListener("click", () => onPick(i));
    hit.addEventListener("mousemove", (ev) => tip(ev, `${st.label}: ${pct(sc)} (range ${pct(u.overall_p10)} to ${pct(u.overall_p90)})`)); hit.addEventListener("mouseleave", () => tip());
    s.appendChild(hit);
  });
  return el("div", { class: "chart" }, [s, el("p", { class: "hint", text: "Bar = score. Line = 10th to 90th percentile across simulated past years and judgement noise. Click a row to select." })]);
}

export function riskHeat(risk) {
  const rows = [["dry", "Dry", css("--sun")], ["hot", "Hot", css("--crit")], ["wet", "Wet", css("--water")], ["cold", "Cold", "#a9b8f0"]];
  const g = el("div", { class: "heat", role: "table", "aria-label": "Share of past years each month was unusual" }, [el("span"), ...MONTHS.map((m) => el("span", { class: "m", text: m[0] }))]);
  rows.forEach(([k, l, c]) => {
    g.appendChild(el("span", { class: "l", text: l }));
    risk[k].forEach((v, i) => { const cell = el("div", { class: "c", style: `background:${c};opacity:${Math.max(0.1, Math.min(1, v * 2.4)).toFixed(2)}` });
      cell.addEventListener("mousemove", (ev) => tip(ev, `${l} in ${MONTHS[i]}: ${pct(v)}% of years`)); cell.addEventListener("mouseleave", () => tip()); g.appendChild(cell); });
  });
  return g;
}

export function ndviBars(sat) {
  const W = 700, H = 170, m = { l: 36, b: 26, t: 10 }, iw = W - m.l - 8, ih = H - m.b - m.t, vals = sat.median_ndvi.map((v) => v ?? 0), mx = Math.max(...vals, .3), bw = iw / 12;
  const s = svg("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Median satellite greenness by month" });
  vals.forEach((v, i) => {
    const h = ih * v / mx, r = svg("rect", { x: m.l + i * bw + 4, y: m.t + ih - h, width: bw - 8, height: Math.max(h, 1), rx: 4, fill: sat.green_months[i] ? css("--leaf") : css("--bare-col", "#8a6a31") || css("--sun"), opacity: sat.green_months[i] ? .95 : .55 });
    r.addEventListener("mousemove", (ev) => tip(ev, `${MONTHS[i]}: greenness ${v.toFixed(2)} (${sat.green_months[i] ? "green" : "low or bare"})`)); r.addEventListener("mouseleave", () => tip()); s.appendChild(r);
    const t = svg("text", { x: m.l + i * bw + bw / 2, y: H - 8, "text-anchor": "middle", "font-size": 11, fill: css("--muted") }); t.textContent = MONTHS[i]; s.appendChild(t);
  });
  s.appendChild(svg("line", { x1: m.l, x2: W - 8, y1: m.t + ih * (1 - sat.threshold / mx), y2: m.t + ih * (1 - sat.threshold / mx), stroke: css("--ink"), "stroke-dasharray": "4 4", opacity: .5 }));
  return el("div", { class: "chart" }, [s, el("p", { class: "hint", text: `Dashed line: threshold for "green". ${sat.method}` })]);
}

export function mlChart(m) {
  const W = 760, H = 200, mg = { l: 40, r: 12, t: 12, b: 28 }, iw = W - mg.l - mg.r, ih = H - mg.t - mg.b, r = m.recent, n = r.length;
  const vals = r.map((x) => x.observed).concat(r.map((x) => x.expected)), lo = Math.min(...vals) - .03, hi = Math.max(...vals) + .03, mut = css("--muted");
  const X = (i) => mg.l + iw * i / (n - 1), Y = (v) => mg.t + ih * (1 - (v - lo) / (hi - lo));
  const s = svg("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Observed and expected satellite greenness, last 36 months" });
  [0, .5, 1].forEach((f) => { const y = mg.t + ih * (1 - f); s.appendChild(svg("line", { x1: mg.l, x2: W - mg.r, y1: y, y2: y, stroke: css("--line") })); const t = svg("text", { x: mg.l - 6, y: y + 4, "text-anchor": "end", fill: mut, "font-size": 11 }); t.textContent = (lo + (hi - lo) * f).toFixed(2); s.appendChild(t); });
  const line = (key, col, dash) => s.appendChild(svg("polyline", { points: r.map((x, i) => `${X(i).toFixed(1)},${Y(x[key]).toFixed(1)}`).join(" "), fill: "none", stroke: col, "stroke-width": 2.5, "stroke-linecap": "round", "stroke-linejoin": "round", "stroke-dasharray": dash || "" }));
  line("expected", css("--water"), "6 5"); line("observed", css("--leaf"));
  r.forEach((x, i) => {
    if (x.observed < x.expected - .08) { const c = svg("circle", { cx: X(i), cy: Y(x.observed), r: 5, fill: css("--crit") }); c.addEventListener("mousemove", (ev) => tip(ev, `${x.month} ${x.year}: greenness ${x.observed}, expected ${x.expected}`)); c.addEventListener("mouseleave", () => tip()); s.appendChild(c); }
    if (i % 6 === 0) { const l = svg("text", { x: X(i), y: H - 8, "text-anchor": "middle", fill: mut, "font-size": 11 }); l.textContent = `${x.month} ${String(x.year).slice(2)}`; s.appendChild(l); }
  });
  return el("div", { class: "chart" }, [s, el("div", { class: "legend" }, [
    el("span", {}, [el("i", { style: `background:${css("--leaf")}` }), "Observed by satellite"]), el("span", {}, [el("i", { style: `background:${css("--water")}` }), "Expected from weather"]), el("span", {}, [el("i", { style: `background:${css("--crit")}` }), "Well below expected"])])]);
}

export function polygonSketch(boundary, size = 220) {
  const ring = boundary && boundary.coordinates && boundary.coordinates[0]; if (!ring) return null;
  const xs = ring.map((p) => p[0]), ys = ring.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const k = (size - 30) / Math.max(x1 - x0, y1 - y0, 1e-9);
  const pts = ring.map((p) => `${(15 + (p[0] - x0) * k).toFixed(1)},${(size - 15 - (p[1] - y0) * k).toFixed(1)}`).join(" ");
  return svg("svg", { viewBox: `0 0 ${size} ${size}`, style: `max-width:${size}px;width:100%`, role: "img", "aria-label": "Field boundary" }, [
    svg("polygon", { points: pts, fill: css("--forest"), "fill-opacity": .5, stroke: css("--leaf"), "stroke-width": 2.5, "stroke-linejoin": "round" })]);
}


export function forecastChart(days, st) {
  const W = 780, H = 280, m = { l: 42, r: 42, t: 16, b: 48 }, iw = W - m.l - m.r, ih = H - m.t - m.b, n = days.length, bw = iw / n;
  const s = svg("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "16-day forecast: daily rain and temperature" });
  const rmax = Math.max(10, ...days.map((d) => Math.max(d.rain_mm || 0, d.normal_rain_mm || 0))) * 1.2;
  const ts = days.flatMap((d) => [d.tmax, d.tmin, d.normal_tmax]).filter((v) => v != null), tmin = Math.min(...ts) - 2, tmax = Math.max(...ts, st.heat_limit_c || 0) + 2;
  const X = (i) => m.l + i * bw + bw / 2, YT = (t) => m.t + ih * (1 - (t - tmin) / (tmax - tmin)), YR = (r) => m.t + ih * (1 - r / rmax), mut = css("--muted");
  [0, .5, 1].forEach((f) => {
    const y = m.t + ih * (1 - f); s.appendChild(svg("line", { x1: m.l, x2: W - m.r, y1: y, y2: y, stroke: css("--line") }));
    const a = svg("text", { x: m.l - 6, y: y + 4, "text-anchor": "end", "font-size": 11, fill: mut }); a.textContent = Math.round(rmax * f); s.appendChild(a);
    const b = svg("text", { x: W - m.r + 6, y: y + 4, "font-size": 11, fill: mut }); b.textContent = Math.round(tmin + (tmax - tmin) * f) + "°"; s.appendChild(b);
  });
  if (st.heat_limit_c != null) { const y = YT(st.heat_limit_c); s.appendChild(svg("line", { x1: m.l, x2: W - m.r, y1: y, y2: y, stroke: css("--crit"), "stroke-dasharray": "5 4", opacity: .7 })); const t = svg("text", { x: m.l + 4, y: y - 4, "font-size": 10.5, fill: css("--crit") }); t.textContent = `heat limit ${Math.round(st.heat_limit_c)}°`; s.appendChild(t); }
  days.forEach((d, i) => {
    const op = d.lead_confidence === "high" ? 1 : d.lead_confidence === "medium" ? .8 : .55;
    if (d.normal_rain_mm != null) s.appendChild(svg("rect", { x: m.l + i * bw + 2, y: YR(d.normal_rain_mm), width: bw - 4, height: 2, fill: css("--ink"), opacity: .35 }));
    const h = ih * (d.rain_mm || 0) / rmax, bar = svg("rect", { x: m.l + i * bw + bw * .2, y: m.t + ih - h, width: bw * .6, height: Math.max(h, 0.5), rx: 3, fill: css("--water"), opacity: op });
    bar.addEventListener("mousemove", (ev) => tip(ev, `${d.date}: rain ${(d.rain_mm ?? 0).toFixed(1)} mm (normal ${d.normal_rain_mm != null ? d.normal_rain_mm.toFixed(1) : "n/a"}), ${d.tmin?.toFixed(0)} to ${d.tmax?.toFixed(0)} °C. Confidence ${d.lead_confidence}`)); bar.addEventListener("mouseleave", () => tip());
    s.appendChild(bar);
    const lab = svg("text", { x: X(i), y: H - 28, "text-anchor": "middle", "font-size": 10.5, fill: mut }); lab.textContent = d.date.slice(8); s.appendChild(lab);
    const mo = svg("text", { x: X(i), y: H - 14, "text-anchor": "middle", "font-size": 9.5, fill: mut, opacity: .7 }); mo.textContent = (i === 0 || d.date.slice(8) === "01") ? MONTHS[+d.date.slice(5, 7) - 1] : ""; s.appendChild(mo);
    s.appendChild(svg("rect", { x: m.l + i * bw + 3, y: H - 8, width: bw - 6, height: 3, rx: 1.5, fill: css("--accent"), opacity: op * .8 }));
  });
  const line = (key, col, dash) => s.appendChild(svg("polyline", { points: days.map((d, i) => d[key] == null ? "" : `${X(i)},${YT(d[key])}`).filter(Boolean).join(" "), fill: "none", stroke: col, "stroke-width": 2.6, "stroke-linejoin": "round", "stroke-linecap": "round", "stroke-dasharray": dash || "" }));
  line("normal_tmax", css("--faint"), "4 5"); line("tmax", css("--copper")); line("tmin", css("--forest"));
  return el("div", { class: "chart" }, [s, el("div", { class: "legend" }, [
    el("span", {}, [el("i", { style: `background:${css("--water")}` }), "Rain (mm per day)"]), el("span", {}, [el("i", { style: `background:${css("--ink")};opacity:.4` }), "Normal rain for the date"]),
    el("span", {}, [el("i", { style: `background:${css("--copper")}` }), "Daily high"]), el("span", {}, [el("i", { style: `background:${css("--forest")}` }), "Daily low"]), el("span", {}, [el("i", { style: `background:${css("--accent")}` }), "Bar under the date: forecast confidence (fades with lead time)"])])]);
}
