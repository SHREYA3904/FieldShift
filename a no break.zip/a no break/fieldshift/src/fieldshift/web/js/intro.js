// Cinematic opening: two black panels meet on the diagonal, TERRAADAPT pops in with a purple and white splash, then the panels slide apart.
export function intro(force = false) {
  let calm = false;                                         // plays on every launch; with "reduce motion" on it stays up a short moment instead of being skipped
  try { if (!force && sessionStorage.getItem("ta-skip")) return; calm = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) { /* private mode: just play it */ }
  const root = document.createElement("div"); root.id = "intro"; root.setAttribute("role", "presentation");
  const letters = "TERRAADAPT".split("").map((c, i) => `<span style="--i:${i}">${c}</span>`).join("");
  root.innerHTML = `<div class="ip a"></div><div class="ip b"></div><div class="iseam"></div><canvas class="ifx"></canvas><div class="iring r1"></div><div class="iring r2"></div><div class="iring r3"></div>
    <div class="iword" aria-hidden="true"><h1>${letters}</h1><p>discover your field in your own language</p></div><button class="iskip" type="button">Skip</button>`;
  document.body.appendChild(root); document.body.classList.add("intro-on");
  const setAng = () => root.style.setProperty("--ang", -Math.atan(innerHeight / innerWidth) * 180 / Math.PI + "deg"); setAng(); addEventListener("resize", setAng);
  const cv = root.querySelector("canvas"), ctx = cv.getContext("2d"), dpr = Math.min(3, devicePixelRatio || 1);
  const fit = () => { cv.width = innerWidth * dpr; cv.height = innerHeight * dpr; }; fit();
  const P = []; let burst = 0, raf = 0, done = false;
  const spawn = () => { const cx = innerWidth / 2, cy = innerHeight / 2; for (let i = 0; i < 150; i++) { const a = Math.random() * 6.283, v = 2 + Math.random() * 9; P.push({ x: cx, y: cy, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.8, r: 1.5 + Math.random() * 5, life: 1, c: Math.random() < 0.45 ? "255,255,255" : Math.random() < 0.5 ? "167,119,255" : "124,58,237" }); } };
  const t0 = performance.now();
  const loop = (t) => {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, innerWidth, innerHeight);
    if (!burst && t - t0 > 900) { burst = 1; spawn(); }
    for (const p of P) { p.x += p.vx; p.y += p.vy; p.vx *= 0.955; p.vy = p.vy * 0.955 + 0.08; p.life -= 0.011; if (p.life <= 0) continue; ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = `rgb(${p.c})`; ctx.shadowColor = "rgba(150,90,255,.9)"; ctx.shadowBlur = 12; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * p.life + 0.5, 0, 6.283); ctx.fill(); }
    ctx.globalAlpha = 1; if (!done) raf = requestAnimationFrame(loop);
  };
  raf = requestAnimationFrame(loop);
  const end = () => { if (done) return; done = true; cancelAnimationFrame(raf); root.classList.add("open"); setTimeout(() => { root.remove(); document.body.classList.remove("intro-on"); }, 1300); };
  root.querySelector(".iskip").onclick = end; addEventListener("keydown", function k(e) { if (["Escape", " ", "Enter"].includes(e.key)) { end(); removeEventListener("keydown", k); } });
  setTimeout(() => root.classList.add("go"), 150); setTimeout(end, calm ? 1800 : 3500);
}
