export const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
export const $ = (id) => document.getElementById(id);
export const pct = (x) => Math.round(x * 100);
export const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

// DOM append helpers turn null/undefined/false into the text "null"/"false": drop them instead, everywhere in the app.
for (const m of ["replaceChildren", "append", "prepend", "before", "after"]) {
  for (const P of [Element.prototype, DocumentFragment.prototype]) {
    const orig = P[m]; if (!orig || orig.__clean) continue;
    const fn = function (...a) { return orig.apply(this, a.flat(Infinity).filter((x) => x !== null && x !== undefined && x !== false)); };
    fn.__clean = true; P[m] = fn;
  }
}
export function el(tag, attrs, kids) {
  const e = document.createElement(tag);
  for (const k in (attrs || {})) {
    const v = attrs[k];
    if (v === undefined || v === null || v === false) continue;
    if (k === "text") e.textContent = v; else if (k === "class") e.className = v; else if (k === "html") e.innerHTML = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? "" : v);
  }
  [].concat(kids || []).forEach((c) => { if (c !== null && c !== undefined && c !== false) e.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c); });
  return e;
}
export function svg(tag, attrs, kids) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const k in (attrs || {})) e.setAttribute(k, attrs[k]);
  [].concat(kids || []).forEach((c) => c && e.appendChild(c));
  return e;
}
export function tip(ev, text) {
  const t = $("tip");
  if (!text) { t.hidden = true; return; }
  t.textContent = text; t.hidden = false;
  t.style.left = Math.min(ev.clientX + 12, innerWidth - 270) + "px"; t.style.top = (ev.clientY + 14) + "px";
}
export function toast(msg) {
  const t = el("div", { class: "toast", text: msg, role: "status" }); document.body.appendChild(t); setTimeout(() => t.remove(), 3200);
}
export const skeleton = (h = 160) => el("div", { class: "skeleton", style: `height:${h}px` });
export function loading(msg) { return el("div", { class: "card" }, [el("p", { class: "hint", text: msg || "Loading…" }), skeleton(180)]); }
export function errorBox(msg, retry) {
  return el("div", { class: "callout crit" }, [el("b", { text: "Something went wrong. " }), msg || "", retry ? el("div", { style: "margin-top:8px" }, [el("button", { class: "btn", text: "Try again", onclick: retry })]) : null]);
}
export function badge(text, kind) { return el("span", { class: "badge " + (kind || ""), text }); }
export const catKind = (c) => (c === "high" ? "crit" : c === "moderate" ? "warn" : "good");
export function count(node, to, dec = 0, ms = 900) {
  if (matchMedia("(prefers-reduced-motion:reduce)").matches || !isFinite(to)) { node.textContent = to.toFixed(dec); return; }
  const t0 = performance.now();
  (function f(t) { const k = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - k, 3); node.textContent = (to * e).toFixed(dec); if (k < 1) requestAnimationFrame(f); })(t0);
}
export function reveal(root) {
  if (matchMedia("(prefers-reduced-motion:reduce)").matches) return;
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 });
  root.querySelectorAll(".reveal").forEach((n) => io.observe(n));
}
export const ICONS = {
  overview: "M3 12 12 3l9 9M5 10v10h14V10", fields: "M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10",
  earth: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18",
  risks: "M12 3 2 20h20L12 3zM12 10v5M12 18h.01", lab: "M9 3h6M10 3v6L4 19a2 2 0 0 0 2 3h12a2 2 0 0 0 2-3l-6-10V3",
  planner: "M5 4h14v16H5zM5 9h14M9 2v4M15 2v4", simulator: "M4 20V10M10 20V4M16 20v-8M22 20H2", assistant: "M21 12a8 8 0 0 1-11.5 7.2L3 21l1.8-5.5A8 8 0 1 1 21 12z",
};
export function icon(name) {
  return svg("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" }, [svg("path", { d: ICONS[name] })]);
}
