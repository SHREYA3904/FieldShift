import * as THREE from "./vendor/three.module.min.js";

const host = document.getElementById("globe");
const R = 1.6;
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
} catch (e) { renderer = null; }
if (!renderer || !host) { document.dispatchEvent(new CustomEvent("fs:noglobe")); }
else boot();

function ll(lat, lon, r = 1) {
  const la = lat * Math.PI / 180, lo = lon * Math.PI / 180;
  return new THREE.Vector3(r * Math.cos(la) * Math.sin(lo), r * Math.sin(la), r * Math.cos(la) * Math.cos(lo));
}

function boot() {
  const reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
  const dpr = Math.min(devicePixelRatio || 1, 2);
  renderer.setPixelRatio(dpr);
  host.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 50);
  camera.position.z = 7.2;
  const root = new THREE.Group(); scene.add(root);
  const uni = { uTime: { value: 0 }, uPin: { value: new THREE.Vector3(0, 0, 0) }, uPinOn: { value: 0 }, uHot: { value: 0 }, uWet: { value: 0 }, uDpr: { value: dpr }, uPulse: { value: -1 } };

  // Real Earth imagery (NASA Blue Marble based textures from the three.js examples): day map, ocean glint, city lights, drifting clouds.
  const loader = new THREE.TextureLoader();
  const tex = (f) => { const t = loader.load("vendor/tex/" + f); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; };
  uni.uSun = { value: new THREE.Vector3(-0.55, 0.32, 0.85).normalize() };
  const vtx = "varying vec2 vUv;varying vec3 vN;varying vec3 vW;void main(){vUv=uv;vN=normalize(mat3(modelMatrix)*normal);vec4 w=modelMatrix*vec4(position,1.);vW=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}";
  const earth = new THREE.Mesh(new THREE.SphereGeometry(R, 96, 72), new THREE.ShaderMaterial({
    uniforms: { ...uni, dayMap: { value: tex("earth_atmos_2048.jpg") }, nightMap: { value: tex("earth_lights_2048.png") }, specMap: { value: tex("earth_specular_2048.jpg") } },
    vertexShader: vtx,
    fragmentShader: "uniform sampler2D dayMap;uniform sampler2D nightMap;uniform sampler2D specMap;uniform vec3 uSun;uniform float uHot;uniform float uWet;varying vec2 vUv;varying vec3 vN;varying vec3 vW;"
      + "void main(){vec3 N=normalize(vN);vec3 V=normalize(cameraPosition-vW);float ndl=dot(N,uSun);float day=smoothstep(-.12,.26,ndl);"
      + "vec3 d=pow(texture2D(dayMap,vUv).rgb,vec3(1.1))*vec3(1.02,1.0,.95);vec3 lit=d*(.05+1.08*max(ndl,0.));"
      + "vec3 city=pow(texture2D(nightMap,vUv).rgb,vec3(1.15))*vec3(1.7,1.08,.5);vec3 dark=d*vec3(.045,.05,.11)+city*1.15;"
      + "vec3 col=mix(dark,lit,day);"
      + "float sp=texture2D(specMap,vUv).r;vec3 H=normalize(uSun+V);col+=pow(max(dot(N,H),0.),60.)*sp*vec3(1.,.8,.6)*.9*day;"
      + "float tb=smoothstep(0.,.16,ndl)*(1.-smoothstep(.16,.4,ndl));col+=tb*vec3(.6,.22,.08)*.28;"
      + "float fr=pow(1.-max(dot(N,V),0.),3.);col+=fr*mix(vec3(.4,.32,.95),vec3(.95,.55,.4),smoothstep(-.3,.8,ndl))*.38;"
      + "col=mix(col,col*vec3(1.1,.9,.8),uHot*.35);col=mix(col,col*vec3(.8,.95,1.15),uWet*.35);"
      + "gl_FragColor=vec4(col,1.);gl_FragColor=linearToOutputTexel(gl_FragColor);}"
  }));
  earth.rotation.y = -Math.PI / 2; root.add(earth);
  const clouds = new THREE.Mesh(new THREE.SphereGeometry(R * 1.013, 72, 56), new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, uniforms: { ...uni, cloudMap: { value: tex("earth_clouds_1024.png") } }, vertexShader: vtx,
    fragmentShader: "uniform sampler2D cloudMap;uniform vec3 uSun;varying vec2 vUv;varying vec3 vN;varying vec3 vW;"
      + "void main(){float a=texture2D(cloudMap,vUv).a;float ndl=dot(normalize(vN),uSun);float l=.05+max(ndl,0.)*1.0;vec3 c=vec3(1.,.95,.92)*l+vec3(.4,.2,.1)*smoothstep(-.1,.2,ndl)*(1.-smoothstep(.2,.4,ndl))*.5;"
      + "gl_FragColor=vec4(c,a*.78);gl_FragColor=linearToOutputTexel(gl_FragColor);}"
  }));
  clouds.rotation.y = -Math.PI / 2; root.add(clouds);
  const atm = new THREE.Mesh(new THREE.SphereGeometry(R * 1.1, 64, 48), new THREE.ShaderMaterial({
    transparent: true, side: THREE.BackSide, blending: THREE.AdditiveBlending, depthWrite: false, uniforms: uni,
    vertexShader: "varying vec3 vN;void main(){vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
    fragmentShader: "varying vec3 vN;uniform float uHot;uniform float uWet;void main(){float f=pow(max(0.,0.64-dot(vN,vec3(0.,0.,1.))),3.);vec3 c=mix(vec3(.42,.45,1.),vec3(.98,.52,.38),.18+uHot*.55);c=mix(c,vec3(.35,.7,1.),uWet*.6);gl_FragColor=vec4(c,1.)*f*1.0;}"
  }));
  scene.add(atm);
  // star field, cream / lilac / amber, twinkling
  const NS = 2200, sp = new Float32Array(NS * 3), sc = new Float32Array(NS * 3), ss = new Float32Array(NS), sph = new Float32Array(NS);
  const pal = [[1, .95, .88], [.8, .78, 1], [1, .78, .55], [.75, .85, 1]];
  for (let i = 0; i < NS; i++) { const v = new THREE.Vector3().randomDirection().multiplyScalar(22 + Math.random() * 14); sp.set([v.x, v.y, v.z], i * 3); sc.set(pal[(Math.random() * 4) | 0], i * 3); ss[i] = Math.random() < .06 ? 2.4 : .7 + Math.random() * 1.1; sph[i] = Math.random() * 6.28; }
  const sg = new THREE.BufferGeometry(); sg.setAttribute("position", new THREE.BufferAttribute(sp, 3)); sg.setAttribute("col", new THREE.BufferAttribute(sc, 3)); sg.setAttribute("sz", new THREE.BufferAttribute(ss, 1)); sg.setAttribute("ph", new THREE.BufferAttribute(sph, 1));
  const stars = new THREE.Points(sg, new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: uni,
    vertexShader: "attribute vec3 col;attribute float sz;attribute float ph;uniform float uTime;uniform float uDpr;varying vec3 vC;varying float vT;void main(){vC=col;vT=.55+.45*sin(uTime*(.6+ph*.15)+ph*7.);vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=sz*uDpr*1.5;gl_Position=projectionMatrix*mv;}",
    fragmentShader: "varying vec3 vC;varying float vT;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(vC,(.5-d)*2.*vT);}"
  })); scene.add(stars);

  const pinG = new THREE.Group(); root.add(pinG);
  const ringMat = () => new THREE.MeshBasicMaterial({ color: 0xffd36b, transparent: true, side: THREE.DoubleSide, depthWrite: false });
  const rings = [0, 1].map(() => { const m = new THREE.Mesh(new THREE.RingGeometry(0.9, 1, 48), ringMat()); pinG.add(m); return m; });
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.03, 16, 12), new THREE.MeshBasicMaterial({ color: 0xffd36b })); pinG.add(dot);
  const spike = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.22, 6), new THREE.MeshBasicMaterial({ color: 0xffd36b })); pinG.add(spike);
  pinG.visible = false;

  // ambient particles
  const N = 500, pp = new Float32Array(N * 3), ph = new Float32Array(N);
  for (let i = 0; i < N; i++) { const v = new THREE.Vector3().randomDirection().multiplyScalar(2.3 + Math.random() * 1.6); pp.set([v.x, v.y, v.z], i * 3); ph[i] = Math.random() * 6.28; }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pp, 3)); pg.setAttribute("ph", new THREE.BufferAttribute(ph, 1));
  const parts = new THREE.Points(pg, new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: uni,
    vertexShader: "attribute float ph;uniform float uTime;uniform float uDpr;void main(){vec3 p=position;p.y+=sin(uTime*.3+ph)*.05;vec4 mv=modelViewMatrix*vec4(p,1.);gl_PointSize=(1.4+sin(uTime+ph))*uDpr*(5./-mv.z);gl_Position=projectionMatrix*mv;}",
    fragmentShader: "uniform float uWet;uniform float uHot;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;vec3 c=mix(vec3(1.,.8,.55),vec3(.7,.6,1.),.4);c=mix(c,vec3(.35,.7,1.),uWet);c=mix(c,vec3(1.,.55,.3),uHot);gl_FragColor=vec4(c,(.5-d)*1.1);}"
  })); scene.add(parts);

  const state = { rotX: 0.35, rotY: -1.2, vx: 0, vy: 0, drag: false, moved: 0, last: 0, tx: null, ty: null, mx: 0, my: 0, visible: true };
  root.rotation.set(state.rotX, state.rotY, 0);

  const stage = { x: 0.24, y: 0, s: 0.94, cx: 0.24, cy: 0, cs: 0.94 };
  function applyView() {
    const w = host.clientWidth || 1, h = host.clientHeight || 1, wide = w / h > 1.15;
    camera.setViewOffset(w, h, wide ? -w * stage.cx : 0, wide ? -h * stage.cy : h * (0.18 - stage.cy), w, h);
    camera.updateProjectionMatrix();
  }
  function size() {
    const w = host.clientWidth, h = host.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false); camera.aspect = w / h; applyView();
  }
  new ResizeObserver(size).observe(host); size();

  const el = renderer.domElement;
  el.addEventListener("pointerdown", e => { state.drag = true; state.moved = 0; state.last = performance.now(); state.lx = e.clientX; state.ly = e.clientY; state.vx = state.vy = 0; el.setPointerCapture(e.pointerId); state.tx = null; });
  el.addEventListener("pointermove", e => {
    const r = el.getBoundingClientRect(); state.mx = ((e.clientX - r.left) / r.width - 0.5); state.my = ((e.clientY - r.top) / r.height - 0.5);
    if (!state.drag) return;
    const dx = e.clientX - state.lx, dy = e.clientY - state.ly; state.lx = e.clientX; state.ly = e.clientY; state.moved += Math.abs(dx) + Math.abs(dy);
    state.rotY += dx * 0.005; state.rotX = Math.max(-1.2, Math.min(1.2, state.rotX + dy * 0.005)); state.vy = dx * 0.005; state.vx = dy * 0.005; state.last = performance.now();
  });
  el.addEventListener("pointerup", e => {
    state.drag = false;
    if (state.moved < 6) pick(e);
  });
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pick(e) {
    const r = el.getBoundingClientRect();
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const o = ray.ray.origin, d = ray.ray.direction, b = o.dot(d), c = o.dot(o) - R * R, disc = b * b - c;
    if (disc < 0) return;
    const hit = o.clone().addScaledVector(d, -b - Math.sqrt(disc));
    const local = root.worldToLocal(hit).normalize();
    const lat = Math.asin(local.y) * 180 / Math.PI, lon = Math.atan2(local.x, local.z) * 180 / Math.PI;
    setPin(lat, lon, true);
    document.dispatchEvent(new CustomEvent("fs:pick", { detail: { lat, lon } }));
  }

  function setPin(lat, lon, fly) {
    const n = ll(lat, lon, 1);
    uni.uPin.value.copy(n); uni.uPinOn.value = 1; uni.uPulse.value = 0;
    pinG.visible = true;
    const p = n.clone().multiplyScalar(R * 1.004);
    pinG.position.copy(p); pinG.lookAt(p.clone().multiplyScalar(2));
    spike.position.set(0, 0, 0.11); spike.rotation.x = Math.PI / 2; dot.position.set(0, 0, 0.004);
    if (fly) { state.tx = lat * Math.PI / 180; state.ty = -lon * Math.PI / 180; }
    state.idle = performance.now();
  }
  function setClimate(o) { uni.uHot.value = Math.max(0, Math.min(1, (o.temp || 0) / 4)); uni.uWet.value = Math.max(0, Math.min(1, (o.rain || 0) / 40)); }
  function setStage(o) { Object.assign(stage, o); state.idle = performance.now(); }
  window.FSGlobe = { setPin, setClimate, setStage };

  new IntersectionObserver(es => { state.visible = es[0].isIntersecting; }).observe(host);
  let t0 = performance.now(), frames = 0, tcheck = t0, reduced = false;
  function tick(now) {
    requestAnimationFrame(tick);
    if (!state.visible) return;
    const dt = Math.min(0.05, (now - t0) / 1000); t0 = now;
    uni.uTime.value += dt;
    if (uni.uPulse.value >= 0 && uni.uPulse.value < 1.4) uni.uPulse.value += dt * 0.55; else if (uni.uPulse.value >= 1.4 && uni.uPinOn.value) uni.uPulse.value = 0;
    if (state.tx !== null && !state.drag) {
      state.rotX += (Math.max(-1.1, Math.min(1.1, state.tx)) - state.rotX) * 0.06;
      let dy = state.ty - state.rotY; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); state.rotY += dy * 0.06;
      if (Math.abs(dy) < 0.004) state.tx = null;
    } else if (!state.drag) {
      state.rotY += state.vy; state.rotX = Math.max(-1.2, Math.min(1.2, state.rotX + state.vx)); state.vy *= 0.95; state.vx *= 0.95;
      if (!reduce && performance.now() - state.last > 2500 && state.tx === null && Math.abs(state.vy) < 0.0005) state.rotY += dt * 0.12;
    }
    stage.cx += (stage.x - stage.cx) * 0.045; stage.cy += (stage.y - stage.cy) * 0.045; stage.cs += (stage.s - stage.cs) * 0.045; root.scale.setScalar(stage.cs); applyView();
    root.rotation.set(state.rotX, state.rotY, 0);
    camera.position.x += (state.mx * 0.5 - camera.position.x) * 0.05; camera.position.y += (-state.my * 0.35 - camera.position.y) * 0.05; camera.lookAt(0, 0, 0);
    const k = uni.uTime.value;
    rings.forEach((m, i) => { const s = ((k * 0.5 + i * 0.5) % 1); m.scale.setScalar(0.03 + s * 0.16); m.material.opacity = (1 - s) * 0.8; });
    clouds.rotation.y += dt * 0.006; stars.rotation.y += dt * 0.004; stars.rotation.x = state.rotX * 0.05;
    parts.rotation.y += dt * 0.02; parts.position.x += (state.mx * 0.6 - parts.position.x) * 0.04; parts.position.y += (-state.my * 0.4 - parts.position.y) * 0.04;
    renderer.render(scene, camera);
    frames++;
    if (now - tcheck > 2000) {                              // adaptive quality
      const fps = frames / ((now - tcheck) / 1000); frames = 0; tcheck = now;
      if (fps < 28 && !reduced) { reduced = true; renderer.setPixelRatio(1); uni.uDpr.value = 1; parts.visible = false; size(); }
    }
  }
  requestAnimationFrame(tick);
}
