"""The v2 analysis pipeline: real daily data -> detect -> simulate -> optimise -> explain.

Nothing here is specific to a place. Every number comes from the daily weather arrays (NASA POWER), soil
(SoilGrids, or a labelled assumption), and the crop table (crop_params.json, tagged estimate/sourced).
Sources are injected so the same code runs against live services or test data.
"""
from __future__ import annotations

import os
import time
import numpy as np

from . import datapack
from . import detect as D
from . import ecocrop
from . import ingest
from . import ml_detect
from . import forecast as F
from . import simulate as S
from . import vulnerability as V
from .climate import Climate
from .ml import analyse as anomalies

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
MDAYS = np.array([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
MSTART = np.r_[0, np.cumsum(MDAYS)][:12]            # day-of-year (0-based) of each month start
TEXTURE = {"loam": (40.0, 20.0), "clay": (20.0, 45.0), "sandy": (80.0, 8.0)}
DEFAULT_PRI = {"water": 4, "nfix": 4, "erosion": 3, "om": 3, "forage": 3, "market": 3, "stability": 0}
SOW_DAY = 15
GAP = 7                                              # days between harvest and next sowing


class Sources:
    """Live data sources. Each call returns the typed result from ingest.result()."""

    def power(self, lat, lon):
        wait_s = float(os.environ.get("FIELDSHIFT_POWER_WAIT", "12"))
        key = ("power", ingest.snap(lat), ingest.snap(lon))
        fut = ingest.background(key, lambda: ingest.result("NASA POWER daily", lambda: ingest.power_daily(lat, lon)))
        inreg = datapack.region(lat, lon)["in_region"]
        if inreg and not ingest.power_is_cached(lat, lon):          # the supplied NASA POWER file answers at once; the live download fills the disk cache for next time
            return {"source": "NASA POWER daily (supplied file)", "ok": True, "error": None, "fetched_at": None, "data": datapack.power_daily(), "bundled": True, "live_error": "live download started in the background"}
        r = ingest.wait(fut, wait_s, "NASA POWER daily")             # cached: instant. Otherwise at most a few seconds, never minutes
        if r["ok"]:
            return r
        okey = ("om", round(lat, 2), round(lon, 2))
        om = ingest.wait(ingest.background(okey, lambda: ingest.result("Open-Meteo archive (ERA5 reanalysis, backup for NASA POWER)", lambda: ingest.openmeteo_daily(lat, lon))), 20, "Open-Meteo archive")
        if om["ok"]:                                                 # real weather now; NASA POWER keeps downloading and is used on the next load
            return {**om, "backup": True, "live_error": r["error"]}
        return r

    def soil(self, lat, lon):
        return ingest.result("SoilGrids", lambda: ingest.soilgrids(lat, lon))

    def elevation(self, lat, lon):
        return ingest.result("Open-Meteo elevation", lambda: ingest.elevation(lat, lon))

    def ndvi(self, lat, lon):
        return ingest.result("MODIS NDVI", lambda: ingest.modis_ndvi(lat, lon))


# ---------------------------------------------------------------- harmonise
def _harmonise(raw: dict):
    dates = raw["dates"]
    out, filled = {}, 0
    doy = (dates - dates.astype("datetime64[Y]")).astype(int)
    for k in ("T2M_MAX", "T2M_MIN", "PRECTOTCORR"):
        a, n = ingest.fill_gaps(raw[k], 5)
        filled += n
        bad = np.isnan(a)
        if bad.any():                                  # remaining gaps: day-of-year climatology, counted
            clim = np.array([np.nanmean(a[doy == d]) if (doy == d).any() else np.nan for d in range(366)])
            a[bad] = clim[doy[bad]]
            filled += int(bad.sum())
        out[k] = a
    total = 3 * len(dates)
    return dates, out["T2M_MAX"], out["T2M_MIN"], np.maximum(out["PRECTOTCORR"], 0), {
        "days": int(len(dates)), "values_filled": int(filled), "pct_filled": round(100 * filled / max(total, 1), 2),
        "method": "gaps of up to 5 days linearly interpolated; longer gaps use the day-of-year mean"}


def _full_years(dates, tmax, tmin, rain):
    ys, rm = D.monthly_from_daily(dates, rain=rain)
    _, tm = D.monthly_from_daily(dates, temp=(tmax + tmin) / 2)
    ok = ~np.isnan(rm).any(axis=1) & ~np.isnan(tm).any(axis=1)
    return ys[ok], tm[ok], rm[ok]


# ---------------------------------------------------------------- detect
def _detect(ys, tm, rm, dates, rain):
    annual_t, annual_r = tm.mean(axis=1), rm.sum(axis=1)
    shifts = [D.detect_shift(ys, annual_t, "Temperature", "C"), D.detect_shift(ys, annual_r, "Annual rain", "mm")]
    sp = D.spi(rm.reshape(-1), 3)
    recent = sp[-24:]
    d = np.asarray(dates, "datetime64[D]")
    yr = d.astype("datetime64[Y]").astype(int) + 1970
    cdd = [D.max_consecutive_dry_days(rain[yr == y]) for y in ys]
    return {"shifts": shifts,
            "drought": {"spi3_lowest_last_24_months": None if np.all(np.isnan(recent)) else round(float(np.nanmin(recent)), 2),
                        "months_in_drought_last_24": int(np.nansum(recent <= -1.0)),
                        "longest_dry_spell_days_median": int(np.median(cdd)), "longest_dry_spell_days_worst": int(np.max(cdd)),
                        "note": "SPI-3 at or below -1 counts as moderate drought or worse"}}


# ---------------------------------------------------------------- NASA soil-wetness cross-check
def _wetness_check(raw, dates, tmax, tmin, rain, lat):
    """Does our water balance (rain minus Hargreaves ET0) track NASA's modelled root-zone wetness (GWETROOT)?"""
    if "GWETROOT" not in raw or np.all(np.isnan(raw["GWETROOT"])):
        return None
    from scipy import stats
    d = np.asarray(dates, "datetime64[D]")
    doy = (d - d.astype("datetime64[Y]")).astype(int) + 1
    et0 = S.hargreaves_et0(tmax, tmin, lat, doy)
    _, rm = D.monthly_from_daily(dates, rain=rain)
    _, em = D.monthly_from_daily(dates, rain=et0)
    _, wm = D.monthly_from_daily(dates, temp=np.where(np.isnan(raw["GWETROOT"]), np.nan, raw["GWETROOT"]))
    bal = rm - em
    ok = ~np.isnan(bal).any(axis=1) & ~np.isnan(wm).any(axis=1)
    if ok.sum() < 8:
        return None
    a = (bal[ok] - bal[ok].mean(0)).ravel(); b = (wm[ok] - wm[ok].mean(0)).ravel()
    r = float(stats.spearmanr(a, b)[0])
    return {"spearman_r": round(r, 2), "months": int(len(a)),
            "meaning": ("Our rain-minus-evaporation balance tracks NASA's modelled root-zone soil wetness (GWETROOT)." if r >= 0.5 else
                        "Our water balance only partly tracks NASA's modelled soil wetness here. Treat water-stress results with extra caution."),
            "method": "Spearman correlation of month-by-month anomalies, 'rain minus Hargreaves ET0' against GWETROOT from NASA POWER."}


# ---------------------------------------------------------------- satellite
def _ndvi_summary(nd):
    d = np.asarray(nd["dates"], "datetime64[D]")
    mon = d.astype("datetime64[M]").astype(int) % 12
    med = np.array([np.nanmedian(nd["ndvi"][mon == m]) if np.any((mon == m) & ~np.isnan(nd["ndvi"])) else np.nan for m in range(12)])
    if np.all(np.isnan(med)):
        return None
    lo, hi = np.nanmin(med), np.nanmax(med)
    thr = lo + 0.35 * (hi - lo)
    green = (med > thr) if hi - lo > 0.1 else np.zeros(12, bool)
    return {"median_ndvi": [None if np.isnan(x) else round(float(x), 3) for x in med], "green_months": [bool(x) for x in green],
            "bare_months": [MONTHS[i] for i in range(12) if not green[i]], "threshold": round(float(thr), 3),
            "seasonal_amplitude": round(float(hi - lo), 3), "years_used": int(len(np.unique(d.astype("datetime64[Y]")))),
            "method": "monthly median NDVI; a month counts as green when above 35% of the way from the lowest to the highest month. "
                      "A 250 m pixel mixes everything inside it, so treat this as a hint, not proof."}


# ---------------------------------------------------------------- simulation grid
def _risk_by_year(runs, years):
    out = np.full(len(years), np.nan)
    idx = {y: i for i, y in enumerate(years)}
    for r in runs:
        if r["year"] in idx:
            out[idx[r["year"]]] = min(1.0, 0.6 * r["water_stress"] + 0.4 * (r["water_stress"] > 0.25)
                                      + 0.2 * (r["heat_days"] >= 3) + 0.15 * (r["cold_days"] >= 2))
    return out


def _window(sow_month, days):
    start = int(MSTART[sow_month - 1] + SOW_DAY - 1)
    return start, start + int(round(days))


def _overlap(w1, w2):
    for shift in (-365, 0, 365):
        a0, a1 = w1[0], w1[1] + GAP
        b0, b1 = w2[0] + shift, w2[1] + shift
        if a0 < b1 and b0 < a1:
            return True
    return False


def _cell(dates, tx, tn, rn, lat, p, awc, m, irr):
    sd0 = S.season_distribution(dates, tx, tn, rn, lat, p, awc, m, 0.0, SOW_DAY)
    return sd0


def analyse(lat, lon, soil="auto", irrigation_mm=0.0, current=None, priorities=None, rain_pct=0.0, temp_c=0.0,
            sources=None, seed=0, years_back=None, soil_test=None, constraints=None, projection=None) -> dict:
    src = sources or Sources()
    notes, issues = [], []
    from concurrent.futures import ThreadPoolExecutor      # all four downloads start together: the slowest one sets the wait, not the sum of all
    _ex = ThreadPoolExecutor(max_workers=4)
    f_soil, f_el, f_nd = _ex.submit(src.soil, lat, lon), _ex.submit(src.elevation, lat, lon), _ex.submit(src.ndvi, lat, lon)
    _ex.shutdown(wait=False)
    pr = src.power(lat, lon)
    if not pr["ok"]:
        raise RuntimeError(f"NASA POWER daily data unavailable: {pr['error']}")
    bundled = bool(pr.get("bundled"))
    reg = datapack.region(lat, lon)
    if pr.get("backup"):
        issues.append("backup_weather")
        notes.append("NASA POWER could not be reached in time, so daily weather comes from the Open-Meteo archive (ERA5 reanalysis) instead. It is real measured-and-modelled weather, but it is not the NASA POWER record.")
    constraints = constraints or {}
    dates, tmax, tmin, rain, quality = _harmonise(pr["data"])
    ys, tm, rm = _full_years(dates, tmax, tmin, rain)
    need_years = 10 if bundled else 15
    if len(ys) < need_years:
        raise ValueError(f"Not enough evidence: only {len(ys)} complete years of weather data ({need_years} needed).")
    if bundled:
        issues.append("bundled_weather")
        notes.append("Live NASA POWER could not be reached, so the NASA POWER file you supplied (2015-2025, 11 years) was used. It has mean temperature only, so daily Tmax and Tmin are estimated from the model diurnal range. Trend tests have little power on 11 years.")
    xcheck = datapack.crosscheck_live(pr["data"]) if (reg["in_region"] and not bundled) else None

    # soil: SSURGO map unit chosen by the user > SoilGrids > user texture class > assumed loam
    t0 = time.time()
    _wait = lambda f, nm: ingest.wait(f, max(0.5, 10 - (time.time() - t0)), nm)       # soil, height and NDVI together get 10 s at most; late ones are skipped and filled for next time
    sr = _wait(f_soil, "SoilGrids")
    measured = sr["ok"] and {"sand", "clay"} <= set(sr["data"] or {})
    ssg, soil_source, ph, drainage = None, None, None, None
    if isinstance(soil, str) and soil.startswith("ssurgo:"):
        ssg = datapack.soil_profile(soil.split(":", 1)[1])
        if not ssg or not ssg.get("usable"):
            issues.append("ssurgo_unusable")
            notes.append("The chosen SSURGO map unit has no usable texture data, so the app fell back to the automatic soil lookup.")
            ssg, soil = None, "auto"
    if ssg:
        sand, clay, soil_source, measured = ssg["sand_pct"], ssg["clay_pct"], "ssurgo", True
        ph, drainage = ssg["ph"], ssg["drainage_class"]
        soil_note = (f"Soil from USDA SSURGO map unit {ssg['musym']} ({ssg['name']}), 0-30 cm: sand {sand:.0f}%, clay {clay:.0f}%, "
                     f"organic matter {ssg['organic_matter_pct']}%, pH {ssg['ph']}, water capacity {ssg['awc_mm_per_m']:.0f} mm/m.")
    elif soil == "auto" or soil is None:
        if measured:
            sand, clay = sr["data"]["sand"], sr["data"]["clay"]
            soil_source = "soilgrids"
            soil_note = f"Soil measured by SoilGrids (0-30 cm): sand {sand:.0f}%, clay {clay:.0f}%."
        else:
            sand, clay = TEXTURE["loam"]
            soil_source = "assumed"
            soil_note = "Soil lookup failed, so loam is assumed. Choose your soil type (or a SSURGO map unit near Diamond Valley) to improve this."
            issues.append("soil_assumed")
    else:
        sand, clay = TEXTURE[soil]
        soil_source = "user"
        soil_note = f"Soil set by you: {soil}."
    awc = float(ssg["awc_mm_per_m"]) if ssg and ssg.get("awc_mm_per_m") else S.awc_from_texture(sand, clay)
    k_fac = S.k_factor_from_texture(sand, clay)
    notes.append(soil_note)
    soil_test = dict(soil_test or {})
    if ssg and ssg.get("organic_matter_pct") is not None and soil_test.get("organic_carbon_pct") is None:
        soil_test["organic_carbon_pct"] = round(ssg["organic_matter_pct"] / 1.724, 2)           # van Bemmelen factor
        soil_test["_from_ssurgo"] = True
    if soil_test.get("ph") is not None:
        ph = float(soil_test["ph"])

    el = _wait(f_el, "Open-Meteo elevation")
    elev = float(el["data"]) if el.get("ok") and el.get("data") is not None else None
    nd = _wait(f_nd, "MODIS NDVI")
    ndvi = _ndvi_summary(nd["data"]) if nd["ok"] and nd["data"] else None
    if ndvi is None:
        issues.append("no_ndvi")
        notes.append("Satellite greenness unavailable, so the cropping calendar was not checked against what satellites see.")

    mld = None
    if nd["ok"] and nd["data"]:
        try:
            _, wm_all = D.monthly_from_daily(dates, temp=pr["data"].get("GWETROOT", np.full(len(dates), np.nan)))
            ys_all, tm_all = D.monthly_from_daily(dates, temp=(tmax + tmin) / 2)
            _, rm_all = D.monthly_from_daily(dates, rain=rain)
            mld = ml_detect.detect([int(y) for y in ys_all], tm_all, rm_all, wm_all, nd["data"]["dates"], nd["data"]["ndvi"], rain_pct, temp_c)
        except Exception as e:                      # noqa: BLE001
            notes.append(f"Learned stress detection failed ({type(e).__name__}).")
    if mld is None:
        issues.append("no_ml")

    # climate object for the anomaly module and the existing chart
    clim = Climate(temp=tm.mean(0), rain=rm.mean(0), temp_sd=tm.std(0), rain_sd=rm.std(0), source="nasa_power_daily",
                   lat=lat, lon=lon, years=len(ys), temp_year=tm, rain_year=rm, year_list=[int(y) for y in ys])
    anom = anomalies(clim)
    detection = _detect(ys, tm, rm, dates, rain)
    wcheck = _wetness_check(pr["data"], dates, tmax, tmin, rain, lat)
    if wcheck and wcheck["spearman_r"] < 0.5:
        issues.append("wetness_disagrees")

    # scenario applied to the daily series used for simulation
    tx, tn, rn = tmax + temp_c, tmin + temp_c, rain * (1 + rain_pct / 100)
    proj_info = None
    if projection:
        if not reg["in_region"]:
            issues.append("projection_out_of_region")
            notes.append(f"Climate projections are only supplied for {datapack.REGION_NAME}. This field is outside that area, so no projection was applied. Use the +temperature and rain sliders for what-if tests.")
        else:
            pj = datapack.projection(projection.get("scenario"), projection.get("period"))
            if pj:
                mon = np.asarray(dates, "datetime64[D]").astype("datetime64[M]").astype(int) % 12
                tx = tx + np.array(pj["delta_tmax_c"])[mon]; tn = tn + np.array(pj["delta_tmin_c"])[mon]
                rn = rn * np.array(pj["rain_ratio"])[mon]
                proj_info = {k: pj[k] for k in ("scenario", "scenario_name", "period", "annual_delta_t_c", "annual_rain_change_pct", "summer_delta_t_c", "delta_t_c", "rain_ratio", "baseline")}
                notes.append(f"Future climate applied: {pj['scenario_name']}, {pj['period']} (about {pj['annual_delta_t_c']:+.1f} C and {pj['annual_rain_change_pct']:+.0f}% annual rain versus 2015-2025, NASA NEX-GDDP-CMIP6 ensemble, delta-change method).")
    params = S.load_params()
    years = [int(y) for y in ys]
    pri = {**DEFAULT_PRI, **(priorities or {})}
    doy_all = (np.asarray(dates, "datetime64[D]") - np.asarray(dates, "datetime64[D]").astype("datetime64[Y]")).astype(int)
    irr = float(irrigation_mm)
    cap = constraints.get("max_irrigation_mm")
    if cap is not None and irr > cap:
        notes.append(f"Irrigation reduced from {irr:.0f} to {cap:.0f} mm because of your maximum irrigation allocation.")
        irr = float(cap)
    constraints_applied = []
    if cap is not None:
        constraints_applied.append(f"Irrigation limited to {cap:.0f} mm/year")

    # simulate every crop at every sowing month
    cells = {}
    for cid, p in params.items():
        for m in range(1, 13):
            sd0 = S.season_distribution(dates, tx, tn, rn, lat, p, awc, m, 0.0, SOW_DAY)
            if sd0["n_years"] < 0.7 * len(ys):
                continue
            sd1 = S.season_distribution(dates, tx, tn, rn, lat, p, awc, m, irr, SOW_DAY) if irr > 0 else sd0
            cells[(cid, m)] = {
                "sd": sd1, "need": float(np.median([r["etc_mm"] - r["eta_mm"] for r in sd0["runs"]])),
                "etc": float(np.median([r["etc_mm"] for r in sd0["runs"]])), "risk_y": _risk_by_year(sd1["runs"], years),
                "risk": float(np.nanmean(_risk_by_year(sd1["runs"], years))), "days": sd1["season_days_p50"],
                "cover": sd1["mean_cover"], "win": _window(m, sd1["season_days_p50"])}
    if not cells:
        raise ValueError("Not enough evidence: no crop completes a season in at least 70% of years here.")

    # candidate rotations
    top = {}
    for cid in params:
        ms = sorted([m for (c, m) in cells if c == cid], key=lambda m: cells[(cid, m)]["risk"])[:3]
        if ms:
            top[cid] = ms
    cand = []
    ids = list(top)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            if params[a].family == params[b].family:
                continue
            for ma in top[a]:
                for mb in top[b]:
                    if not _overlap(cells[(a, ma)]["win"], cells[(b, mb)]["win"]):
                        cand.append(((a, ma), (b, mb), False))

    cur_rec, cur_note = None, None
    if current:
        a, b = current
        opts = [(x, y) for x in range(1, 13) for y in range(1, 13) if (a, x) in cells and (b, y) in cells]
        if not opts:
            cur_note = "One of your current crops does not complete a season in most years at this location."
        else:
            ok = [(x, y) for x, y in opts if not _overlap(cells[(a, x)]["win"], cells[(b, y)]["win"])]
            pool = ok or opts
            x, y = min(pool, key=lambda t: cells[(a, t[0])]["risk"] + cells[(b, t[1])]["risk"])
            cur_rec = ((a, x), (b, y), not ok)
            if not ok:
                cur_note = "The two crops' seasons overlap in the same year here. Check that double-cropping is feasible."
    # unique key for each candidate
    seen, allc = set(), []
    for c in ([cur_rec] if cur_rec else []) + cand:
        key = (c[0], c[1])
        if key not in seen:
            seen.add(key)
            allc.append(c)
    if not allc:
        raise ValueError("Not enough evidence: no compatible crop pairs found for this location.")

    # score every candidate
    P = len(allc)
    need = np.zeros(P); etc = np.zeros(P); clim_y = np.zeros((P, len(years))); eros = np.zeros(P)
    nfx = np.zeros(P); erj = np.zeros(P); omj = np.zeros(P); fgj = np.zeros(P); mkj = np.zeros(P); bonus = np.zeros(P)
    for i, ((a, ma), (b, mb), _ov) in enumerate(allc):
        A, B = cells[(a, ma)], cells[(b, mb)]
        need[i] = A["need"] + B["need"]; etc[i] = A["etc"] + B["etc"]
        ry = np.vstack([A["risk_y"], B["risk_y"]])
        col = np.nanmean(ry, axis=0)
        clim_y[i] = 1 - np.where(np.isnan(col), np.nanmean(col), col)
        cov = np.zeros(365)
        for cell in (A, B):
            for d in range(cell["win"][0], cell["win"][1]):
                cov[d % 365] = max(cov[d % 365], cell["cover"])
        eros[i] = S.erosion_index(rn, cov[np.minimum(doy_all, 364)], k_fac)
        pa, pb = params[a], params[b]
        nfx[i] = (pa.j_nfix + pb.j_nfix) / 10; erj[i] = (pa.j_erosion + pb.j_erosion) / 10
        omj[i] = (pa.j_om + pb.j_om) / 10; fgj[i] = (pa.j_forage + pb.j_forage) / 10; mkj[i] = (pa.j_market + pb.j_market) / 10
        bonus[i] = 0.04 * float(pa.nfix > 0 or pb.nfix > 0)
        loc = [datapack.local_presence(x) for x in (a, b)]
        if reg["in_region"]:                                      # market proxy: how much of this crop is actually grown nearby (CDL)
            mkj[i] = 0.5 * mkj[i] + 0.5 * float(np.mean([min(1.0, 0.25 + 4 * l["share_of_cropland"]) if l["reliable"] else 0.0 for l in loc]))
        mk = constraints.get("market_crops") or []
        if mk:
            mkj[i] = 0.5 * mkj[i] + 0.5 * float(np.mean([1.0 if x in mk else 0.0 for x in (a, b)]))
        hist = constraints.get("history") or []
        if hist:
            last = params.get(hist[0]["crop"])
            if last and last.family in (params[a].family, params[b].family):
                bonus[i] -= 0.06
    en = eros / max(eros.max(), 1e-9)
    s_water = 1 - need / max(need.max(), 1.0)
    stab = 1 - np.clip(clim_y.std(axis=1) / max(clim_y.std(axis=1).max(), 1e-9), 0, 1)
    comp = {"water": s_water, "nfix": nfx, "erosion": 0.5 * erj + 0.5 * (1 - en), "om": 0.7 * omj + 0.3 * (1 - en),
            "forage": fgj, "market": mkj, "stability": stab}
    w = np.array([max(0.0, float(pri[k])) for k in comp]); w = w / w.sum() if w.sum() > 0 else np.full(len(comp), 1 / len(comp))
    pm = sum(wi * comp[k] for wi, k in zip(w, comp))
    cf = clim_y.mean(axis=1)
    total = 0.45 * cf + 0.55 * pm + bonus

    # uncertainty: every historical year x judgement noise
    rng = np.random.default_rng(seed)
    nd_ = 8
    tot_d = np.concatenate([0.45 * clim_y + 0.55 * np.clip(pm[:, None] + rng.normal(0, 0.07, (P, len(years))), 0, 1) + bonus[:, None]
                            for _ in range(nd_)], axis=1)
    p10, p90 = np.percentile(tot_d, 10, axis=1), np.percentile(tot_d, 90, axis=1)
    rank = np.argsort(np.argsort(-tot_d, axis=0), axis=0)
    top3 = (rank < 3).mean(axis=1)
    cur_i = 0 if cur_rec else None
    beats = (tot_d > tot_d[cur_i][None, :]).mean(axis=1) if cur_i is not None else np.full(P, np.nan)

    viable = np.array([cf[i] >= 0.6 for i in range(P)])
    viable[0] = viable[0] or cur_i == 0
    picks, used = [], set()

    def pick(label, why, score, mask):
        order = np.argsort(-np.where(mask, score, -1e9))
        for i in order:
            if not mask[i] or i in used or (cur_i is not None and i == cur_i):
                continue
            used.add(int(i))
            picks.append((label, why, int(i)))
            return

    if cur_i is not None:
        used.add(0)
        picks.append(("Your current rotation", "This is what you grow now. It is the baseline the other options are compared with.", 0))
    pick("Best match to your priorities", "Highest score once your priorities and the simulated climate stress are combined.", total, viable)
    pick("Water-saving option", "Needs the least extra water while still passing the climate test.", s_water + 0.3 * cf, viable & (total >= np.max(total[viable]) - 0.2))
    pick("Soil-building option", "Strongest mix of cover, residue and nitrogen from legumes while still passing the climate test.",
         0.4 * comp["erosion"] + 0.3 * comp["nfix"] + 0.3 * comp["om"] + 0.2 * cf, viable)
    pick("Lowest climate risk", "Fewest simulated bad seasons from water stress, heat and cold across past years.", cf, viable)
    if len(picks) < 3:
        issues.append("few_strategies")

    # trend projection (only a significant trend is carried forward)
    mk_t = detection["shifts"][0]["mann_kendall"]
    dT = (mk_t["slope"] * (2040 - float(np.mean(ys)))) if (mk_t.get("p") is not None and mk_t["p"] < 0.1) else 0.0
    proj = {"warming_to_2040_c": round(float(dT), 2),
            "note": "Applies the measured warming trend to 2040 only when the trend test is significant." if dT else
                    "No significant warming trend was detected, so 2040 is simulated as today."}

    def project_fit(i):
        (a, ma), (b, mb), _ = allc[i]
        outs = []
        for cid, m in ((a, ma), (b, mb)):
            sd = S.season_distribution(dates, tx + dT, tn + dT, rn, lat, params[cid], awc, m, irr, SOW_DAY)
            outs.append(1 - np.nanmean(_risk_by_year(sd["runs"], years)) if sd["n_years"] else np.nan)
        return float(np.nanmean(outs))

    grade = "B" if not issues and len(ys) >= 15 else "C"
    reasons = ["Crop parameters are estimates (no local yield data)."] + (["Soil was assumed, not measured."] if "soil_assumed" in issues else []) \
        + (["Satellite greenness was unavailable."] if "no_ndvi" in issues else []) \
        + (["Water balance only partly agrees with NASA soil wetness."] if "wetness_disagrees" in issues else [])

    strategies = []
    for label, why, i in picks:
        strategies.append(_record(label, why, i, allc, cells, params, dates, rn, tm, rm, ys, total, pm, cf, need, etc, p10, p90, top3, beats,
                                  cur_i, cur_rec, cur_note, ndvi, grade, reasons, project_fit, detection, k_fac, en, comp, s_water))
    if ndvi and cur_i is not None:
        cal = strategies[0]["calendar"]
        agree = float(np.mean([(cal[m] != "bare") == ndvi["green_months"][m] for m in range(12)]))
        ndvi["agreement_with_current"] = round(agree, 2)
        if agree < 0.6:
            strategies[0]["information_gaps"].append(
                f"Satellite greenness agrees with your stated rotation in only {agree*100:.0f}% of months. Check the crops and dates you entered.")

    base = strategies[0]
    ci = picks[0][2]
    vul = V.assess(base, rm.sum(axis=1), float(en[ci]), soil_test, grade, issues)
    return {
        "location": {"lat": lat, "lon": lon, "elevation_m": elev}, "region": reg, "projection": proj_info, "constraints": {"applied": constraints_applied, "given": {k: v for k, v in constraints.items() if k != "boundary"}},
        "vulnerability": vul, "vulnerability_for": base["label"],
        "climate": {
            "source": "open_meteo_era5_backup" if pr.get("backup") else "nasa_power", "notes": notes, "years_of_data": int(len(ys)),
            "monthly_temp_c": [round(float(x), 2) for x in tm.mean(0)], "monthly_rain_mm": [round(float(x), 1) for x in rm.mean(0)],
            "annual_rain_mm": round(float(rm.sum(1).mean()), 0),
            "rain_trend_mm_per_year": round(float(detection["shifts"][1]["mann_kendall"]["slope"] or 0), 2),
            "warming_trend_c_per_decade": round(float((detection["shifts"][0]["mann_kendall"]["slope"] or 0) * 10), 3),
            "anomalies": None if anom is None else anom.to_json(), "soil_wetness_by_month": None,
            "normals": F.doy_normals(dates, tmax, tmin, rain)},
        "detection": detection, "satellite": ndvi, "nasa_soil_wetness_check": wcheck, "ml_detection": mld, "trend_projection": proj,
        "data_quality": {**quality, "years": int(len(ys)), "fetched_at": pr["fetched_at"], "last_weather_date": str(np.asarray(dates, "datetime64[D]")[-1]), "first_weather_date": str(np.asarray(dates, "datetime64[D]")[0]),
                         "sources": {"NASA POWER daily": not pr.get("backup"), "Open-Meteo ERA5 (backup, NASA POWER unreachable)": bool(pr.get("backup")), "NASA POWER (supplied file)": bundled, "USDA SSURGO": soil_source == "ssurgo", "SoilGrids": bool(measured), "MODIS NDVI": ndvi is not None},
                         "elevation_m": elev, "soil": {"sand_pct": round(sand, 1), "clay_pct": round(clay, 1), "awc_mm_per_m": round(awc, 0), "measured": bool(measured), "source": soil_source, "ph": ph, "ssurgo": ssg},
                         "bundled_weather": bundled, "live_vs_supplied": xcheck},
        "ecocrop": ecocrop.assess_all([float(x) for x in tm.mean(0)], float(rm.sum(1).mean()) + irr, ph, sand, clay, drainage),
        "local_crops": datapack.cdl()["crops"][:8] if reg["in_region"] else None,
        "evidence_grade": {"grade": grade, "reasons": reasons},
        "strategies": strategies,
        "planting": {cid: {"name": params[cid].name, "heat_crit": params[cid].heat_crit, "cold_crit": params[cid].cold_crit, "tbase": params[cid].tbase,
                           "months": [{"month": m, "month_name": MONTHS[m - 1], "bad_season_pct": round(c["sd"]["p_bad_season"] * 100), "heat_damage_pct": round(c["sd"]["p_heat_damage"] * 100),
                                       "cold_damage_pct": round(c["sd"]["p_cold_damage"] * 100), "season_days": round(c["days"]), "risk": round(c["risk"], 3), "years": c["sd"]["n_years"]}
                                      for (k, m), c in sorted(cells.items()) if k == cid]}
                     for cid in params if any(k == cid for (k, _m) in cells)},
        "disclaimer": "Decision support only. Compares options against each other using simulated water, heat and cold stress. "
                      "It does not predict yield or profit. Review with a farmer or local agricultural adviser."}


def _record(label, why, i, allc, cells, params, dates, rain, tm, rm, ys, total, pm, cf, need, etc, p10, p90, top3, beats,
            cur_i, cur_rec, cur_note, ndvi, grade, reasons, project_fit, detection, k_fac, en, comp, s_water):
    (a, ma), (b, mb), overlap = allc[i]
    order = sorted([(a, ma), (b, mb)], key=lambda t: t[1])
    crops, cal = [], ["bare"] * 12
    mean_t = tm.mean(0)
    for letter, (cid, m) in zip("AB", order):
        c, p = cells[(cid, m)], params[cid]
        sd = c["sd"]
        start, end = c["win"]
        months = sorted({int(((d % 365) // 30.42)) % 12 for d in range(start, end)})
        months = [min(11, x) for x in months]
        for d in range(start, end, 5):
            mi = int(np.searchsorted(np.r_[MSTART, 365], d % 365, side="right") - 1)
            if cal[mi] == "bare":
                cal[mi] = letter
        rin = float(np.mean([rm[:, mm].sum() / max(len(ys), 1) for mm in months]) * len(months) / max(len(months), 1)) if months else 0.0
        crops.append({
            "id": cid, "name": p.name, "sow_month": MONTHS[m - 1], "months": [MONTHS[x] for x in months],
            "rain_in_season_mm": round(float(sum(rm[:, mm].mean() for mm in months)), 0), "typical_need_mm": round(c["etc"], 0),
            "monthly_temp_range_c": [round(float(min(mean_t[x] for x in months)), 1), round(float(max(mean_t[x] for x in months)), 1)],
            "comfortable_range_c": [p.tbase, p.tcap], "temperature_fit": round(1 - min(1, 0.6 * sd["p_heat_damage"] + 0.4 * sd["p_cold_damage"]), 3),
            "water_fit": round(1 - sd["water_stress_p50"], 3), "hot_months": int(sd["heat_days_p50"] >= 3), "cold_risk": bool(sd["p_cold_damage"] > 0.25),
            "data_confidence": p.confidence, "sources": list(p.sources), "dry_year_share": round(sd["p_bad_season"], 2),
            "hot_year_share": round(sd["p_heat_damage"], 2), "cold_year_share": round(sd["p_cold_damage"], 2),
            "water_stress_p10_p90": [round(sd["water_stress_p10"], 2), round(sd["water_stress_p90"], 2)], "season_days": int(round(sd["season_days_p50"])),
            "years_simulated": sd["n_years"]})
    bare = [MONTHS[m] for m in range(12) if cal[m] == "bare"]
    shortfall = float(need[i]); rc = max(0.0, min(100.0, 100 * (1 - shortfall / max(etc[i], 1.0))))
    A, B = crops
    evidence = [f"Across {A['years_simulated']} years of NASA daily weather, {A['name']} sown in {A['sow_month']} had a water-stress bad season in "
                f"{A['dry_year_share']*100:.0f}% of years and {B['name']} sown in {B['sow_month']} in {B['dry_year_share']*100:.0f}%.",
                f"Without irrigation the two crops fall about {shortfall:.0f} mm short of their water need in a typical year (rain covers about {rc:.0f}%)."]
    if A["hot_year_share"] >= 0.25 or B["hot_year_share"] >= 0.25:
        evidence.append("Heat during flowering damaged at least one of the crops in a quarter or more of past years.")
    if bare:
        evidence.append(f"The field is bare in {', '.join(bare)} (no crop growing).")
    benefits = []
    if params[a].nfix > 0 or params[b].nfix > 0:
        benefits.append("Includes a legume, which adds nitrogen for the next crop.")
    if len(bare) <= 3:
        benefits.append("Short bare period, so less exposure to erosion and water loss.")
    if rc >= 80:
        benefits.append("Rain covers most of the crop water need.")
    if not benefits:
        benefits.append("No clear advantage in the factors this tool covers.")
    gaps = ["Crop parameters are estimates until checked with local agronomy.",
            "No local yield, price, pest or labour data. This compares stress, not profit.",
            "Weather is NASA's modelled grid (about 50 km), not measured at your field."]
    gaps += [r for r in reasons if "Soil" in r or "Satellite" in r]
    if cur_note and i == 0 and cur_rec:
        gaps.append(cur_note)
    risks = []
    for c in crops:
        if c["dry_year_share"] >= 0.25:
            risks.append(f"{c['name']}: bad water-stress seasons in {c['dry_year_share']*100:.0f}% of past years.")
        if c["hot_year_share"] >= 0.25:
            risks.append(f"{c['name']}: heat damage during flowering in {c['hot_year_share']*100:.0f}% of past years.")
        if c["cold_year_share"] >= 0.25:
            risks.append(f"{c['name']}: cold damage in {c['cold_year_share']*100:.0f}% of past years.")
    if len(bare) >= 4:
        risks.append(f"{len(bare)} bare months raise erosion and water loss. Consider a cover crop.")
    if overlap:
        risks.append("The two crop seasons overlap in the same year. Check that this double-cropping is feasible.")
    interventions = []
    if len(bare) >= 2:
        interventions.append(f"Consider a short cover crop or mulch during the bare months ({', '.join(bare)}) to reduce erosion and water loss.")
    for c in crops:
        if c["dry_year_share"] >= 0.25:
            interventions.append(f"Plan irrigation or moisture conservation for {c['name']} (water stress in {c['dry_year_share']*100:.0f}% of past years).")
        if c["hot_year_share"] >= 0.25:
            interventions.append(f"Consider an earlier sowing date or a more heat-tolerant variety for {c['name']} to avoid heat at flowering.")
    if params[a].nfix > 0 or params[b].nfix > 0:
        interventions.append("Return legume residue to the soil to capture the nitrogen benefit.")
    pf = project_fit(i)
    return {"label": label, "why": why, "crops": crops, "calendar": cal, "bare_months": bare,
            "scores": {"overall": round(float(total[i]), 3), "climate_fit": round(float(cf[i]), 3), "priority_match": round(float(pm[i]), 3),
                       "irrigation_need_mm_per_year": round(shortfall, 0), "rain_covers_pct": round(rc, 0),
                       "climate_fit_2040": round(pf, 3),
                       "components": {"climate_fit": round(float(cf[i]), 3), "water_efficiency": round(float(s_water[i]), 3),
                                      "erosion_protection": round(float(comp["erosion"][i]), 3), "soil_organic_matter": round(float(comp["om"][i]), 3),
                                      "nitrogen": round(float(comp["nfix"][i]), 3), "market": round(float(comp["market"][i]), 3)}},
            "uncertainty": {"overall_p10": round(float(p10[i]), 3), "overall_p90": round(float(p90[i]), 3),
                            "p_in_top3": round(float(top3[i]), 2),
                            "p_beats_current": None if cur_i is None or np.isnan(beats[i]) else round(float(beats[i]), 2),
                            "draws": 8 * len(ys),
                            "method": "Every historical year simulated, plus noise on the 0-5 judgement scores."},
            "evidence_grade": grade, "evidence": evidence, "benefits": benefits, "information_gaps": gaps,
            "risks_for_local_review": risks, "interventions": interventions}
