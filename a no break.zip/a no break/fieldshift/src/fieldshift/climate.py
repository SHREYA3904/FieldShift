"""Climate object (12 monthly values + interannual spread) and loaders.

Layer 1 (ingest) and layer 2 (harmonise): everything downstream sees a Climate,
whatever the source (NASA POWER, a CSV, or the synthetic generator for tests).
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field

import numpy as np
import requests

POWER_URL = "https://power.larc.nasa.gov/api/temporal/monthly/point"
DAYS = 30.4


@dataclass
class Climate:
    temp: np.ndarray            # monthly mean air temperature, C, shape (12,)
    rain: np.ndarray            # monthly rain, mm, shape (12,)
    temp_sd: np.ndarray         # interannual SD of monthly temperature
    rain_sd: np.ndarray         # interannual SD of monthly rain (mm)
    soil_wet: np.ndarray | None = None   # root-zone wetness 0-1, modelled
    rain_trend: float = 0.0     # mm per year, linear trend of annual rain
    temp_trend: float = 0.0     # C per year
    years: int = 0
    source: str = "unknown"     # "nasa_power", "synthetic", "csv"
    lat: float = 0.0
    lon: float = 0.0
    temp_year: np.ndarray | None = None   # (years, 12) monthly temperature per year
    rain_year: np.ndarray | None = None   # (years, 12) monthly rain per year, mm
    year_list: list = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def annual_rain(self) -> float:
        return float(self.rain.sum())


def _slope(xs, vs):
    xs = np.asarray(xs, float)
    vs = np.asarray(vs, float)
    if len(xs) < 3:
        return 0.0
    xm, vm = xs.mean(), vs.mean()
    den = ((xs - xm) ** 2).sum()
    return float(((xs - xm) * (vs - vm)).sum() / den) if den else 0.0


def from_power_json(js: dict, lat: float = 0.0, lon: float = 0.0) -> Climate:
    """Parse a NASA POWER monthly point response (T2M, PRECTOTCORR, GWETROOT)."""
    p = js["properties"]["parameter"]
    t, r = p["T2M"], p["PRECTOTCORR"]
    w = p.get("GWETROOT")
    tm = [[] for _ in range(12)]
    rm = [[] for _ in range(12)]
    wm = [[] for _ in range(12)]
    years: dict[int, dict] = {}
    for k, tv in t.items():
        y, m = int(k[:4]), int(k[4:]) - 1
        if not 0 <= m <= 11:
            continue                      # POWER uses month 13 for the annual mean
        rv = r.get(k, -999)
        if tv < -900 or rv < -900:
            continue
        tm[m].append(tv)
        rm[m].append(rv * DAYS)           # mm/day -> mm/month
        if w and w.get(k, -999) > -900:
            wm[m].append(w[k])
        years.setdefault(y, {"t": [], "r": []})
        years[y]["t"].append(tv)
        years[y]["r"].append(rv * DAYS)
    if any(len(x) == 0 for x in tm):
        raise ValueError("POWER response is missing months")
    full = sorted(y for y, d in years.items() if len(d["t"]) == 12)
    ty = np.array([years[y]["t"] for y in full]) if full else None
    ry = np.array([years[y]["r"] for y in full]) if full else None
    return Climate(
        temp_year=ty, rain_year=ry, year_list=full,
        temp=np.array([np.mean(x) for x in tm]),
        rain=np.array([np.mean(x) for x in rm]),
        temp_sd=np.array([np.std(x) for x in tm]),
        rain_sd=np.array([np.std(x) for x in rm]),
        soil_wet=np.array([np.mean(x) for x in wm]) if all(wm) else None,
        rain_trend=_slope(full, [sum(years[y]["r"]) for y in full]),
        temp_trend=_slope(full, [np.mean(years[y]["t"]) for y in full]),
        years=len(full), source="nasa_power", lat=lat, lon=lon,
    )


def fetch_power(lat: float, lon: float, start: int = 2005, end: int = 2025,
                cache_dir: str = "cache", timeout: int = 60) -> Climate:
    """Layer 1: call the NASA POWER API (no key needed). Responses are cached on disk."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"power_{lat:.2f}_{lon:.2f}_{start}_{end}.json")
    if os.path.exists(path):
        with open(path) as f:
            js = json.load(f)
    else:
        params = {"parameters": "T2M,PRECTOTCORR,GWETROOT", "community": "AG",
                  "longitude": lon, "latitude": lat, "start": start, "end": end, "format": "JSON"}
        resp = requests.get(POWER_URL, params=params, timeout=timeout)
        resp.raise_for_status()
        js = resp.json()
        with open(path, "w") as f:
            json.dump(js, f)
    return from_power_json(js, lat, lon)


def synthetic(lat: float, annual_rain: float = 800, mean_t: float = 22, amp: float = 8,
              wet_season_share: float = 0.7, seed: int = 0) -> Climate:
    """Deterministic fake climate for tests and offline demos. Clearly labelled as synthetic."""
    phase = 6 if lat < 0 else 0
    rain, temp = [], []
    for m in range(12):
        mm = (m - phase) % 12
        share = wet_season_share / 5 if 5 <= mm <= 9 else (1 - wet_season_share) / 7
        rain.append(annual_rain * share)
        temp.append(mean_t + amp * math.sin((mm - 3) / 12 * 2 * math.pi))
    rain, temp = np.array(rain), np.array(temp)
    rng = np.random.default_rng(seed)
    ty = temp + rng.normal(0, 1.0, (21, 12))
    ry = np.maximum(0.0, rain + rng.normal(0, 1, (21, 12)) * rain * 0.35)
    return Climate(temp=temp, rain=rain, temp_sd=np.full(12, 1.0), rain_sd=rain * 0.35,
                   temp_year=ty, rain_year=ry, year_list=list(range(2005, 2026)),
                   soil_wet=None, years=0, source="synthetic", lat=lat, lon=0.0,
                   notes=["Synthetic climate: for testing only, not real observations."])
