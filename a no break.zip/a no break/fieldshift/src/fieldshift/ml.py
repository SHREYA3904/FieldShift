"""Pattern finding: statistical anomaly detection on the monthly climate history.

Robust z-scores (median and MAD, so a few extreme years do not hide themselves) are computed for every
month of every year. From them we get (1) how often each month is unusually dry, wet, hot or cold, i.e. when
crops are typically vulnerable, (2) the most unusual recent months, and (3) per-year flags used to say how
often a crop's growing season was stressed in the past. This is explainable statistics, not a black box.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .climate import Climate

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
THRESH = 1.5          # |robust z| at or above this counts as unusual


def robust_z(mat: np.ndarray, floor: np.ndarray) -> np.ndarray:
    med = np.median(mat, axis=0)
    mad = np.median(np.abs(mat - med), axis=0)
    scale = np.maximum(mad / 0.6745, floor)
    return (mat - med) / scale


@dataclass
class Anomalies:
    zt: np.ndarray            # (years, 12)
    zr: np.ndarray
    years: list
    risk: dict                # kind -> (12,) fraction of years that month was unusual
    recent: list              # most unusual recent months

    def to_json(self) -> dict:
        return {
            "method": "robust z-score (median and MAD) per calendar month; unusual means |z| >= %.1f" % THRESH,
            "years": [int(y) for y in self.years],
            "monthly_risk": {k: [round(float(x), 3) for x in v] for k, v in self.risk.items()},
            "recent_unusual_months": self.recent,
        }

    def season_share(self, months, kind: str) -> float:
        """Share of past years in which at least one of `months` was unusually dry/wet/hot/cold."""
        idx = list(months)
        z = {"dry": -self.zr, "wet": self.zr, "hot": self.zt, "cold": -self.zt}[kind]
        return float((z[:, idx] >= THRESH).any(axis=1).mean())


def analyse(clim: Climate, last_n: int = 5) -> Anomalies | None:
    if clim.temp_year is None or clim.rain_year is None or len(clim.temp_year) < 8:
        return None
    ty, ry = clim.temp_year, clim.rain_year
    zt = robust_z(ty, np.full(12, 0.3))
    zr = robust_z(ry, np.maximum(5.0, 0.1 * np.median(ry, axis=0)))
    risk = {"dry": (zr <= -THRESH).mean(0), "wet": (zr >= THRESH).mean(0),
            "hot": (zt >= THRESH).mean(0), "cold": (zt <= -THRESH).mean(0)}
    rec = []
    for yi in range(len(clim.year_list) - last_n, len(clim.year_list)):
        for m in range(12):
            for kind, z in (("dry", -zr[yi, m]), ("wet", zr[yi, m]), ("hot", zt[yi, m]), ("cold", -zt[yi, m])):
                if z >= THRESH:
                    rec.append({"year": int(clim.year_list[yi]), "month": MONTHS[m], "kind": kind, "z": round(float(z), 2)})
    rec.sort(key=lambda r: -r["z"])
    return Anomalies(zt, zr, list(clim.year_list), risk, rec[:8])
