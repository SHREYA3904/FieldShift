"""Learned detection of crop stress, trained on the location's own history (no pooled data, no labels needed).

Idea: a gradient-boosted model learns how THIS place's satellite greenness (MODIS NDVI) responds to weather
and soil wetness. Then
  1. leave-one-year-out predictions give the greenness we would expect from weather alone;
  2. months where observed greenness falls well short of that are flagged: stress the weather numbers do not explain
     (pests, management, waterlogging, a failed or skipped crop, data problems);
  3. skill against a plain monthly average is measured honestly, and the model is marked unreliable when it does not beat it;
  4. the same model estimates how greenness would respond to a weather scenario.
It detects from the satellite signal; NASA weather is only an input feature.
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def monthly_ndvi(dates, ndvi):
    d = np.asarray(dates, "datetime64[D]")
    ym = d.astype("datetime64[M]")
    out = {}
    for m in np.unique(ym):
        v = ndvi[ym == m]
        v = v[~np.isnan(v)]
        if len(v):
            out[int(m.astype(int))] = float(np.median(v))        # months since 1970-01
    return out


def _features(years, tm, rm, wm):
    """One row per (year, month) with weather and one-to-three-month memory."""
    rows, keys = [], []
    n = len(years)
    flat_r, flat_t = rm.reshape(-1), tm.reshape(-1)
    flat_w = wm.reshape(-1) if wm is not None else np.full(n * 12, np.nan)
    for i in range(n * 12):
        y, m = years[i // 12], i % 12
        r1 = flat_r[i - 1] if i >= 1 else np.nan
        r3 = flat_r[max(0, i - 2):i + 1].sum()
        r6 = flat_r[max(0, i - 5):i + 1].sum()
        rows.append([flat_t[i], flat_r[i], r1, r3, r6, flat_w[i], np.sin(2 * np.pi * m / 12), np.cos(2 * np.pi * m / 12)])
        keys.append((int(y), m))
    return np.array(rows, float), keys


def _model():
    return HistGradientBoostingRegressor(max_depth=3, learning_rate=0.08, max_iter=150, min_samples_leaf=6,
                                         l2_regularization=1.0, random_state=0)


def detect(years, tm, rm, wm, nd_dates, nd_values, rain_pct=0.0, temp_c=0.0, z_thresh=1.5) -> dict | None:
    """years: list of years aligned to rows of tm/rm/wm (years x 12). Returns None if too little satellite data."""
    obs = monthly_ndvi(nd_dates, nd_values)
    X, keys = _features(years, tm, rm, wm)
    idx = [i for i, (y, m) in enumerate(keys) if (int(np.datetime64(f"{y}-{m+1:02d}", "M").astype(int))) in obs]
    if len(idx) < 60:
        return None
    y_obs = np.array([obs[int(np.datetime64(f"{keys[i][0]}-{keys[i][1]+1:02d}", "M").astype(int))] for i in idx])
    Xs = X[idx]
    yrs = np.array([keys[i][0] for i in idx])
    mons = np.array([keys[i][1] for i in idx])
    uy = np.unique(yrs)
    if len(uy) < 5:
        return None

    pred = np.zeros(len(idx)); base = np.zeros(len(idx))
    for y in uy:                                                   # leave one year out
        te, tr = yrs == y, yrs != y
        m = _model().fit(Xs[tr], y_obs[tr])
        pred[te] = m.predict(Xs[te])
        for mo in np.unique(mons[te]):                             # baseline: that month's mean in the other years
            sel = tr & (mons == mo)
            base[te & (mons == mo)] = y_obs[sel].mean() if sel.any() else y_obs[tr].mean()
    mae_m, mae_b = float(np.mean(np.abs(y_obs - pred))), float(np.mean(np.abs(y_obs - base)))
    skill = 1 - mae_m / mae_b if mae_b > 0 else 0.0
    ss_tot = float(np.sum((y_obs - y_obs.mean()) ** 2))
    r2 = 1 - float(np.sum((y_obs - pred) ** 2)) / ss_tot if ss_tot > 0 else 0.0

    resid = y_obs - pred
    mad = np.median(np.abs(resid - np.median(resid))) * 1.4826
    sd = max(mad, 0.02)
    z = (resid - np.median(resid)) / sd
    flagged = [{"year": int(yrs[i]), "month": MONTHS[mons[i]], "observed_ndvi": round(float(y_obs[i]), 2),
                "expected_ndvi": round(float(pred[i]), 2), "z": round(float(z[i]), 1)}
               for i in np.argsort(z) if z[i] <= -z_thresh][:12]
    reliable = bool(skill > 0.05 and r2 > 0.3)

    final = _model().fit(Xs, y_obs)
    resp = None
    if abs(rain_pct) > 0 or abs(temp_c) > 0:
        Xa = Xs.copy()
        Xa[:, 0] += temp_c
        for c in (1, 2, 3, 4):
            Xa[:, c] *= (1 + rain_pct / 100)
        d = final.predict(Xa) - final.predict(Xs)
        resp = {"mean_change_ndvi": round(float(d.mean()), 3),
                "by_month": [round(float(d[mons == m].mean()), 3) if (mons == m).any() else None for m in range(12)],
                "meaning": "Estimated change in satellite greenness if weather shifted as set in the sliders. A learned estimate, not a forecast."}
    recent = [{"year": int(yrs[i]), "month": MONTHS[mons[i]], "observed": round(float(y_obs[i]), 3), "expected": round(float(pred[i]), 3)}
              for i in range(len(idx) - 36, len(idx))]
    return {"method": "Gradient-boosted model of monthly NDVI from weather, rain memory and soil wetness, trained on this location, scored with leave-one-year-out.",
            "months_used": int(len(idx)), "years_used": int(len(uy)),
            "skill_vs_monthly_average": round(float(skill), 2), "r2": round(float(r2), 2), "mae_ndvi": round(mae_m, 3), "reliable": reliable,
            "verdict": ("The model explains local greenness better than a plain monthly average, so unexplained dips are meaningful."
                        if reliable else "The model does not beat a plain monthly average here, so treat its flags and scenario response as weak."),
            "unexplained_stress": flagged, "recent": recent, "scenario_response": resp}
