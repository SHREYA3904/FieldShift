"""Command line: python -m fieldshift.cli --lat 30.9 --lon 75.85 --current maize wheat"""
from __future__ import annotations

import argparse
import json

from . import service


def main():
    p = argparse.ArgumentParser(description="Field Shift: compare crop rotations for a location")
    p.add_argument("--lat", type=float, required=True)
    p.add_argument("--lon", type=float, required=True)
    p.add_argument("--soil", default="loam", choices=["loam", "clay", "sandy"])
    p.add_argument("--irrigation", type=float, default=0, help="mm per crop")
    p.add_argument("--current", nargs=2, metavar=("CROP1", "CROP2"))
    p.add_argument("--rain-pct", type=float, default=0)
    p.add_argument("--temp-c", type=float, default=0)
    p.add_argument("--offline", action="store_true", help="skip NASA, use a synthetic climate")
    p.add_argument("--json", action="store_true", help="print full JSON")
    a = p.parse_args()
    out = service.analyse(a.lat, a.lon, a.soil, a.irrigation, tuple(a.current) if a.current else None,
                          None, a.rain_pct, a.temp_c, offline=a.offline)
    if a.json:
        print(json.dumps(out, indent=2))
        return
    cl = out["climate"]
    print(f"Climate source: {cl['source']}  annual rain {cl['annual_rain_mm']:.0f} mm")
    for n in cl["notes"]:
        print("  note:", n)
    for s in out["strategies"]:
        c1, c2 = s["crops"]
        u = s["uncertainty"]
        beat = "" if u["p_beats_current"] is None else f", beats current in {u['p_beats_current']*100:.0f}% of runs"
        print(f"\n{s['label']}: {c1['name']} (sow {c1['sow_month']}) + {c2['name']} (sow {c2['sow_month']})")
        print(f"  score {s['scores']['overall']:.2f} [{u['overall_p10']:.2f}-{u['overall_p90']:.2f}]"
              f", irrigation need {s['scores']['irrigation_need_mm_per_year']:.0f} mm/yr{beat}")
        for r in s["risks_for_local_review"][:3]:
            print("  risk:", r)
    print("\n" + out["disclaimer"])


if __name__ == "__main__":
    main()
