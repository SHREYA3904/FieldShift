"""Layer 3, detection statistics. Pure functions on arrays: no network, no per-place constants."""
from __future__ import annotations

import numpy as np
from scipy import stats


def mann_kendall(x) -> dict:
    """Mann-Kendall trend test (tie-corrected) with Sen's slope per step. Needs n >= 8."""
    x = np.asarray(x, float)
    n = len(x)
    if n < 8:
        return {"n": n, "trend": "insufficient data", "p": None, "slope": None, "tau": None}
    s = sum(np.sign(x[j] - x[i]) for i in range(n - 1) for j in range(i + 1, n))
    _, counts = np.unique(x, return_counts=True)
    var = (n * (n - 1) * (2 * n + 5) - sum(t * (t - 1) * (2 * t + 5) for t in counts)) / 18.0
    z = 0.0 if s == 0 else (s - np.sign(s)) / np.sqrt(var)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    slopes = [(x[j] - x[i]) / (j - i) for i in range(n - 1) for j in range(i + 1, n)]
    tau = s / (0.5 * n * (n - 1))
    trend = "no significant trend" if p >= 0.1 else ("increasing" if z > 0 else "decreasing")
    return {"n": n, "trend": trend, "p": float(p), "z": float(z), "tau": float(tau), "slope": float(np.median(slopes))}


def pettitt(x) -> dict:
    """Pettitt change-point test. Returns the most likely break index (first index of the new regime)."""
    x = np.asarray(x, float)
    n = len(x)
    if n < 10:
        return {"n": n, "change_index": None, "p": None, "significant": False}
    r = stats.rankdata(x)
    u = np.array([2 * r[:k].sum() - k * (n + 1) for k in range(1, n)])
    k = int(np.argmax(np.abs(u)))
    kmax = abs(u[k])
    p = min(1.0, 2 * np.exp(-6 * kmax ** 2 / (n ** 3 + n ** 2)))
    return {"n": n, "change_index": k + 1, "p": float(p), "significant": bool(p < 0.05)}


def detect_shift(years, values, label: str, unit: str) -> dict:
    """Trend plus change-point on one annual series, with a plain-words verdict."""
    values = np.asarray(values, float)
    mk, pt = mann_kendall(values), pettitt(values)
    out = {"variable": label, "unit": unit, "mann_kendall": mk, "pettitt": pt}
    if mk["p"] is None:
        out["verdict"] = f"Too few years of {label.lower()} data to test for change."
        return out
    per_dec = mk["slope"] * 10
    if mk["p"] < 0.1:
        out["verdict"] = (f"{label} is {mk['trend']}: about {per_dec:+.2f} {unit} per decade "
                          f"(p = {mk['p']:.2f}, {mk['n']} years).")
    else:
        out["verdict"] = f"No significant change in {label.lower()} over {mk['n']} years (p = {mk['p']:.2f})."
    if pt["significant"]:
        out["change_year"] = int(years[pt["change_index"]])
        out["verdict"] += f" A step change is likely around {out['change_year']} (p = {pt['p']:.2f})."
    return out


def spi(monthly_rain, scale: int = 3) -> np.ndarray:
    """Standardised Precipitation Index on a monthly series (gamma fit per calendar month).
    Returns an array the same length as the input, NaN where the window is incomplete."""
    r = np.asarray(monthly_rain, float)
    n = len(r)
    acc = np.full(n, np.nan)
    for i in range(scale - 1, n):
        acc[i] = r[i - scale + 1:i + 1].sum()
    out = np.full(n, np.nan)
    months = np.arange(n) % 12
    for m in range(12):
        idx = np.where((months == m) & ~np.isnan(acc))[0]
        v = acc[idx]
        if len(v) < 10:
            continue
        q0 = np.mean(v <= 0)
        pos = v[v > 0]
        if len(pos) < 5:
            continue
        a, loc, sc = stats.gamma.fit(pos, floc=0)
        cdf = q0 + (1 - q0) * stats.gamma.cdf(v, a, loc=0, scale=sc)
        out[idx] = stats.norm.ppf(np.clip(cdf, 1e-4, 1 - 1e-4))
    return out


def max_consecutive_dry_days(daily_rain, thresh: float = 1.0) -> int:
    best = run = 0
    for v in np.asarray(daily_rain, float):
        run = run + 1 if v < thresh else 0
        best = max(best, run)
    return best


def monthly_from_daily(dates, rain=None, temp=None):
    """Aggregate daily arrays to (years, 12) monthly sums (rain) or means (temp). dates = numpy datetime64[D]."""
    d = np.asarray(dates, "datetime64[D]")
    yrs = d.astype("datetime64[Y]").astype(int) + 1970
    mons = d.astype("datetime64[M]").astype(int) % 12
    ys = np.unique(yrs)
    src = rain if rain is not None else temp
    out = np.full((len(ys), 12), np.nan)
    for yi, y in enumerate(ys):
        for m in range(12):
            sel = (yrs == y) & (mons == m)
            if sel.any():
                v = np.asarray(src, float)[sel]
                out[yi, m] = v.sum() if rain is not None else v.mean()
    return ys, out
