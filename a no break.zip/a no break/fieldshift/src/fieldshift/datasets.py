"""Honest catalogue of data sources: what is connected, at what resolution, and what is not."""
CATALOG = [
    ("power", "NASA POWER daily weather", "NASA (MERRA-2 / GEOS)", "Temperature, rain, solar radiation, soil wetness", "about 50 km grid", "none", "NASA POWER daily"),
    ("modis", "MODIS NDVI (MOD13Q1)", "NASA (via ORNL DAAC)", "Vegetation greenness every 16 days", "250 m pixel", "none", "MODIS NDVI"),
    ("soilgrids", "SoilGrids soil texture", "ISRIC (not NASA)", "Sand, clay, organic carbon", "250 m", "none", "SoilGrids"),
    ("elevation", "Elevation (Copernicus DEM via Open-Meteo)", "Open-Meteo (not SRTM)", "Point elevation only, no slope yet", "about 90 m", "none", "Open-Meteo elevation"),
    ("smap", "SMAP soil moisture", "NASA", "Surface and root-zone soil moisture", "9 km (L4)", "NASA Earthdata login", None),
    ("gpm", "GPM IMERG rainfall", "NASA", "Rainfall and extreme events", "about 10 km, 30 min", "NASA Earthdata login", None),
    ("ecostress", "ECOSTRESS", "NASA", "Land surface temperature, evapotranspiration", "70 m (irregular passes)", "NASA Earthdata login", None),
    ("landsat", "Landsat", "NASA / USGS", "Land cover and field-scale vegetation", "30 m", "Earthdata or USGS login", None),
    ("grace", "GRACE / GRACE-FO", "NASA / DLR", "Regional water-storage trends", "about 300 km", "NASA Earthdata login", None),
]


def build(analysis: dict) -> list[dict]:
    ok = (analysis.get("data_quality") or {}).get("sources", {})
    out = []
    for id_, name, agency, uses, res, access, key in CATALOG:
        if key is None:
            status, note = "not_connected", f"Not connected in this version. Needs {access}."
        elif key == "NASA POWER daily":
            status, note = ("live" if analysis.get("climate", {}).get("source") == "nasa_power" else "fallback"), "Retrieved live for this location."
        elif key == "Open-Meteo elevation":
            e = (analysis.get("data_quality") or {}).get("elevation_m")
            status, note = ("live" if e is not None else "unavailable"), ("Elevation %.0f m." % e if e is not None else "Lookup failed.")
        else:
            status = "live" if ok.get(key) else "unavailable"
            note = "Retrieved live for this location." if status == "live" else "Lookup failed or timed out; the app degraded honestly."
        out.append({"id": id_, "name": name, "agency": agency, "provides": uses, "resolution": res, "access": access, "status": status, "note": note})
    return out
