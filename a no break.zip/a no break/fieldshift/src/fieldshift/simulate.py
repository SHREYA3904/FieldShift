"""Layer 4, daily crop-water simulation (FAO-56 style single bucket). Pure functions, no network.

Everything physical is computed from daily weather. Crop parameters come from crop_params.json
and every one carries a source and a confidence tag. Results are comparisons, not yield forecasts.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

_PARAMS = Path(__file__).with_name("crop_params.json")


@dataclass(frozen=True)
class CropParams:
    id: str
    name: str
    family: str
    tbase: float
    tcap: float
    gdd_total: float
    kc_ini: float
    kc_mid: float
    kc_end: float
    root_m: float
    p_dep: float          # fraction of TAW usable before stress
    heat_crit: float      # daily Tmax (C) that damages the crop
    cold_crit: float      # daily Tmin (C) that damages the crop
    nfix: float
    residue: float        # 0..1 relative residue returned
    j_nfix: float
    j_erosion: float
    j_om: float
    j_forage: float
    j_market: float
    confidence: str
    sources: tuple


def load_params() -> dict[str, CropParams]:
    raw = json.loads(_PARAMS.read_text())
    out = {}
    for c in raw["crops"]:
        c = dict(c)
        c["sources"] = tuple(c.get("sources", []))
        out[c["id"]] = CropParams(**c)
    return out


def extraterrestrial_radiation(lat_deg: float, doy) -> np.ndarray:
    """Ra in MJ m-2 day-1 (FAO-56 eq. 21)."""
    doy = np.asarray(doy, float)
    phi = np.radians(lat_deg)
    dr = 1 + 0.033 * np.cos(2 * np.pi * doy / 365)
    delta = 0.409 * np.sin(2 * np.pi * doy / 365 - 1.39)
    ws = np.arccos(np.clip(-np.tan(phi) * np.tan(delta), -1, 1))
    return 24 * 60 / np.pi * 0.0820 * dr * (ws * np.sin(phi) * np.sin(delta) + np.cos(phi) * np.cos(delta) * np.sin(ws))


def hargreaves_et0(tmax, tmin, lat_deg, doy) -> np.ndarray:
    """Reference evapotranspiration (mm/day), Hargreaves-Samani."""
    tmax, tmin = np.asarray(tmax, float), np.asarray(tmin, float)
    tmean = (tmax + tmin) / 2
    ra = extraterrestrial_radiation(lat_deg, doy)
    return np.maximum(0.0, 0.0023 * 0.408 * ra * (tmean + 17.8) * np.sqrt(np.maximum(tmax - tmin, 0)))


def stage_kc(frac: float, p: CropParams) -> float:
    """Kc by fraction of seasonal GDD: initial 0-15%, development to 40%, mid to 80%, late to 100%."""
    if frac < 0.15:
        return p.kc_ini
    if frac < 0.40:
        return p.kc_ini + (p.kc_mid - p.kc_ini) * (frac - 0.15) / 0.25
    if frac < 0.80:
        return p.kc_mid
    return p.kc_mid + (p.kc_end - p.kc_mid) * min(1.0, (frac - 0.80) / 0.20)


def awc_from_texture(sand_pct: float, clay_pct: float) -> float:
    """Plant-available water, mm per metre of soil (simple texture class means, Saxton-Rawls scale)."""
    silt = max(0.0, 100 - sand_pct - clay_pct)
    return float(np.clip(60 + 1.1 * silt + 0.25 * clay_pct - 0.55 * sand_pct, 60, 220))


def simulate_season(tmax, tmin, rain, et0, doy_start_idx: int, p: CropParams, awc_mm_per_m: float,
                    irrigation_mm: float = 0.0, max_days: int = 300) -> dict | None:
    """Run one sowing. Arrays are continuous daily series, doy_start_idx the sowing index.
    Returns None if the crop cannot finish before the data ends."""
    n = len(tmax)
    taw = awc_mm_per_m * p.root_m
    raw = p.p_dep * taw
    dep = 0.3 * taw                       # start moderately wet
    gdd = 0.0
    irr_left = irrigation_mm
    etc_sum = eta_sum = irr_used = drain = 0.0
    heat = cold = 0
    cover = []
    i = doy_start_idx
    while i < n and i - doy_start_idx < max_days:
        t_mean = (min(tmax[i], p.tcap) + max(tmin[i], p.tbase)) / 2
        gdd += max(0.0, t_mean - p.tbase)
        frac = gdd / p.gdd_total
        kc = stage_kc(min(frac, 1.0), p)
        etc = kc * et0[i]
        ks = 1.0 if dep <= raw else max(0.0, (taw - dep) / (taw - raw))
        if ks < 1.0 and irr_left > 0:     # irrigate when stress would start, refill to field capacity
            apply = min(irr_left, dep)
            irr_left -= apply
            irr_used += apply
            dep -= apply
            ks = 1.0 if dep <= raw else max(0.0, (taw - dep) / (taw - raw))
        eta = ks * etc
        dep = dep - rain[i] + eta
        if dep < 0:
            drain += -dep
            dep = 0.0
        dep = min(dep, taw)
        etc_sum += etc
        eta_sum += eta
        if 0.4 <= frac < 0.8:
            heat += int(tmax[i] > p.heat_crit)
        cold += int(tmin[i] < p.cold_crit)
        cover.append(min(1.0, kc / max(p.kc_mid, 1e-6)))
        i += 1
        if frac >= 1.0:
            return {"days": i - doy_start_idx, "water_stress": float(1 - eta_sum / etc_sum) if etc_sum > 0 else 0.0,
                    "etc_mm": etc_sum, "eta_mm": eta_sum, "irrigation_used_mm": irr_used, "drainage_mm": drain,
                    "heat_days": heat, "cold_days": cold, "mean_cover": float(np.mean(cover))}
    return None


def season_distribution(dates, tmax, tmin, rain, lat_deg, p: CropParams, awc_mm_per_m: float,
                        sow_month: int, irrigation_mm: float = 0.0, sow_day: int = 15) -> dict:
    """Run the same sowing date in every historical year; return the distribution of outcomes."""
    d = np.asarray(dates, "datetime64[D]")
    doy = (d - d.astype("datetime64[Y]")).astype(int) + 1
    et0 = hargreaves_et0(tmax, tmin, lat_deg, doy).tolist()
    tmax, tmin, rain = (np.asarray(a, float).tolist() for a in (tmax, tmin, rain))
    years = np.unique(d.astype("datetime64[Y]").astype(int) + 1970)
    runs = []
    for y in years:
        target = np.datetime64(f"{y}-{sow_month:02d}-{sow_day:02d}")
        idx = np.searchsorted(d, target)
        if idx >= len(d) or d[idx] != target:
            continue
        r = simulate_season(tmax, tmin, rain, et0, idx, p, awc_mm_per_m, irrigation_mm)
        if r:
            r["year"] = int(y)
            runs.append(r)
    if not runs:
        return {"n_years": 0, "crop": p.id, "sow_month": sow_month}
    ws = np.array([r["water_stress"] for r in runs])
    heat = np.array([r["heat_days"] for r in runs])
    return {"crop": p.id, "sow_month": sow_month, "n_years": len(runs),
            "water_stress_p10": float(np.percentile(ws, 10)), "water_stress_p50": float(np.percentile(ws, 50)),
            "water_stress_p90": float(np.percentile(ws, 90)),
            "p_bad_season": float(np.mean(ws > 0.25)),
            "heat_days_p50": float(np.median(heat)), "p_heat_damage": float(np.mean(heat >= 3)),
            "p_cold_damage": float(np.mean([r["cold_days"] >= 2 for r in runs])),
            "season_days_p50": float(np.median([r["days"] for r in runs])),
            "irrigation_need_mm_p50": float(np.median([r["etc_mm"] - r["eta_mm"] - 0 for r in runs]) if irrigation_mm == 0
                                            else np.median([r["irrigation_used_mm"] for r in runs])),
            "mean_cover": float(np.mean([r["mean_cover"] for r in runs])), "runs": runs}


def erosion_index(daily_rain, cover_by_day, k_factor: float) -> float:
    """Relative erosion index = sum over days of rainfall erosivity x cover factor x erodibility.
    Erosivity per day from a Richardson-type power law; cover factor C = 1 - 0.9 * cover (bare = 1)."""
    r = np.asarray(daily_rain, float)
    cover = np.asarray(cover_by_day, float)
    erosivity = 0.0483 * np.where(r > 12.7, r, 0.0) ** 1.61
    c = 1 - 0.9 * np.clip(cover, 0, 1)
    return float(np.sum(erosivity * c) * k_factor / max(1, len(r)) * 365)


def k_factor_from_texture(sand_pct: float, clay_pct: float) -> float:
    """Relative soil erodibility 0.1 to 0.6 from texture (silty soils erode most)."""
    silt = max(0.0, 100 - sand_pct - clay_pct)
    return float(np.clip(0.12 + 0.004 * silt + 0.001 * sand_pct - 0.002 * clay_pct, 0.08, 0.6))
