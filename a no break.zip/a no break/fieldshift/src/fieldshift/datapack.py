"""Regional data pack: the supplied Diamond Valley / Eureka County (Nevada) files, loaded and checked.

Nothing here is invented. Every function reads the files in data/ and says what it could and could not use.
The pack is regional: it only applies to fields near Diamond Valley (see in_region); everywhere else the app keeps using live global sources.
"""
from __future__ import annotations

import csv
import json
import math
import re
from functools import lru_cache
from pathlib import Path

import numpy as np

DIR = Path(__file__).with_name("data")
CENTRE = (39.7591, -115.9734)        # USGS GNIS "Diamond Valley" basin
RADIUS_KM = 100.0
REGION_NAME = "Diamond Valley, Eureka County, Nevada"
F = {"power_daily": "nasa_power_daily_2015_2025.csv", "power_clim": "nasa_power_climatology_2001_2025.csv",
     "ssurgo": "usda_nrcs_ssurgo_diamond_valley_surface_horizons.csv", "ssurgo_demo": "usda_nrcs_ssurgo_demo_point_soil.csv",
     "cdl": "usda_nass_cdl_eureka_county_2015_2025.csv", "ecocrop": "fao_ecocrop_candidate_crop_characteristics.csv",
     "nex": "nasa_nexgddp_cmip6_ensemble_monthly_2015_2100.csv", "priorities": "farmer_priorities_template.csv"}
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# names a farmer might type -> crop id used by the simulator
ALIASES = {"wheat": ["wheat", "gehu", "gehun", "gom"], "barley": ["barley", "jau"], "maize": ["maize", "corn", "makka", "bhutta"],
           "rice": ["rice", "paddy", "dhan", "chawal"], "sorghum": ["sorghum", "jowar", "milo"], "soybean": ["soybean", "soyabean", "soy"],
           "groundnut": ["groundnut", "peanut", "moongfali"], "chickpea": ["chickpea", "chana", "gram"], "pea": ["pea", "peas", "field pea", "matar"],
           "cover_legume": ["cover crop", "cover legume", "green manure"], "mustard": ["mustard", "sarson"], "sunflower": ["sunflower"],
           "cotton": ["cotton", "kapas"], "potato": ["potato", "potatoes", "aloo", "alu"], "alfalfa": ["alfalfa", "lucerne"], "oats": ["oats", "oat", "jai"],
           "rye": ["rye"], "lentil": ["lentil", "lentils", "masoor"], "canola": ["canola", "rapeseed", "rape"], "red_clover": ["red clover", "clover"],
           "sainfoin": ["sainfoin"], "proso_millet": ["proso millet", "proso", "broomcorn millet"], "foxtail_millet": ["foxtail millet", "foxtail", "kangni"],
           "vetch": ["vetch", "common vetch"]}
ECO_ID = {"Alfalfa": "alfalfa", "Barley": "barley", "Wheat": "wheat", "Oats": "oats", "Rye": "rye", "Field pea": "pea", "Chickpea": "chickpea",
          "Lentil": "lentil", "Canola / rapeseed": "canola", "Red clover": "red_clover", "Sainfoin": "sainfoin", "Proso millet": "proso_millet",
          "Foxtail millet": "foxtail_millet", "Corn": "maize", "Sorghum": "sorghum", "Common vetch": "vetch"}
CDL_ID = {"Alfalfa": "alfalfa", "Barley": "barley", "Spring Wheat": "wheat", "Winter Wheat": "wheat", "Oats": "oats", "Rye": "rye", "Corn": "maize",
          "Potatoes": "potato", "Sorghum": "sorghum", "Sunflower": "sunflower", "Soybeans": "soybean"}
NONCROP_PREFIX = ("Developed", "Open Water", "Perennial Ice", "Barren", "Deciduous", "Evergreen", "Mixed Forest", "Shrubland", "Grass/Pasture",
                  "Woody Wetlands", "Herbaceous Wetlands", "Fallow")


def _num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else float("nan")
    except (TypeError, ValueError):
        return float("nan")


@lru_cache(maxsize=None)
def _rows(key: str) -> tuple:
    with (DIR / F[key]).open(newline="", encoding="utf-8") as f:
        return tuple(csv.DictReader(f))


def _hav(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(h))


def region(lat: float, lon: float) -> dict:
    d = _hav((lat, lon), CENTRE)
    return {"in_region": d <= RADIUS_KM, "distance_km": round(d, 1), "name": REGION_NAME, "radius_km": RADIUS_KM,
            "note": ("The supplied regional files (SSURGO soil, CDL crops, bundled weather and climate projections) apply to this field." if d <= RADIUS_KM else
                     f"This field is {d:.0f} km from {REGION_NAME}. The regional files do not cover it, so the app uses live global sources only.")}


# ------------------------------------------------------------------ NASA POWER (supplied daily + climatology)
@lru_cache(maxsize=1)
def _nex_dtr() -> np.ndarray:
    """Mean monthly diurnal temperature range (Tmax - Tmin) from the CMIP6 file, 2015-2025, three scenarios."""
    rows = [r for r in _rows("nex") if "2015" <= r["month"][:4] <= "2025"]
    out = []
    for m in range(1, 13):
        v = [_num(r["T2M_MAX_C"]) - _num(r["T2M_MIN_C"]) for r in rows if int(r["month"][5:7]) == m]
        out.append(float(np.nanmean(v)))
    return np.array(out)


@lru_cache(maxsize=1)
def power_daily() -> dict:
    """Supplied daily NASA POWER, 2015-2025. It has mean temperature only (no T2M_MAX / T2M_MIN), so Tmax and Tmin are ESTIMATED as
    T2M +/- half the model diurnal range for that month. The result is flagged so the pipeline can say so."""
    rows = _rows("power_daily")
    dates = np.array([r["date"] for r in rows], "datetime64[D]")
    col = lambda k: np.array([_num(r[k]) for r in rows], float)   # noqa: E731
    t = col("T2M_C")
    mon = dates.astype("datetime64[M]").astype(int) % 12
    half = _nex_dtr()[mon] / 2
    return {"dates": dates, "T2M_MAX": t + half, "T2M_MIN": t - half, "PRECTOTCORR": col("PRECTOTCORR_mm_per_day"), "ALLSKY_SFC_SW_DWN": col("ALLSKY_SFC_SW_DWN_MJ_per_m2_per_day"),
            "RH2M": col("RH2M_percent"), "WS2M": col("WS2M_m_per_s"), "GWETROOT": col("GWETROOT_fraction"), "T2M": t,
            "_estimated_tmax_tmin": True}


def climatology() -> dict:
    rows = [r for r in _rows("power_clim") if r["month"] != "ANN"]
    ann = next(r for r in _rows("power_clim") if r["month"] == "ANN")
    return {"months": MONTHS, "t2m_c": [_num(r["T2M_C"]) for r in rows], "rain_mm_per_day": [_num(r["PRECTOTCORR_mm_per_day"]) for r in rows],
            "rain_mm_month": [round(_num(r["PRECTOTCORR_mm_per_day"]) * d, 1) for r, d in zip(rows, [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])],
            "gwetroot": [_num(r["GWETROOT_fraction"]) for r in rows], "solar_mj": [_num(r["ALLSKY_SFC_SW_DWN_MJ_per_m2_per_day"]) for r in rows],
            "annual_t_c": _num(ann["T2M_C"]), "annual_rain_mm": round(_num(ann["PRECTOTCORR_mm_per_day"]) * 365.25, 0), "period": "2001-2025"}


def daily_vs_climatology() -> dict:
    """Is the supplied 2015-2025 daily record typical of the 2001-2025 climatology? (It is a different, shorter period.)"""
    d = power_daily()
    mon = d["dates"].astype("datetime64[M]").astype(int) % 12
    c = climatology()
    t = [float(np.nanmean(d["T2M"][mon == m])) for m in range(12)]
    r = [float(np.nanmean(d["PRECTOTCORR"][mon == m])) for m in range(12)]
    wet = float(np.mean(d["PRECTOTCORR"]) / np.mean(c["rain_mm_per_day"]) - 1)
    return {"temp_diff_c_by_month": [round(a - b, 2) for a, b in zip(t, c["t2m_c"])], "rain_ratio_by_month": [round(a / b, 2) if b else None for a, b in zip(r, c["rain_mm_per_day"])],
            "annual_rain_diff_pct": round(100 * wet, 1), "annual_temp_diff_c": round(float(np.nanmean(d["T2M"]) - c["annual_t_c"]), 2),
            "note": f"The supplied 2015-2025 daily record is {abs(100*wet):.0f}% {'wetter' if wet > 0 else 'drier'} than the 2001-2025 climatology, so the two files describe slightly different periods."}


def crosscheck_live(raw: dict) -> dict | None:
    """Compare a live NASA POWER fetch with the supplied daily file over the same days. Only meaningful near Diamond Valley."""
    p = power_daily()
    d = np.asarray(raw["dates"], "datetime64[D]")
    common, i, j = np.intersect1d(d, p["dates"], return_indices=True)
    if len(common) < 365:
        return None
    live_t = (raw["T2M_MAX"][i] + raw["T2M_MIN"][i]) / 2
    ok = ~np.isnan(live_t) & ~np.isnan(p["T2M"][j])
    okr = ~np.isnan(raw["PRECTOTCORR"][i]) & ~np.isnan(p["PRECTOTCORR"][j])
    if ok.sum() < 300:
        return None
    r_t = float(np.corrcoef(live_t[ok], p["T2M"][j][ok])[0, 1])
    r_r = float(np.corrcoef(raw["PRECTOTCORR"][i][okr], p["PRECTOTCORR"][j][okr])[0, 1])
    return {"days_compared": int(len(common)), "temp_correlation": round(r_t, 3), "temp_mean_difference_c": round(float(np.mean(live_t[ok] - p["T2M"][j][ok])), 2),
            "rain_correlation": round(r_r, 3), "rain_mean_difference_mm_per_day": round(float(np.mean(raw["PRECTOTCORR"][i][okr] - p["PRECTOTCORR"][j][okr])), 3),
            "agrees": bool(r_t > 0.97 and r_r > 0.9),
            "meaning": "The live NASA POWER download matches the file you supplied for the same days." if r_t > 0.97 and r_r > 0.9 else
                       "The live download differs from the supplied file (different grid cell, version or location). Check which one you mean to use."}


# ------------------------------------------------------------------ SSURGO soils
def _horizon(r: dict) -> dict:
    return {"top": _num(r["horizon_top_depth_cm"]), "bottom": _num(r["horizon_bottom_depth_cm"]), "om": _num(r["organic_matter_percent"]), "ph": _num(r["ph_water_1_to_1"]),
            "sand": _num(r["sand_percent"]), "silt": _num(r["silt_percent"]), "clay": _num(r["clay_percent"]), "awc": _num(r["available_water_capacity_in_per_in"])}


def mapunits() -> list[dict]:
    out: dict = {}
    for r in _rows("ssurgo"):
        mu = out.setdefault(r["mukey"], {"mukey": r["mukey"], "musym": r["musym"], "name": r["mapunit_name"], "components": {}})
        c = mu["components"].setdefault(r["cokey"], {"name": r["component_name"], "pct": _num(r["component_percent_of_mapunit"]), "drainage": r["drainage_class"] or None,
                                                     "hsg": r["hydrologic_soil_group"] or None, "taxonomy": r["taxonomic_class"] or None, "horizons": []})
        c["horizons"].append(_horizon(r))
    res = []
    for mu in out.values():
        mu["components"] = list(mu["components"].values())
        res.append(mu)
    return res


def demo_point() -> dict:
    r = _rows("ssurgo_demo")[0]
    return {"mukey": r["mukey"], "musym": r["musym"], "name": r["mapunit_name"], "components": [{"name": r["component_name"], "pct": _num(r["component_percent_of_mapunit"]),
            "drainage": r["drainage_class"] or None, "hsg": r["hydrologic_soil_group"] or None, "taxonomy": r["taxonomic_class"] or None, "horizons": [_horizon(r)]}]}


def soil_profile(key: str, top: float = 0.0, bottom: float = 30.0) -> dict | None:
    """Component- and thickness-weighted soil properties over top..bottom cm for a map unit ('demo' = the supplied demo-point row)."""
    mu = demo_point() if key == "demo" else next((m for m in mapunits() if m["mukey"] == str(key)), None)
    if mu is None:
        return None
    acc = {p: [0.0, 0.0] for p in ("om", "ph", "sand", "silt", "clay", "awc")}
    wtot = 0.0
    used, skipped = [], []
    drain, hsg = {}, {}
    for c in mu["components"]:
        cw = 0.0
        for h in c["horizons"]:
            ov = max(0.0, min(h["bottom"], bottom) - max(h["top"], top)) if not math.isnan(h["bottom"]) else 0.0
            if ov <= 0:
                continue
            w = (c["pct"] if not math.isnan(c["pct"]) else 0.0) * ov
            cw += w
            for p in acc:
                if not math.isnan(h[p]):
                    acc[p][0] += w * h[p]
                    acc[p][1] += w
        wtot += cw
        (used if cw and any(not math.isnan(h["sand"]) for h in c["horizons"]) else skipped).append(c["name"])
        if c["drainage"]:
            drain[c["drainage"]] = drain.get(c["drainage"], 0) + c["pct"]
        if c["hsg"]:
            hsg[c["hsg"]] = hsg.get(c["hsg"], 0) + c["pct"]
    val = {p: (acc[p][0] / acc[p][1] if acc[p][1] else None) for p in acc}
    if val["sand"] is None or val["clay"] is None:
        return {"mukey": mu["mukey"], "name": mu["name"], "usable": False, "reason": "No soil texture recorded for this map unit (for example rock outcrop or a missing horizon).", "components_without_data": skipped}
    cov = acc["sand"][1] / wtot if wtot else 0.0
    awc = val["awc"]
    return {"mukey": mu["mukey"], "musym": mu["musym"], "name": mu["name"], "usable": True, "depth_cm": [top, bottom],
            "sand_pct": round(val["sand"], 1), "silt_pct": round(val["silt"], 1) if val["silt"] is not None else round(100 - val["sand"] - val["clay"], 1), "clay_pct": round(val["clay"], 1),
            "organic_matter_pct": None if val["om"] is None else round(val["om"], 2), "ph": None if val["ph"] is None else round(val["ph"], 2),
            "awc_mm_per_m": None if awc is None else round(awc * 1000, 0),            # inch per inch == mm per mm
            "drainage_class": max(drain, key=drain.get) if drain else None, "hydrologic_group": max(hsg, key=hsg.get) if hsg else None,
            "components_used": used, "components_without_data": skipped, "data_coverage": round(cov, 2), "source": "USDA NRCS SSURGO (supplied file)",
            "note": "Weights: component share x horizon thickness inside " + f"{top:.0f}-{bottom:.0f} cm. SSURGO gives map-unit averages, not your exact field."}


def texture_class(sand: float, clay: float) -> str:
    return "heavy" if clay >= 35 else ("light" if sand >= 70 else "medium")


def drainage_eco(d: str | None) -> str | None:
    if not d:
        return None
    s = d.lower()
    if "excessively" in s:
        return "excessive"
    if "poorly" in s or "very poorly" in s:
        return "poorly"
    return "well"


# ------------------------------------------------------------------ CDL (what is actually grown in the county)
@lru_cache(maxsize=1)
def cdl() -> dict:
    rows = _rows("cdl")
    years = sorted({int(r["year"]) for r in rows})
    by: dict = {}
    for r in rows:
        by.setdefault(r["cdl_category"], {})[int(r["year"])] = _num(r["acreage_acres"])
    crops, crop_year = [], {y: 0.0 for y in years}
    fallow = {y: by.get("Fallow/Idle Cropland", {}).get(y, 0.0) for y in years}
    for cat, ser in by.items():
        if cat.startswith(NONCROP_PREFIX):
            continue
        for y, a in ser.items():
            crop_year[y] += a
    last5 = years[-5:]
    for cat, ser in by.items():
        if cat.startswith(NONCROP_PREFIX):
            continue
        a5 = float(np.mean([ser.get(y, 0.0) for y in last5]))
        share = a5 / max(float(np.mean([crop_year[y] for y in last5])), 1.0)
        hist = [y for y in years if y <= 2024]
        xs, ys = np.array(hist, float), np.array([ser.get(y, 0.0) for y in hist])
        slope = float(np.polyfit(xs, ys, 1)[0]) if ys.sum() > 0 else 0.0
        crops.append({"category": cat, "crop_id": CDL_ID.get(cat), "acres_by_year": {str(y): ser.get(y, 0.0) for y in years}, "latest_acres": ser.get(years[-1], 0.0),
                      "mean_5y_acres": round(a5, 1), "share_of_cropland_5y": round(share, 4), "trend_acres_per_year_2015_2024": round(slope, 0),
                      "reliable": bool(sum(1 for y in last5 if ser.get(y, 0.0) >= 50) >= 3)})
    crops.sort(key=lambda c: -c["mean_5y_acres"])
    noncrop_jump = {c: round(by[c].get(2025, 0) / max(by[c].get(2024, 1), 1), 1) for c in ("Developed/Low Intensity", "Barren", "Deciduous Forest", "Herbaceous Wetlands") if c in by}
    return {"county": "Eureka County, Nevada (FIPS 32011)", "years": years, "crops": crops, "cropland_acres_by_year": {str(y): round(v, 1) for y, v in crop_year.items()},
            "fallow_acres_by_year": {str(y): round(v, 1) for y, v in fallow.items()}, "source": "USDA NASS Cropland Data Layer (supplied file)",
            "notes": ["CDL is a satellite classification with its own errors. Classes under about 50 acres (for example 1 acre of corn) are treated as classification noise, not real crops.",
                      "CDL covers the whole county, not one field. It shows what is grown nearby, not what will sell or yield well.",
                      f"The 2025 column shows large jumps in non-crop classes versus 2024 (for example Developed/Low Intensity x{noncrop_jump.get('Developed/Low Intensity', '?')}), which suggests a change in the CDL method; crop trends here use 2015-2024."]}


def local_presence(crop_id: str) -> dict:
    c = cdl()
    cats = [x for x in c["crops"] if x["crop_id"] == crop_id]
    share = sum(x["share_of_cropland_5y"] for x in cats)
    reliable = any(x["reliable"] for x in cats)
    return {"share_of_cropland": round(share, 4), "acres_5y_mean": round(sum(x["mean_5y_acres"] for x in cats), 0), "reliable": reliable}


# ------------------------------------------------------------------ FAO EcoCrop
@lru_cache(maxsize=1)
def ecocrop() -> dict:
    out = {}
    for r in _rows("ecocrop"):
        cid = ECO_ID.get(r["common_name"])
        if not cid:
            continue
        g = lambda k: _num(r[k])   # noqa: E731
        out[cid] = {"crop_id": cid, "common_name": r["common_name"], "scientific_name": r["scientific_name"], "life_span": r["life_span"] or None, "category": r["category"] or None,
                    "t_abs": [g("absolute_temperature_min_C"), g("absolute_temperature_max_C")], "t_opt": [g("optimal_temperature_min_C"), g("optimal_temperature_max_C")],
                    "rain_abs": [g("absolute_annual_rainfall_min_mm"), g("absolute_annual_rainfall_max_mm")], "rain_opt": [g("optimal_annual_rainfall_min_mm"), g("optimal_annual_rainfall_max_mm")],
                    "ph_abs": [g("absolute_soil_pH_min"), g("absolute_soil_pH_max")], "ph_opt": [g("optimal_soil_pH_min"), g("optimal_soil_pH_max")],
                    "texture_opt": [x.strip() for x in (r["optimal_soil_texture"] or "").split(",") if x.strip()], "texture_abs": [x.strip() for x in (r["absolute_soil_texture"] or "").split(",") if x.strip()],
                    "drainage_opt": r["optimal_soil_drainage"] or None, "drainage_abs": r["absolute_soil_drainage"] or None,
                    "cycle_days": [g("crop_cycle_min_days"), g("crop_cycle_max_days")], "url": r["fao_profile_url"]}
    return out


# ------------------------------------------------------------------ NEX-GDDP-CMIP6 projections
PERIODS = {"2021-2040": (2021, 2040), "2041-2060": (2041, 2060), "2061-2080": (2061, 2080), "2081-2100": (2081, 2100)}
SCENARIOS = {"ssp126": "SSP1-2.6 (low emissions)", "ssp245": "SSP2-4.5 (middle road)", "ssp370": "SSP3-7.0 (high emissions)"}
W_TO_MJ = 0.0864


@lru_cache(maxsize=1)
def _nex() -> dict:
    d: dict = {}
    for r in _rows("nex"):
        y, m = int(r["month"][:4]), int(r["month"][5:7])
        d.setdefault(r["scenario"], {})[(y, m)] = {"t": _num(r["T2M_C"]), "tmax": _num(r["T2M_MAX_C"]), "tmin": _num(r["T2M_MIN_C"]), "p": _num(r["PRECTOTCORR_mm_per_day"]),
                                                  "sw": _num(r["ALLSKY_SFC_SW_DWN_MJ_per_m2_per_day"]) * W_TO_MJ}
    return d


def _mean_by_month(s: dict, y0: int, y1: int, key: str) -> np.ndarray:
    return np.array([np.nanmean([s[(y, m)][key] for y in range(y0, y1 + 1) if (y, m) in s]) for m in range(1, 13)])


def projection(scenario: str, period: str) -> dict | None:
    """Delta-change projection for one scenario and 20-year period, relative to the SAME model's 2015-2025 mean.
    Using the model's own baseline removes its bias, so we only trust the CHANGE, which is then added to the observed record."""
    if scenario not in SCENARIOS or period not in PERIODS:
        return None
    s = _nex()[scenario]
    y0, y1 = PERIODS[period]
    base = {k: _mean_by_month(s, 2015, 2025, k) for k in ("t", "tmax", "tmin", "p", "sw")}
    fut = {k: _mean_by_month(s, y0, y1, k) for k in base}
    dt, dmax, dmin = fut["t"] - base["t"], fut["tmax"] - base["tmax"], fut["tmin"] - base["tmin"]
    pr = np.where(base["p"] > 0.01, fut["p"] / base["p"], 1.0)
    swr = np.where(base["sw"] > 0, fut["sw"] / base["sw"], 1.0)
    days = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
    return {"scenario": scenario, "scenario_name": SCENARIOS[scenario], "period": period, "baseline": "2015-2025 of the same model ensemble",
            "delta_t_c": [round(float(x), 2) for x in dt], "delta_tmax_c": [round(float(x), 2) for x in dmax], "delta_tmin_c": [round(float(x), 2) for x in dmin],
            "rain_ratio": [round(float(x), 3) for x in pr], "solar_ratio": [round(float(x), 3) for x in swr],
            "annual_delta_t_c": round(float(np.mean(dt)), 2), "annual_rain_change_pct": round(float((np.sum(fut["p"] * days) / np.sum(base["p"] * days) - 1) * 100), 1),
            "summer_delta_t_c": round(float(np.mean(dt[5:8])), 2), "model_annual_t_c": [round(float(np.mean(base["t"])), 2), round(float(np.mean(fut["t"])), 2)],
            "months": MONTHS}


def projection_summary() -> dict:
    out = {sc: {pe: {k: v for k, v in projection(sc, pe).items() if k in ("annual_delta_t_c", "annual_rain_change_pct", "summer_delta_t_c")} for pe in PERIODS} for sc in SCENARIOS}
    return {"scenarios": SCENARIOS, "periods": list(PERIODS), "table": out, "method": "Delta-change: the change between the model's 2015-2025 and the future period is added to the observed daily record (temperature) or multiplied onto it (rain), month by month.",
            "caveats": ["The projection file is for the Diamond Valley point only.", "It is an ensemble mean of CMIP6 models, so it hides model disagreement. Treat the numbers as one central estimate, not a forecast.",
                        "Monthly means are shifted; day-to-day variability is kept from the observed record. Changes in extremes are not modelled separately.",
                        "In the supplied file the solar column is labelled MJ/m2/day but holds W/m2 values (about 100 to 370). It was converted (x0.0864) before use."]}


# ------------------------------------------------------------------ dataset sources + files
def sources() -> list[dict]:
    return json.loads((DIR / "dataset_sources.json").read_text())


def file_inventory() -> list[dict]:
    """What each supplied file is, how much of it there is, and what it was used for. Counts are read from the files themselves."""
    d, nx = power_daily(), _nex()
    return [
        {"file": F["power_daily"], "dataset": "NASA POWER daily", "rows": len(d["dates"]), "coverage": f"{d['dates'][0]} to {d['dates'][-1]}",
         "used_for": "Offline weather for Diamond Valley fields when the live download fails; cross-check against the live download.",
         "caveat": "Mean temperature only (no Tmax/Tmin), so daily Tmax and Tmin are estimated from the model diurnal range. Only 11 years."},
        {"file": F["power_clim"], "dataset": "NASA POWER climatology", "rows": len(_rows("power_clim")), "coverage": "2001-2025 monthly means", "used_for": "Reference climate; checks whether 2015-2025 is typical.", "caveat": "Different period than the daily file."},
        {"file": F["ssurgo"], "dataset": "USDA NRCS SSURGO horizons", "rows": len(_rows("ssurgo")), "coverage": f"{len(mapunits())} map units, Diamond Valley", "used_for": "Choose a SSURGO map unit as a field's soil: texture, organic matter, pH, water capacity, drainage.", "caveat": "No map geometry, so the app cannot place a field on a map unit by itself. You pick the unit. Surface horizons only."},
        {"file": F["ssurgo_demo"], "dataset": "USDA NRCS SSURGO demo point", "rows": len(_rows("ssurgo_demo")), "coverage": demo_point()["name"], "used_for": "Soil of the Diamond Valley demonstration field.", "caveat": "One map unit, one horizon (0-38 cm)."},
        {"file": F["cdl"], "dataset": "USDA NASS Cropland Data Layer, Eureka County", "rows": len(_rows("cdl")), "coverage": "2015-2025 acres by class", "used_for": "What is actually grown nearby: local crop presence feeds the market score for Diamond Valley fields.", "caveat": "Acreage only, no yield or price; 2025 non-crop classes look inconsistent."},
        {"file": F["ecocrop"], "dataset": "FAO EcoCrop candidate crops", "rows": len(_rows("ecocrop")), "coverage": "16 candidate crops", "used_for": "Crop list; temperature, rainfall, pH, texture and drainage suitability for any location.", "caveat": "Broad species envelopes, not variety or yield data."},
        {"file": F["nex"], "dataset": "NASA NEX-GDDP-CMIP6 ensemble", "rows": len(_rows("nex")), "coverage": f"{len(nx)} scenarios, 2015-2100 monthly", "used_for": "Future climate: delta-change projections for the Climate Simulator.", "caveat": "Diamond Valley point only. Solar column holds W/m2 though labelled MJ/m2/day."},
        {"file": F["priorities"], "dataset": "Farmer priorities template", "rows": len(_rows("priorities")), "coverage": "12 priorities or constraints", "used_for": "Import and export of priorities in the Rotation Lab.", "caveat": "Only some rows can change the scoring; the rest are stored and shown as not modelled."},
    ]


# ------------------------------------------------------------------ farmer priorities CSV
PRI_MAP = {"reduce irrigation demand": "water", "improve soil organic matter": "om", "reduce erosion/runoff risk": "erosion", "maintain or improve net return": "market", "reduce yield variability": "stability"}
PRI_LABEL = {"water": "Save water", "om": "Organic matter", "erosion": "Protect soil", "market": "Market / return", "stability": "Stable yields"}


def priorities_template() -> str:
    return (DIR / F["priorities"]).read_text(encoding="utf-8")


def crops_in(text: str) -> list[str]:
    t = " " + re.sub(r"[^a-z0-9 ]+", " ", (text or "").lower()) + " "
    out = []
    for cid, words in ALIASES.items():
        if any(f" {w} " in t for w in words) and cid not in out:
            out.append(cid)
    return out


def parse_priorities(text: str) -> dict:
    """Read the filled-in priorities template. Returns what was applied to the scoring and what was only recorded."""
    rows = list(csv.DictReader(text.strip().splitlines()))
    need = {"priority_or_constraint", "weight_1_to_5", "target_or_limit", "unit", "notes"}
    if not rows and not text.strip():
        return {"ok": False, "error": "The file is empty."}
    if not rows or not need <= set(rows[0].keys()):
        return {"ok": False, "error": "This does not look like the priorities template. Expected the columns: " + ", ".join(sorted(need)) + "."}
    pri, cons, applied, not_modelled, warnings = {}, {}, [], [], []
    for r in rows:
        key = (r["priority_or_constraint"] or "").strip().lower()
        w, tv, unit, notes = (r["weight_1_to_5"] or "").strip(), (r["target_or_limit"] or "").strip(), (r["unit"] or "").strip(), (r["notes"] or "").strip()
        if not key or not (w or tv or notes):
            continue
        wf = _num(w) if w else float("nan")
        if w and math.isnan(wf):
            warnings.append(f"'{r['priority_or_constraint']}': weight '{w}' is not a number, ignored.")
        elif not math.isnan(wf) and not 1 <= wf <= 5:
            warnings.append(f"'{r['priority_or_constraint']}': weight {wf:g} is outside 1 to 5 and was clipped.")
            wf = min(5.0, max(1.0, wf))
        if key in PRI_MAP:
            if not math.isnan(wf):
                pri[PRI_MAP[key]] = wf
                applied.append({"row": r["priority_or_constraint"], "effect": f"{PRI_LABEL[PRI_MAP[key]]} weight set to {wf:g}"
                                + (" (no price data is connected, so this uses local crop presence and judgement scores as a proxy, not prices or returns)" if key == "maintain or improve net return" else "")})
            if key == "maintain or improve net return" and tv:
                cons["net_return_target_usd_ha"] = _num(tv)
                not_modelled.append({"row": r["priority_or_constraint"], "why": f"Target {tv} {unit or 'USD/ha'} recorded, but there are no yield or price data to compute returns."})
        elif key == "maximum irrigation allocation":
            v = _num(tv)
            if math.isnan(v) or v <= 0:
                if tv:
                    warnings.append(f"'{r['priority_or_constraint']}': '{tv}' is not a positive number.")
                continue
            mm = v / 10.0                              # 1 mm of water over 1 ha = 10 m3
            cons["max_irrigation_mm"] = round(mm, 1)
            applied.append({"row": r["priority_or_constraint"], "effect": f"Irrigation capped at {v:g} m3/ha/year = {mm:g} mm"})
        elif key == "crops with reliable local market":
            ids = crops_in(tv + " " + notes)
            miss = [x for x in re.split(r"[,;/]+", tv) if x.strip() and not crops_in(x)]
            if ids:
                cons["market_crops"] = ids
                applied.append({"row": r["priority_or_constraint"], "effect": "Market score raised to the maximum for: " + ", ".join(ids)})
            if miss:
                warnings.append("Crops not recognised: " + ", ".join(m.strip() for m in miss) + ". Use names from the crop list.")
        elif key == "acceptable rotation length":
            cons["rotation_years"] = _num(tv)
            not_modelled.append({"row": r["priority_or_constraint"], "why": "The model compares two-crop sequences within one year. Multi-year rotation length is recorded, not optimised."})
        elif key == "current crop and last 5 years of field history":
            hist = []
            for m in re.finditer(r"([A-Za-z][A-Za-z /]*?)\s*[/:\- ]\s*((?:19|20)\d\d)", tv + ";" + notes):
                cid = (crops_in(m.group(1)) or [None])[0]
                if cid:
                    hist.append({"crop": cid, "year": int(m.group(2))})
                else:
                    warnings.append(f"History entry '{m.group(0).strip()}': crop not recognised.")
            if hist:
                hist.sort(key=lambda h: -h["year"])
                cons["history"] = hist
                applied.append({"row": r["priority_or_constraint"], "effect": f"{len(hist)} past crop(s) read; a repeat of last year's crop family is penalised"})
        elif key == "field boundary or parcel identifier":
            if tv.startswith("{"):
                try:
                    gj = json.loads(tv)
                    cons["boundary"] = gj
                    applied.append({"row": r["priority_or_constraint"], "effect": f"GeoJSON {gj.get('type', 'object')} stored as the field boundary"})
                except ValueError:
                    warnings.append("Boundary looks like GeoJSON but could not be parsed.")
            else:
                cons["parcel_id"] = tv
                not_modelled.append({"row": r["priority_or_constraint"], "why": "A parcel identifier cannot be turned into a boundary without a parcel service. Recorded as a note. Draw the boundary on the map or paste GeoJSON."})
        elif key in ("avoid new equipment", "limit peak labor demand"):
            cons[key.replace(" ", "_")] = wf if not math.isnan(wf) else (tv or True)
            not_modelled.append({"row": r["priority_or_constraint"], "why": "No machinery or labour data exist in the crop table, so this cannot change the ranking. It is recorded and shown with the results."})
        else:
            warnings.append(f"Row '{r['priority_or_constraint']}' is not one this app knows.")
    if not (applied or not_modelled):
        return {"ok": False, "error": "The template has no filled-in rows. Add weights (1 to 5) or targets and upload it again."}
    return {"ok": True, "priorities": pri, "constraints": cons, "applied": applied, "not_modelled": not_modelled, "warnings": warnings}
