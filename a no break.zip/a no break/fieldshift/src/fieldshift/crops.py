"""Crop knowledge base loader (layer 4 input). Knowledge lives in crops.json, not in code."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass

HERE = os.path.dirname(__file__)


@dataclass(frozen=True)
class Crop:
    id: str
    name: str
    family: str
    dur: int
    tmin: float
    tlo: float
    thi: float
    tmax: float
    need: float
    nfix: float
    erosion: float
    om: float
    forage: float
    market: float
    confidence: str
    temp_sd: float
    need_sd_frac: float
    sources: tuple


def load_crops(path: str | None = None) -> list[Crop]:
    path = path or os.path.join(HERE, "crops.json")
    with open(path) as f:
        data = json.load(f)["crops"]
    out = []
    for c in data:
        t = c["temp"]
        out.append(Crop(
            id=c["id"], name=c["name"], family=c["family"], dur=int(c["dur"]),
            tmin=t["min"], tlo=t["lo"], thi=t["hi"], tmax=t["max"], need=c["need_mm"],
            nfix=c["nfix"], erosion=c["erosion"], om=c["om"], forage=c["forage"],
            market=c["market"], confidence=c["confidence"], temp_sd=c.get("temp_sd", 2.0),
            need_sd_frac=c.get("need_sd_frac", 0.3), sources=tuple(c.get("sources", [])),
        ))
    ids = [c.id for c in out]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate crop ids in crops.json")
    return out
