"""16-day weather outlook. The forecast itself comes from Open-Meteo (national weather models), NOT from NASA.
It is compared with the field's own 25-year NASA POWER normals and with the latest satellite state, using plain rules
that are written out in the result so a farmer can see why each action appears."""
from __future__ import annotations

import time
from datetime import date, datetime, timezone

import numpy as np
import requests

URL = "https://api.open-meteo.com/v1/forecast"
DAILY = "temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration,wind_speed_10m_max"
_CACHE: dict = {}


def fetch(lat: float, lon: float, days: int = 16, timeout: int = 25) -> dict:
    key = (round(lat, 2), round(lon, 2))
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    r = requests.get(URL, params={"latitude": lat, "longitude": lon, "daily": DAILY, "forecast_days": days, "timezone": "auto"}, timeout=timeout)
    r.raise_for_status()
    d = r.json()["daily"]
    rows = []
    for i, t in enumerate(d["time"]):
        g = lambda k: (d.get(k) or [None] * len(d["time"]))[i]  # noqa: E731
        rows.append({"date": t, "tmax": g("temperature_2m_max"), "tmin": g("temperature_2m_min"), "rain_mm": g("precipitation_sum"),
                     "rain_prob": g("precipitation_probability_max"), "et0_mm": g("et0_fao_evapotranspiration"), "wind_kmh": g("wind_speed_10m_max")})
    out = {"source": "Open-Meteo forecast (national weather models)", "fetched_at": datetime.now(timezone.utc).isoformat(timespec="minutes"), "days": rows}
    _CACHE[key] = (time.time(), out)
    return out


def doy_normals(dates, tmax, tmin, rain) -> dict:
    """Day-of-year normals from the daily NASA POWER history, smoothed over +-7 days."""
    d = np.asarray(dates, "datetime64[D]")
    doy = (d - d.astype("datetime64[Y]")).astype(int)            # 0..365
    out = {k: np.full(366, np.nan) for k in ("tmax", "tmin", "rain", "tmax_p90")}
    for i in range(366):
        sel = np.abs(((doy - i + 183) % 366) - 183) <= 7
        if sel.sum() < 20:
            continue
        out["tmax"][i], out["tmin"][i], out["rain"][i] = np.nanmean(tmax[sel]), np.nanmean(tmin[sel]), np.nanmean(rain[sel])
        out["tmax_p90"][i] = np.nanpercentile(tmax[sel], 90)
    return {k: [None if np.isnan(x) else round(float(x), 2) for x in v] for k, v in out.items()}


def _lead_conf(i):
    return "high" if i < 3 else "medium" if i < 7 else "low"


def _doy(s):
    d = date.fromisoformat(s)
    return min(d.timetuple().tm_yday - 1, 365)


def outlook(fc: dict, normals: dict | None, ctx: dict) -> dict:
    """ctx: crop (name, heat_crit, cold_crit) or None if the field is bare, irrigation_mm, ndvi_gap (observed-expected) and its date."""
    days = fc["days"]
    crop = ctx.get("crop")
    heat = crop["heat_crit"] if crop else 38.0
    cold = crop["cold_crit"] if crop else 0.0
    rows = []
    for i, d in enumerate(days):
        k = _doy(d["date"])
        nm = lambda key: (normals[key][k] if normals and normals.get(key) else None)  # noqa: E731
        rows.append({**d, "lead_confidence": _lead_conf(i), "normal_tmax": nm("tmax"), "normal_rain_mm": nm("rain")})
    num = lambda key, sub=rows: [r[key] for r in sub if r[key] is not None]  # noqa: E731
    r7, r16 = rows[:7], rows
    rain7, rain16 = sum(num("rain_mm", r7)), sum(num("rain_mm", r16))
    nrain7, nrain16 = sum(num("normal_rain_mm", r7)), sum(num("normal_rain_mm", r16))
    tm7 = np.mean(num("tmax", r7)) if num("tmax", r7) else None
    nt7 = np.mean(num("normal_tmax", r7)) if num("normal_tmax", r7) else None
    kc = 1.0 if crop else 0.4
    et16 = sum(num("et0_mm", r16)) * kc
    deficit = max(0.0, et16 - rain16)
    heat_days = [r for r in rows if r["tmax"] is not None and r["tmax"] >= heat]
    cold_days = [r for r in rows if r["tmin"] is not None and r["tmin"] <= cold]
    heavy = [r for r in rows if (r["rain_mm"] or 0) >= 40]
    run = best = 0
    for r in rows:
        run = run + 1 if (r["rain_mm"] or 0) < 1 else 0
        best = max(best, run)
    stats = {"rain_next7_mm": round(rain7, 1), "normal_rain_next7_mm": round(nrain7, 1) if normals else None,
             "rain_next16_mm": round(rain16, 1), "normal_rain_next16_mm": round(nrain16, 1) if normals else None,
             "tmax_next7_c": None if tm7 is None else round(float(tm7), 1), "normal_tmax_next7_c": None if nt7 is None else round(float(nt7), 1),
             "heat_days": len(heat_days), "cold_days": len(cold_days), "heavy_rain_days": len(heavy), "longest_dry_run_days": best,
             "crop_water_use_16d_mm": round(et16, 0), "water_gap_16d_mm": round(deficit, 0), "heat_limit_c": heat, "cold_limit_c": cold}
    acts = []
    sub = f"{crop['name']}" if crop else "a bare field"
    if heat_days:
        sev = "crit" if len(heat_days) >= 3 or heat_days[0] is rows[0] or rows.index(heat_days[0]) < 5 else "warn"
        acts.append({"id": "heat", "severity": sev, "title": f"Heat of {heat:.0f} °C or more on {len(heat_days)} day(s)",
                     "evidence": f"Forecast daily highs reach {max(r['tmax'] for r in heat_days):.0f} °C on {', '.join(r['date'][5:] for r in heat_days[:4])}. {sub} is damaged above about {heat:.0f} °C in the crop table.",
                     "action": "General guidance: irrigate in the early morning or evening, and avoid sowing or transplanting on those days." if crop else "Avoid sowing on those days."})
    if cold_days:
        acts.append({"id": "cold", "severity": "crit" if len(cold_days) >= 2 else "warn", "title": f"Cold nights at or below {cold:.0f} °C",
                     "evidence": f"Forecast lows reach {min(r['tmin'] for r in cold_days):.0f} °C on {', '.join(r['date'][5:] for r in cold_days[:4])}.",
                     "action": "General guidance: protect young plants if you can (light irrigation before a cold night, mulch)."})
    if heavy:
        acts.append({"id": "heavy_rain", "severity": "warn", "title": f"Heavy rain (40 mm or more) on {len(heavy)} day(s)",
                     "evidence": f"Forecast on {', '.join(r['date'][5:] + ' (' + str(round(r['rain_mm'])) + ' mm)' for r in heavy[:3])}.",
                     "action": "General guidance: avoid spreading fertiliser or spraying just before; check drainage. A bare field loses soil fastest in heavy rain."})
    if deficit >= 25 and best >= 7:
        have = ctx.get("irrigation_mm") or 0
        acts.append({"id": "dry", "severity": "crit" if deficit >= 60 else "warn", "title": f"Dry stretch of {best} days; water gap about {deficit:.0f} mm",
                     "evidence": f"Over 16 days the crop would use about {et16:.0f} mm and the forecast brings {rain16:.0f} mm (normal for these dates: {nrain16:.0f} mm).",
                     "action": ("Plan roughly that much irrigation if the soil is already dry. " + ("You listed irrigation water as available." if have > 0 else "You listed no irrigation water, so consider drought-tolerant timing or mulch.")) if crop else "Little to do while bare; keep residue or mulch to hold moisture."})
    elif rain7 >= max(15, 1.5 * nrain7) and not heavy:
        acts.append({"id": "wet_week", "severity": "info", "title": "Wetter than normal week ahead", "evidence": f"{rain7:.0f} mm forecast in 7 days against a normal {nrain7:.0f} mm.",
                     "action": "Good moisture for sowing if a sowing window is open. Hold irrigation."})
    gap, gdate = ctx.get("ndvi_gap"), ctx.get("ndvi_date")
    sat = None
    if gap is not None:
        stressed = gap < -0.08
        sat = {"date": gdate, "gap_ndvi": round(gap, 3), "stressed": stressed}
        dry_ahead = deficit >= 25 and best >= 5
        if stressed and dry_ahead:
            acts.insert(0, {"id": "combined", "severity": "crit", "title": "Crop was already under stress, and a dry spell is coming",
                            "evidence": f"The latest satellite reading ({gdate}) was {abs(gap):.2f} greenness units below what the weather explains, and the forecast has {best} dry days.",
                            "action": "Highest priority: inspect this field and irrigate it first if you can. (Satellite data can be weeks old; check the field.)"})
        elif stressed:
            acts.append({"id": "unexplained", "severity": "warn", "title": "Crop is less green than the weather explains",
                         "evidence": f"Latest satellite reading ({gdate}) is {abs(gap):.2f} below expected, and the forecast is not especially dry.",
                         "action": "The cause is not weather. Walk the field and check pests, nutrients, waterlogging or sowing problems."})
        else:
            acts.append({"id": "sat_ok", "severity": "info", "title": "Satellite shows the crop doing as the weather would predict", "evidence": f"Latest reading {gdate}, difference {gap:+.2f}.", "action": ""})
    level = "alert" if any(a["severity"] == "crit" for a in acts) else "watch" if any(a["severity"] == "warn" for a in acts) else "calm"
    return {"level": level, "stats": stats, "actions": acts, "satellite": sat, "days": rows, "crop_now": crop["name"] if crop else None,
            "confidence_note": "Forecast skill falls with lead time: days 1 to 3 are the most reliable, days 8 to 16 show tendencies only.",
            "method": "Rules compare the forecast with the field's 25-year NASA POWER day-of-year normals and with the crop's heat and cold limits from the crop table (estimates). They are guidance, not instructions."}
