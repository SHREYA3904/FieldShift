"""Layers 3-5: features, crop models and the strategy engine.

For every crop and every planting month we compute a temperature fit and a water fit.
Rotations are pairs of crops whose growing periods do not overlap. A Monte Carlo loop
perturbs the climate (using real interannual spread) and the crop parameters, so every
result carries an honest uncertainty: how often it beats the farmer's current rotation.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from .climate import Climate
from .crops import Crop

HOLD = {"loam": 1.0, "clay": 1.05, "sandy": 0.8}      # relative soil water holding
PRIORITY_KEYS = ("water", "nfix", "erosion", "om", "forage", "market")
DEFAULT_PRIORITIES = {"water": 4, "nfix": 4, "erosion": 3, "om": 3, "forage": 3, "market": 3}


@dataclass
class Scenario:
    rain_pct: float = 0.0       # change in rainfall, percent
    temp_c: float = 0.0         # warming, C


@lru_cache(maxsize=None)
def _valid_mask(di: int, dj: int) -> np.ndarray:
    """mask[a, b] is True when crop i sown in month a and crop j sown in month b do not overlap."""
    m = np.zeros((12, 12), bool)
    for a in range(12):
        ma = {(a + k) % 12 for k in range(di)}
        for b in range(12):
            mb = {(b + k) % 12 for k in range(dj)}
            m[a, b] = not (ma & mb)
    return m


def crop_fits(T, R, c: Crop, irr: float, hold: float, dlim: float = 0.0, need_mult: float = 1.0) -> dict:
    """Fit of crop c for each of the 12 possible sowing months (vectorised)."""
    idx = (np.arange(12)[:, None] + np.arange(c.dur)[None, :]) % 12
    t = T[idx]
    mn, lo, hi, mx = c.tmin + dlim, c.tlo + dlim, c.thi + dlim, c.tmax + dlim
    f = np.where((t < mn) | (t > mx), 0.0,
        np.where(t < lo, (t - mn) / (lo - mn),
        np.where(t <= hi, 1.0, (mx - t) / (mx - hi))))
    tf = f.mean(1)
    cold = (t < mn).any(1)
    tf = np.where(cold, tf * 0.5, tf)
    rain = R[idx].sum(1)
    need = c.need * need_mult
    wf = np.minimum(1.0, (rain + irr) * hold / need)
    return {"tf": tf, "wf": wf, "fit": 0.5 * tf + 0.5 * wf, "rain": rain,
            "irr_need": np.maximum(0.0, need - rain), "hot": (t > hi).sum(1),
            "cold": cold, "idx": idx, "t": t, "need": need}


def priority_score(c: Crop, w: dict) -> float:
    pr = {"water": (1 - min(1.0, c.need / 1200)) * 5, "nfix": c.nfix, "erosion": c.erosion,
          "om": c.om, "forage": c.forage, "market": c.market}
    tw = sum(w.get(k, 0) for k in PRIORITY_KEYS)
    if tw == 0:
        return 0.5
    return sum(w.get(k, 0) * pr[k] / 5 for k in PRIORITY_KEYS) / tw


class Engine:
    def __init__(self, crops: list[Crop]):
        self.crops = crops
        self.pairs = [(i, j) for i in range(len(crops)) for j in range(i + 1, len(crops))]
        self.pair_index = {p: k for k, p in enumerate(self.pairs)}

    # ---- one deterministic evaluation of every pair ----
    def evaluate(self, T, R, irr, hold, w, dlim=None, need_mult=None, pri_noise=None):
        n = len(self.crops)
        fits = [crop_fits(T, R, c, irr, hold,
                          0.0 if dlim is None else dlim[i],
                          1.0 if need_mult is None else need_mult[i])
                for i, c in enumerate(self.crops)]
        pri = [priority_score(c, w) + (0.0 if pri_noise is None else pri_noise[i]) for i, c in enumerate(self.crops)]
        npairs = len(self.pairs)
        total = np.zeros(npairs); fit = np.zeros(npairs); irrn = np.zeros(npairs)
        ab = np.zeros((npairs, 2), int)
        for k, (i, j) in enumerate(self.pairs):
            ci, cj = self.crops[i], self.crops[j]
            F = fits[i]["fit"][:, None] + fits[j]["fit"][None, :]
            F = np.where(_valid_mask(ci.dur, cj.dur), F, -1.0)
            a, b = np.unravel_index(int(np.argmax(F)), F.shape)
            ab[k] = (a, b)
            fit[k] = F[a, b] / 2
            irrn[k] = fits[i]["irr_need"][a] + fits[j]["irr_need"][b]
            legume = 1.0 if (ci.nfix >= 4 or cj.nfix >= 4) else 0.0
            total[k] = 0.45 * fit[k] + 0.55 * (pri[i] + pri[j]) / 2 + 0.04 * legume
        return {"total": total, "fit": fit, "irr_need": irrn, "ab": ab, "fits": fits, "pri": pri}

    # ---- full analysis ----
    def run(self, climate: Climate, priorities: dict | None = None, scenario: Scenario | None = None,
            soil: str = "loam", irrigation_mm: float = 0.0, current: tuple[str, str] | None = None,
            n_mc: int = 300, seed: int = 0) -> dict:
        w = {**DEFAULT_PRIORITIES, **(priorities or {})}
        sc = scenario or Scenario()
        hold = HOLD.get(soil, 1.0)
        T = climate.temp + sc.temp_c
        R = np.maximum(0.0, climate.rain * (1 + sc.rain_pct / 100))
        central = self.evaluate(T, R, irrigation_mm, hold, w)

        ids = [c.id for c in self.crops]
        cur_k = None
        if current:
            if current[0] == current[1]:
                raise ValueError("current rotation needs two different crops")
            i, j = sorted((ids.index(current[0]), ids.index(current[1])))
            cur_k = self.pair_index[(i, j)]

        # Monte Carlo: weather noise from interannual SD, plus uncertain crop parameters
        rng = np.random.default_rng(seed)
        draws = np.zeros((n_mc, len(self.pairs)))
        for m in range(n_mc):
            Tk = T + rng.normal(0, climate.temp_sd)
            Rk = np.maximum(0.0, R + rng.normal(0, climate.rain_sd))
            dlim = [rng.normal(0, c.temp_sd) for c in self.crops]
            nm = [max(0.5, 1 + rng.normal(0, c.need_sd_frac)) for c in self.crops]
            pn = rng.normal(0, 0.10, len(self.crops))     # the 0-5 judgement scores are uncertain too
            draws[m] = self.evaluate(Tk, Rk, irrigation_mm, hold, w, dlim, nm, pn)["total"]
        ranks = (-draws).argsort(1).argsort(1)             # 0 = best
        mc = {
            "p10": np.percentile(draws, 10, axis=0), "p90": np.percentile(draws, 90, axis=0),
            "p_top3": (ranks < 3).mean(0),
            "p_beats_current": (draws > draws[:, [cur_k]]).mean(0) if cur_k is not None else None,
        }
        return {"central": central, "mc": mc, "cur_k": cur_k, "weights": w, "scenario": sc,
                "irrigation_mm": irrigation_mm, "soil": soil, "n_mc": n_mc, "seed": seed}

    # ---- pick strategies to show ----
    def pick_strategies(self, res: dict) -> list[tuple[str, str, int]]:
        c = res["central"]; cur = res["cur_k"]
        soil_score = np.array([(self.crops[i].nfix + self.crops[i].om + self.crops[i].erosion +
                                self.crops[j].nfix + self.crops[j].om + self.crops[j].erosion) / 30
                               for i, j in self.pairs])
        minfit = np.array([min(c["fits"][i]["fit"][c["ab"][k][0]], c["fits"][j]["fit"][c["ab"][k][1]])
                           for k, (i, j) in enumerate(self.pairs)])
        viable = [k for k in range(len(self.pairs)) if c["fit"][k] >= 0.6 and minfit[k] >= 0.4]
        if len(viable) < 3:
            viable = list(np.argsort(-c["fit"])[:12])
        out, seen = [], set()
        if cur is not None:
            out.append(("Your current rotation",
                        "This is what you grow now. It is the baseline the other options are compared with.", cur))
            seen.add(cur)

        def pick(label, why, key):
            cand = [k for k in viable if k not in seen]
            if cand:
                k = min(cand, key=key)
                out.append((label, why, k)); seen.add(k)
        pick("Best match to your priorities",
             "Scores highest against the priorities you set, among rotations that suit the climate.",
             lambda k: -c["total"][k])
        pick("Water-saving option",
             "Needs the least irrigation among rotations that still suit the climate.",
             lambda k: c["irr_need"][k])
        pick("Soil-building option",
             "Scores highest for nitrogen fixing, ground cover and organic matter among rotations that suit the climate.",
             lambda k: (-soil_score[k], -c["total"][k]))
        pick("Best climate fit",
             "Closest match between the crops' temperature limits and this place's climate.",
             lambda k: -c["fit"][k])
        return out
