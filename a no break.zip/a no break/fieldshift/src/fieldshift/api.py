"""FastAPI app: field store, live analysis, scenario re-runs, grounded assistant, and the web app."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from fastapi import Request as HttpRequest
from fastapi import Cookie, Depends, FastAPI, Header, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from datetime import date

from . import simulate
from . import ai, assistant, auth, datapack, datasets, game, geo, forecast, ingest, service, store

app = FastAPI(title="Field Shift API", version="0.6.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

WATER = {"low": 0.0, "medium": 250.0, "high": 600.0}


class Request(BaseModel):                       # legacy request
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    soil: str = Field("auto", pattern="^(auto|loam|clay|sandy|ssurgo:[A-Za-z0-9]+)$")
    irrigation_mm: float = Field(0, ge=0, le=3000)
    current: list[str] | None = Field(None, description="two crop ids")
    priorities: dict[str, float] | None = None
    rain_pct: float = Field(0, ge=-80, le=80)
    temp_c: float = Field(0, ge=-3, le=6)
    n_mc: int = Field(300, ge=20, le=2000)
    offline: bool = False


class FieldIn(BaseModel):
    farm: str = Field("My farm", max_length=120)
    name: str = Field(max_length=120)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    area_ha: float | None = Field(None, ge=0, le=100000)
    soil: str = Field("auto", pattern="^(auto|loam|clay|sandy|ssurgo:[A-Za-z0-9]+)$")
    irrigation_mm: float = Field(0, ge=0, le=3000)
    water_availability: str = Field("medium", pattern="^(low|medium|high)$")
    current: list[str] = Field(min_length=2, max_length=2)
    history: list[str] = []
    priorities: dict[str, float] = {}
    soil_test: dict[str, float] = {}
    constraints: dict = {}
    boundary: dict | None = None
    note: str = ""


class Scenario(BaseModel):
    rain_pct: float = Field(0, ge=-80, le=80)
    temp_c: float = Field(0, ge=-3, le=6)
    water_availability: str | None = Field(None, pattern="^(low|medium|high)$")
    priorities: dict[str, float] | None = None
    offline: bool = False
    projection_scenario: str | None = Field(None, pattern="^(ssp126|ssp245|ssp370)$")
    projection_period: str | None = Field(None, pattern="^20[2-8]1-20[4-9]0$|^2081-2100$")


class AssistantIn(Scenario):
    field_id: str
    question: str = Field(min_length=2, max_length=400)
    language: str = Field("Auto", max_length=40)
    here_lat: float | None = Field(None, ge=-90, le=90)
    here_lon: float | None = Field(None, ge=-180, le=180)
    use_here: bool = False
    voice: bool = False


class ExplainRequest(BaseModel):
    strategy: dict
    question: str | None = Field(None, max_length=400)
    language: str = Field("Auto", max_length=40)


_CACHE: dict[str, tuple[float, dict]] = {}


def _validate_current(cur):
    ids = {c["id"] for c in service.crop_list()}
    if len(cur) != 2 or cur[0] == cur[1] or not set(cur) <= ids:
        raise HTTPException(422, f"current must be two different crop ids from {sorted(ids)}")
    return (cur[0], cur[1])


def run_field(f: dict, sc: Scenario) -> dict:
    cur = _validate_current(f["current"])
    irr = WATER[sc.water_availability] if sc.water_availability else f.get("irrigation_mm", 0)
    pri = sc.priorities or f.get("priorities") or None
    key = json.dumps([f["lat"], f["lon"], f["soil"], irr, cur, pri, sc.rain_pct, sc.temp_c, f.get("soil_test"), sc.offline, f.get("constraints"), sc.projection_scenario, sc.projection_period], sort_keys=True, default=str)
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 900:
        return hit[1]
    try:
        out = service.analyse(f["lat"], f["lon"], f["soil"], irr, cur, pri, sc.rain_pct, sc.temp_c, 0, 0, sc.offline, soil_test=f.get("soil_test") or None,
                              constraints=f.get("constraints") or None,
                              projection={"scenario": sc.projection_scenario, "period": sc.projection_period} if sc.projection_scenario and sc.projection_period else None)
    except ValueError as e:
        raise HTTPException(422, str(e))
    out["datasets"] = datasets.build(out)
    out["scenario"] = {"rain_pct": sc.rain_pct, "temp_c": sc.temp_c, "irrigation_mm": irr, "hypothetical": bool(sc.rain_pct or sc.temp_c or sc.projection_scenario)}
    out["field"] = f
    if len(_CACHE) > 64:
        _CACHE.pop(next(iter(_CACHE)))
    _CACHE[key] = (time.time(), out)
    return out


def current_user(fs_session: str | None = Cookie(default=None)):
    return auth.user_for_token(fs_session)


def need_user(u=Depends(current_user)):
    if not u:
        raise HTTPException(401, "Please sign in first.")
    return u


def _field(fid, user=None):
    f = store.get_field(fid, user["id"] if user else None)
    if not f:
        raise HTTPException(404, "I cannot find this field in your account. Your field list will refresh; please pick a field again.")
    return f


class SignupIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(min_length=1, max_length=128)
    name: str = Field("", max_length=80)


class LoginIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(min_length=1, max_length=128)


class ProfileIn(BaseModel):
    name: str | None = Field(None, max_length=80)
    profile: dict | None = None


def _auth_call(fn, *a):
    try:
        return fn(*a)
    except auth.AuthError as e:
        raise HTTPException(e.status, str(e))


def _start(response, user, token):
    response.set_cookie("fs_session", token, max_age=auth.SESSION_DAYS * 86400, httponly=True, samesite="lax", secure=os.environ.get("FIELDSHIFT_COOKIE_SECURE") == "1", path="/")
    return {"user": user}


@app.post("/api/auth/signup")
def auth_signup(r: SignupIn, response: Response):
    user, token = _auth_call(auth.signup, r.email, r.password, r.name)
    return {**_start(response, user, token), "new": True}


_GUESTS = {"n": 0, "t": 0.0}


@app.post("/api/auth/guest")
def auth_guest(response: Response, fs_session: str | None = Cookie(default=None)):
    """A private device account so a farmer's field is saved without typing an email. They can add an email later."""
    cur = auth.user_for_token(fs_session)
    if cur:
        return {"user": cur, "new": False}
    now = time.time()
    if now - _GUESTS["t"] > 3600:
        _GUESTS.update(n=0, t=now)
    _GUESTS["n"] += 1
    if _GUESTS["n"] > 300:
        raise HTTPException(429, "Too many new devices just now. Please try again in a while.")
    import secrets as _s
    user, token = _auth_call(auth.signup, f"guest-{_s.token_hex(8)}@guest.terraadapt.local", _s.token_urlsafe(24), "")
    return {**_start(response, user, token), "new": True, "guest": True}


@app.post("/api/auth/login")
def auth_login(r: LoginIn, response: Response):
    user, token = _auth_call(auth.login, r.email, r.password)
    return {**_start(response, user, token), "new": False}


@app.post("/api/auth/logout")
def auth_logout(response: Response, fs_session: str | None = Cookie(default=None)):
    auth.logout(fs_session)
    response.delete_cookie("fs_session", path="/")
    return {"ok": True}


@app.get("/api/me")
def me(u=Depends(current_user)):
    if not u:
        return {"user": None}
    return {"user": u, "fields": len(store.list_fields(u["id"])) - 1}


@app.put("/api/me")
def update_me(p: ProfileIn, u=Depends(need_user)):
    prof = None
    if p.profile is not None:
        allowed = {"region", "farm_size_ha", "experience", "main_goal", "language", "crops_interest", "water_source", "notes"}
        prof = {**u["profile"], **{k: v for k, v in p.profile.items() if k in allowed}}
    return {"user": store.update_user(u["id"], name=p.name, profile=prof)}


@app.get("/api/me/memory")
def memory(u=Depends(need_user)):
    return {"chat": store.list_memory(u["id"], "chat", limit=60), "snapshots": store.list_memory(u["id"], "snapshot", limit=60)}


@app.delete("/api/me/memory")
def forget(kind: str | None = None, u=Depends(need_user)):
    store.clear_memory(u["id"], kind)
    return {"cleared": kind or "all"}


class KeyIn(BaseModel):
    key: str = Field(max_length=200)


@app.post("/api/ai/save-key")
def ai_save_key(b: KeyIn, request: HttpRequest):
    """Write the Gemini key to the .env file next to the app so it is picked up every time. Only from this computer (localhost)."""
    if (request.client.host if request.client else "") not in ("127.0.0.1", "::1", "localhost") or request.headers.get("x-forwarded-for") or request.headers.get("forwarded"):
        raise HTTPException(403, "The key can only be saved from the computer that runs the app.")
    k = b.key.strip().strip('"').strip("'")
    if not (20 <= len(k) <= 120) or any(c.isspace() for c in k):
        raise HTTPException(422, "That does not look like a Gemini key. It is one line of letters and numbers, usually starting with AIza.")
    env = ai.ENV_DIR / ".env"
    lines = []
    try:
        lines = [ln for ln in env.read_text(encoding="utf-8-sig").splitlines() if not ln.strip().startswith(("GEMINI_API_KEY", "GOOGLE_API_KEY"))]
    except OSError:
        pass
    lines.append("GEMINI_API_KEY=" + k)
    try:
        env.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as e:
        raise HTTPException(500, f"Could not write {env}: {e}")
    os.environ["GEMINI_API_KEY"] = k
    ai.ENV_FILES.add(str(env))
    return {"ok": True, "file": str(env)}


@app.post("/api/ai/test")
def ai_test(x_ai_key: str | None = Header(None), x_ai_model: str | None = Header(None)):
    """Say whether Gemini accepts the key (browser key first, then the server one)."""
    key = (x_ai_key or ai.env_key()).strip()
    if not key:
        return {"ok": False, "message": "No AI yet. Start a local model (Ollama or LM Studio) or paste a Gemini key and press Save."}
    try:
        ai.generate("Reply with the single word OK.", [{"role": "user", "content": "ping"}], key, x_ai_model, 25, 20)
        pv = ai.provider(key)
        return {"ok": True, "message": f"Local model '{pv['model']}' on this computer answered. AI is ready." if pv["name"] == "local" else "Gemini accepted the key. AI is ready."}
    except ai.AIError as e:
        return {"ok": False, "message": str(e)}


@app.get("/health")
@app.get("/api/health")
def health():
    k = ai.env_key(); pv = ai.provider(k); why = ""
    if not k:
        why = (ai.local_problem() + " Or add a Gemini key. "
               + ("A .env file was read but it has no GEMINI_API_KEY=... line." if ai.ENV_FILES else f"No .env file found in {Path.cwd()}."))
    return {"status": "ok", "ai_enabled": bool(k), "ai_hint": why, "ai_provider": pv["name"], "ai_model": pv["model"]}


@app.get("/api/datapack")
def datapack_info():
    c = datapack.climatology()
    return {"region": {"name": datapack.REGION_NAME, "lat": datapack.CENTRE[0], "lon": datapack.CENTRE[1], "radius_km": datapack.RADIUS_KM},
            "files": datapack.file_inventory(), "sources": datapack.sources(), "climatology": c, "daily_vs_climatology": datapack.daily_vs_climatology(),
            "projections": datapack.projection_summary(), "cdl": datapack.cdl(), "ecocrop": list(datapack.ecocrop().values())}


@app.get("/api/datapack/region")
def datapack_region(lat: float = Query(ge=-90, le=90), lon: float = Query(ge=-180, le=180)):
    return datapack.region(lat, lon)


@app.get("/api/datapack/soils")
def datapack_soils():
    out = []
    for m in datapack.mapunits():
        p = datapack.soil_profile(m["mukey"])
        out.append({"id": "ssurgo:" + m["mukey"], "musym": m["musym"], "name": m["name"], "usable": bool(p and p.get("usable")),
                    **({k: p[k] for k in ("sand_pct", "clay_pct", "organic_matter_pct", "ph", "awc_mm_per_m", "drainage_class", "data_coverage")} if p and p.get("usable") else {})})
    out.append({"id": "ssurgo:demo", "musym": "Ab", "name": datapack.demo_point()["name"] + " (demo point)", "usable": True, **{k: v for k, v in datapack.soil_profile("demo").items() if k in ("sand_pct", "clay_pct", "organic_matter_pct", "ph", "awc_mm_per_m", "drainage_class", "data_coverage")}})
    return out


@app.get("/api/datapack/projection")
def datapack_projection(scenario: str, period: str):
    p = datapack.projection(scenario, period)
    if not p:
        raise HTTPException(422, "unknown scenario or period")
    return p


@app.get("/api/priorities/template", response_class=PlainTextResponse)
def priorities_template():
    return PlainTextResponse(datapack.priorities_template(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=farmer_priorities_template.csv"})


class CsvIn(BaseModel):
    text: str = Field(max_length=50000)


@app.post("/api/priorities/parse")
def priorities_parse(b: CsvIn):
    r = datapack.parse_priorities(b.text)
    if not r["ok"]:
        raise HTTPException(422, r["error"])
    return r


class TranslateIn(BaseModel):
    language: str = Field(min_length=2, max_length=40, pattern=r"^[A-Za-z][A-Za-z \-\(\)']+$")
    texts: list[str] = Field(max_length=60)


@app.post("/api/translate")
def translate(b: TranslateIn, x_ai_key: str | None = Header(default=None), x_ai_model: str | None = Header(default=None)):
    """Translate interface text into any language with the farmer's Gemini key. Results are cached so each phrase is translated once."""
    texts = [t.strip()[:400] for t in b.texts if t.strip()]
    got = {k: v for k, v in store.tr_get(b.language, texts).items() if isinstance(v, str) and v.strip() and v.strip().lower() not in ("null", "none", "undefined", "nan")}
    todo = [t for t in dict.fromkeys(texts) if t not in got]
    key = ai.LOCAL if ai.local_info() else ""        # translation never uses Gemini (its quota is kept for nothing else to run out): built-in word lists, plus a local model for the rest
    if todo and key:
        sysmsg = ("You translate the interface of a farming advice app. Translate each English string into the target language in simple words a farmer with little schooling understands. "
                  "Keep numbers, units, symbols, crop and place names recognisable. Do not add explanations. Return ONLY a JSON array of strings, the same length and order as the input.")
        for k in range(0, len(todo), 25):                       # small batches: faster, and a cut-off answer only loses one batch
            chunk, new = todo[k:k + 25], None
            for attempt in (1, 2):
                try:
                    raw = ai.generate(sysmsg, [{"role": "user", "content": f"Target language: {b.language}\nStrings:\n" + json.dumps(chunk, ensure_ascii=False)}], key, x_ai_model, 60, 8000, json_mode=True).strip()
                    out = json.loads(raw[raw.index("["): raw.rindex("]") + 1])
                    if isinstance(out, list) and len(out) == len(chunk) and all(isinstance(x, str) for x in out):
                        new = {s: (t if t.strip() and t.strip().lower() not in ("null", "none", "undefined", "nan") else s) for s, t in zip(chunk, out)}   # a model that answers "null" keeps the English instead
                        break
                except ai.AIError:
                    break
                except (ValueError, json.JSONDecodeError):
                    pass
            if new is None:
                break                                           # whatever is not translated stays in English; no error is shown
            store.tr_put(b.language, new)
            got.update(new)
    return {"language": b.language, "translations": {t: got[t] for t in texts if t in got}}


class AudioIn(BaseModel):
    audio_b64: str = Field(max_length=2_500_000)
    mime: str = Field(pattern=r"^audio/[a-z0-9.+\-]+(;\s*codecs=[a-z0-9.,\-]+)?$")
    language: str = Field("Auto", max_length=40)


@app.post("/api/transcribe")
def transcribe(b: AudioIn, x_ai_key: str | None = Header(default=None), x_ai_model: str | None = Header(default=None)):
    key = (x_ai_key or "").strip() or ai.env_key()
    if not key:
        raise HTTPException(402, "Voice without the browser's speech engine needs a Gemini API key. Add it under Settings (the gear icon).")
    try:
        return {"text": ai.transcribe(b.audio_b64, b.mime.split(";")[0], key, b.language, x_ai_model)}
    except ai.AIError as e:
        raise HTTPException(502, f"Transcription problem: {e}")


def _game_field(fid, user=None):
    """A saved field, or a just-arrived spot on Earth written as geo:LAT,LON (used by the first-run journey, no account needed)."""
    if fid.startswith("geo:"):
        try:
            la, lo = (float(x) for x in fid[4:].split(","))
        except ValueError:
            raise HTTPException(422, "Bad location.")
        if not (-90 <= la <= 90 and -180 <= lo <= 180):
            raise HTTPException(422, "Bad location.")
        return {"id": fid, "name": "Your place", "lat": la, "lon": lo, "soil": "auto", "soil_test": {}, "constraints": {}}
    return _field(fid, user)


class GameIn(BaseModel):
    field_id: str = Field(max_length=80)
    crop: str = Field(max_length=40)
    month: int = Field(ge=1, le=12)
    day: int = Field(1, ge=1, le=28)
    case: int = Field(0, ge=0, le=60)
    doses: list[int] = Field(default_factory=list, max_length=12)      # days since sowing on which the player irrigated one dose
    day_now: int | None = Field(None, ge=0, le=300)
    auto: bool = False                                                     # watch mode: Terra's autopilot irrigates
    covers: list[int] = Field(default_factory=list, max_length=2)          # nights (days since sowing) the player covers the crop against frost
    mulch: int | None = Field(None, ge=0, le=300)                          # day the player mulched the soil
    scouts: list[int] = Field(default_factory=list, max_length=4)          # days on which the player looked three days ahead
    worst: bool = False                                                    # "Survive your worst year": the hidden year is this spot's harshest one for a crop with no help


def _warm_all():
    """In the background, download (or read from disk) the weather of every saved field, so the first open of the game is instant."""
    from concurrent.futures import ThreadPoolExecutor
    try:
        places = list(dict.fromkeys((ingest.snap(a), ingest.snap(b)) for a, b in store.all_places()))[:60]
    except Exception:
        return
    def one(p):
        try:
            game.weather(*p); forecast.fetch(*p)
        except Exception:
            pass
    with ThreadPoolExecutor(max_workers=3) as ex:
        list(ex.map(one, places))


@app.on_event("startup")
def _startup_warm():
    import threading
    threading.Thread(target=_warm_all, daemon=True, name="warm-weather").start()


@app.post("/api/game/warm")
def game_warm(lat: float = Query(..., ge=-90, le=90), lon: float = Query(..., ge=-180, le=180)):
    """Start downloading the weather of a spot while the farmer is still naming the field, so the game opens fast. Never fails the caller."""
    try:
        w = game.weather(lat, lon)
        return {"ok": True, "years": len(w["years"]), "source": w["source"]}
    except RuntimeError as e:
        return {"ok": False, "error": str(e)}


@app.post("/api/game/play")
def game_play(b: GameIn, u=Depends(current_user)):
    """Replay one hidden past season. Only days that have already happened are returned, until the season ends."""
    f = _game_field(b.field_id, u)
    ps = game.crops()
    if b.crop not in ps:
        raise HTTPException(422, "Unknown crop.")
    p = ps[b.crop]
    try:
        w = game.weather(f["lat"], f["lon"])
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    awc, awc_src = game.awc_for(f)
    cases = game.playable_cases(w, p, awc, b.month, b.day)
    if len(cases) < 3:
        raise HTTPException(422, f"{p.name} sown on that date cannot finish in most past years here. Try another month.")
    if b.worst:                                       # the year in which the plain rain-fed crop scored lowest at this very spot
        year = min(cases, key=lambda y: (game.run(w, p, awc, game._start_idx(w, y, b.month, b.day), {})["score"], y))
    else:
        year = cases[(b.case * 7 + 3) % len(cases)]
    start = game._start_idx(w, year, b.month, b.day)
    doses = {d: game.DOSE_MM for d in sorted(set(b.doses))[: int(game.BUDGET_MM // game.DOSE_MM)]}
    ad = (None, game.BUDGET_MM) if b.auto else (doses, 0.0)
    cov = frozenset(sorted(set(b.covers))[: game.COVERS]) if not b.auto else frozenset()
    mul = b.mulch if not b.auto else None
    full = game.run(w, p, awc, start, ad[0], ad[1], covers=cov, mulch_day=mul)
    length = len(full["days"])
    now = length if b.day_now is None else min(b.day_now, length)
    shown = game.run(w, p, awc, start, ad[0], ad[1], upto=now, covers=cov, mulch_day=mul)
    peeks = []
    if not b.auto:
        for sd in sorted(set(b.scouts))[: game.SCOUTS]:
            if sd < now and sd + 1 < len(full["days"]):          # only a look ahead from a day that has already happened; never beyond the player's own day
                nx = full["days"][sd + 1: sd + 4]
                peeks.append({"from": sd, "days": len(nx), "rain_mm": round(sum(x["rain"] for x in nx), 1), "tmax": max(x["tmax"] for x in nx), "tmin": min(x["tmin"] for x in nx), "frost": any(x["tmin"] < p.cold_crit for x in nx), "hot": any(x["tmax"] > p.heat_crit for x in nx)})
    done = now >= length and full["finished"]
    out = {"crop": {"id": p.id, "name": p.name, "family": p.family, "cold_crit": p.cold_crit, "heat_crit": p.heat_crit}, "season_days": length, "now": now, "finished": done, "doses_left": 0 if b.auto else int(game.BUDGET_MM // game.DOSE_MM) - len(doses), "dose_mm": game.DOSE_MM, "covers_left": 0 if b.auto else game.COVERS - len(cov), "scouts_left": 0 if b.auto else game.SCOUTS - len(set(b.scouts)), "mulched": mul is not None, "peeks": peeks,
           "days": shown["days"], "cases": len(cases), "soil_source": awc_src, "weather_source": w["source"], "worst": b.worst, "note": "Teaching game: the score is a simple index, not a yield forecast." + (" Weather: backup ERA5 reanalysis (Open-Meteo), because NASA POWER could not be reached." if "Open-Meteo" in w["source"] else "")}
    if done:
        auto = game.run(w, p, awc, start, None, game.BUDGET_MM)
        rainfed = game.run(w, p, awc, start, {})
        out["result"] = {"year": year, "score": full["score"], "water_stress": round(full["water_stress"], 3), "heat_days": full["heat_days"], "cold_days": full["cold_days"], "irrigation_used_mm": full["irrigation_used_mm"],
                         "autopilot": {"score": auto["score"], "irrigation_used_mm": auto["irrigation_used_mm"]}, "rainfed": {"score": rainfed["score"]}, "facts": game.season_facts(w, start, length),
                         "source": "NASA POWER daily weather" + (" (supplied file)" if w["bundled"] else "")}
    return out


@app.get("/api/game/crops")
def game_crops():
    return [{"id": c.id, "name": c.name, "family": c.family} for c in game.crops().values()]


class OutlookIn(BaseModel):
    field_id: str = Field(max_length=80)
    crop: str = Field(max_length=40)
    month: int = Field(ge=1, le=12)
    day: int = Field(1, ge=1, le=28)


@app.post("/api/game/outlook")
def game_outlook(b: OutlookIn, u=Depends(current_user)):
    """Good or bad choice? Replays every past year for this crop and sowing date and summarises how it would have gone."""
    f = _game_field(b.field_id, u)
    ps = game.crops()
    if b.crop not in ps:
        raise HTTPException(422, "Unknown crop.")
    try:
        w = game.weather(f["lat"], f["lon"])
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    o = game.outlook(w, ps[b.crop], game.awc_for(f)[0], b.month, b.day, len(w["years"]))
    import numpy as _np
    o["place"] = {"name": f["name"], "lat": round(float(f["lat"]), 3), "lon": round(float(f["lon"]), 3), "years": len(w["years"]), "coldest_c": round(float(_np.nanmin(w["tmin"])), 1), "hottest_c": round(float(_np.nanmax(w["tmax"])), 1),
                  "source": "NASA POWER supplied file for Diamond Valley, Nevada" if w["bundled"] else ("BACKUP source, ERA5 reanalysis via Open-Meteo, because NASA POWER could not be reached" if "Open-Meteo" in w["source"] else "NASA POWER daily weather for this exact spot")}
    return o


@app.post("/api/game/recommend")
def game_recommend(b: OutlookIn, u=Depends(current_user)):
    """After the season: which month suits the chosen crop best here, and which other crops would do better on this spot."""
    f = _game_field(b.field_id, u)
    ps = game.crops()
    if b.crop not in ps:
        raise HTTPException(422, "Unknown crop.")
    try:
        w = game.weather(f["lat"], f["lon"])
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    return game.recommend(w, ps, game.awc_for(f)[0], b.crop, b.month, b.day)


@app.get("/crops")
@app.get("/api/crops")
def crops():
    return service.crop_list()


@app.get("/api/fields")
def list_fields(u=Depends(current_user)):
    return store.list_fields(u["id"] if u else None)


@app.post("/api/fields")
def create_field(f: FieldIn, u=Depends(need_user)):
    _validate_current(f.current)
    return store.save_field(f.model_dump(), None, u["id"])


@app.get("/api/fields/{fid}")
def get_field(fid: str, u=Depends(current_user)):
    return _field(fid, u)


@app.put("/api/fields/{fid}")
def update_field(fid: str, f: FieldIn, u=Depends(need_user)):
    _field(fid, u)
    _validate_current(f.current)
    return store.save_field(f.model_dump(), fid, u["id"])


@app.delete("/api/fields/{fid}")
def delete_field(fid: str, u=Depends(need_user)):
    if not store.delete_field(fid, u["id"]):
        raise HTTPException(400, "the demonstration field cannot be deleted, or it does not exist")
    return {"deleted": fid}


def _snapshot(u, f, out):
    """Remember what the analysis said, at most once a day per field, so the assistant can talk about change over time."""
    today = date.today().isoformat()
    last = store.list_memory(u["id"], "snapshot", f["id"], limit=1)
    if last and last[0]["created_at"][:10] == today:
        return
    best = max(out["strategies"][1:], key=lambda s: s["scores"]["overall"]) if len(out["strategies"]) > 1 else out["strategies"][0]
    store.add_memory(u["id"], "snapshot", {"date": today, "field": f["name"], "vulnerability": out["vulnerability"]["overall"], "category": out["vulnerability"]["category"],
                                           "current_score": round(out["strategies"][0]["scores"]["overall"], 3), "best": best["label"],
                                           "best_crops": [c["name"] for c in best["crops"]], "best_score": round(best["scores"]["overall"], 3),
                                           "warming_c_per_decade": out["climate"]["warming_trend_c_per_decade"]}, f["id"])


@app.post("/api/fields/{fid}/analyse")
def analyse_field(fid: str, sc: Scenario | None = None, u=Depends(current_user)):
    f = _field(fid, u)
    out = run_field(f, sc or Scenario())
    if u and fid != store.DEMO_ID and not (sc and (sc.rain_pct or sc.temp_c or sc.priorities or sc.projection_scenario)):
        _snapshot(u, f, out)
    return out


def _crop_now(a):
    cur = a["strategies"][0]
    k = cur["calendar"][date.today().month - 1]
    if k == "bare":
        return None, None
    c = cur["crops"][0 if k == "A" else 1]
    p = __import__("fieldshift.simulate", fromlist=["x"]).load_params().get(c["id"])
    return ({"name": c["name"], "heat_crit": p.heat_crit, "cold_crit": p.cold_crit} if p else None), c


@app.get("/api/fields/{fid}/forecast")
def field_forecast(fid: str, u=Depends(current_user)):
    return _forecast_for(_field(fid, u))


def _forecast_for(f: dict):
    a = run_field(f, Scenario())
    try:
        fc = forecast.fetch(f["lat"], f["lon"])
    except Exception as e:                                   # noqa: BLE001
        raise HTTPException(503, f"The weather forecast service could not be reached ({type(e).__name__}). Try again shortly.")
    crop, _ = _crop_now(a)
    ml = a.get("ml_detection") or {}
    gap = gdate = None
    if ml.get("reliable") and ml.get("recent"):
        last = ml["recent"][-1]
        gap, gdate = last["observed"] - last["expected"], f"{last['month']} {last['year']}"
    out = forecast.outlook(fc, a["climate"].get("normals"), {"crop": crop, "irrigation_mm": f.get("irrigation_mm", 0), "ndvi_gap": gap, "ndvi_date": gdate})
    return {**out, "source": fc["source"], "fetched_at": fc["fetched_at"], "field": {"id": f["id"], "name": f["name"], "lat": f["lat"], "lon": f["lon"]}}


def _profile_text(u):
    if not u:
        return ""
    p = u["profile"]
    bits = [f"Name: {u['name']}" if u["name"] else "", *[f"{k.replace('_', ' ')}: {v}" for k, v in p.items() if v not in ("", None)]]
    return "; ".join(b for b in bits if b)


@app.post("/api/assistant")
def ask(r: AssistantIn, x_ai_key: str | None = Header(default=None), x_ai_model: str | None = Header(default=None), u=Depends(current_user)):
    f = _field(r.field_id, u)
    place = None
    pname = geo.place_in(r.question)
    if r.use_here and r.here_lat is not None and r.here_lon is not None and not pname:     # "where I live": use the phone's or computer's own location
        place = {"name": "your location", "admin": None, "country": None, "lat": round(r.here_lat, 4), "lon": round(r.here_lon, 4)}
        f = {**f, "id": "place-" + f["id"], "name": "your location", "lat": place["lat"], "lon": place["lon"], "soil": "auto", "boundary": None, "soil_test": {}, "constraints": {}}
    elif pname and pname.lower() not in f["name"].lower():          # the farmer asked about somewhere else: look that place up and analyse it
        g = geo.geocode(pname)
        if not g:
            return {"mode": "template", "text": f"I could not find a place called '{pname}'. Try the district or town name, or add it as a field with the map.", "note": "Place lookup (Open-Meteo geocoding).", "as_of": None, "place": None}
        place = g
        f = {**f, "id": "place-" + f["id"], "name": g["name"], "lat": g["lat"], "lon": g["lon"], "soil": "auto", "boundary": None, "soil_test": {}, "constraints": {}}
    base = run_field(f, Scenario(priorities=r.priorities, offline=r.offline, water_availability=r.water_availability,
                                 rain_pct=r.rain_pct, temp_c=r.temp_c))
    rerun = lambda rain_pct=0.0: run_field(f, Scenario(rain_pct=rain_pct, temp_c=r.temp_c, offline=r.offline, priorities=r.priorities))  # noqa: E731
    fields = [x for x in (store.list_fields(u["id"]) if u else [f])]
    history = store.list_memory(u["id"], "chat", r.field_id, limit=8) if u and not place else []
    snaps = store.list_memory(u["id"], "snapshot", r.field_id, limit=4) if u and not place else []
    fc = None
    if assistant.wants_forecast(r.question):
        try:
            fc = _forecast_for(f)
        except HTTPException as e:
            fc = {"error": e.detail}
    user_ctx = {"voice": r.voice, "user": u, "profile_text": _profile_text(u), "fields": fields, "history": history, "snapshots": snaps, "all_snaps": store.list_memory(u["id"], "snapshot", limit=60) if u else [], "forecast": fc}
    out = assistant.answer(base, r.question, r.language, x_ai_key, rerun, user_ctx=user_ctx, model=x_ai_model)
    out["spoken"] = assistant.spoken(out["text"])
    if place:
        out["place"] = {**place, "note": f"Results are for {place['name']} ({place['lat']}, {place['lon']}). Soil is detected automatically and your field's crops and priorities are reused."}
    if u:
        store.add_memory(u["id"], "chat", {"role": "user", "text": r.question}, r.field_id)
        store.add_memory(u["id"], "chat", {"role": "assistant", "text": out["text"], "mode": out["mode"]}, r.field_id)
    return out


@app.post("/strategies")
def strategies(r: Request):
    cur = _validate_current(r.current) if r.current else None
    try:
        return service.analyse(r.lat, r.lon, r.soil, r.irrigation_mm, cur, r.priorities, r.rain_pct, r.temp_c, r.n_mc, 0, r.offline)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.post("/explain")
@app.post("/api/explain")
def explain(r: ExplainRequest, x_ai_key: str | None = Header(default=None), x_ai_model: str | None = Header(default=None)):
    needed = {"label", "crops", "scores", "uncertainty", "bare_months", "benefits", "risks_for_local_review"}
    if not needed <= set(r.strategy):
        raise HTTPException(422, "strategy must be a record returned by /strategies")
    return ai.explain(r.strategy, r.question, r.language, api_key=x_ai_key, model=x_ai_model)


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/app/")


_WEB = Path(__file__).parent / "web"
if _WEB.exists():
    app.mount("/app", StaticFiles(directory=str(_WEB), html=True), name="app")
