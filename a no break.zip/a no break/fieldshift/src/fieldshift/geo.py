"""Place names to coordinates (Open-Meteo geocoding, free, no key) so a farmer can ask about any place by name."""
from __future__ import annotations

import re

import requests

URL = "https://geocoding-api.open-meteo.com/v1/search"
_SKIP = {"my", "the", "this", "that", "me", "it", "now", "today", "tomorrow", "next", "week", "month", "season", "year", "rice", "wheat", "maize", "crop", "field", "farm", "planting",
         "plant", "sowing", "irrigation", "rain", "weather", "here", "there", "you", "your", "us", "them", "what", "when", "how", "why", "which", "kharif", "rabi", "zaid"}


def place_in(question: str) -> str | None:
    """Pull a place name out of 'can you check for howrah?', 'what can I plant in Pune now', 'weather at Nagpur'. None if there is none."""
    q = re.sub(r"[?!.,]+", " ", question or "")
    m = re.search(r"\b(?:for|in|at|near|around|of)\s+([A-Za-z][A-Za-zÀ-ɏ'\- ]{1,40}?)(?=\s+(?:now|today|tomorrow|this|next|please|and|or|to|with|if|during|in|for)\b|\s*$)", q, flags=re.I)
    if not m:
        return None
    words = [w for w in m.group(1).strip().split() if w]
    if not words or words[0].lower() in _SKIP or all(w.lower() in _SKIP for w in words):
        return None
    return " ".join(words)


def geocode(name: str, timeout: int = 8) -> dict | None:
    try:
        r = requests.get(URL, params={"name": name, "count": 1, "language": "en", "format": "json"}, timeout=timeout)
        r.raise_for_status()
        res = (r.json().get("results") or [None])[0]
    except Exception:       # noqa: BLE001 - network or parsing problems just mean "not found"
        return None
    if not res:
        return None
    return {"name": res["name"], "admin": res.get("admin1"), "country": res.get("country"), "lat": round(res["latitude"], 4), "lon": round(res["longitude"], 4)}
