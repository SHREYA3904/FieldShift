"""Layer 1, ingest clients. WRITTEN AGAINST DOCUMENTED RESPONSE FORMATS AND NOT YET RUN LIVE.
Run `python scripts/verify_sources.py` on a machine with internet first and fix anything it reports."""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import requests

CACHE = Path(os.environ.get("FIELDSHIFT_CACHE") or Path(__file__).resolve().parents[2] / "cache")   # always the project folder, whichever folder the app is started from
POWER_DAILY = "https://power.larc.nasa.gov/api/temporal/daily/point"
SOILGRIDS = "https://rest.isric.org/soilgrids/v2.0/properties/query"
ELEV = "https://api.open-meteo.com/v1/elevation"
PARAMS = "T2M_MAX,T2M_MIN,PRECTOTCORR,ALLSKY_SFC_SW_DWN,RH2M,WS2M,GWETROOT"


def _get(url, params, timeout=30, tries=3):
    err = None
    for k in range(tries):
        try:
            r = requests.get(url, params=params, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:                    # noqa: BLE001
            err = e
            time.sleep(1.5 ** k)
    raise err


def _cached(key, fn):
    CACHE.mkdir(exist_ok=True)
    f = CACHE / f"{key}.json"
    if f.exists():
        return json.loads(f.read_text())
    data = fn()
    f.write_text(json.dumps(data))
    return data


def result(source, fn):
    """Typed result: never raises, always says what happened."""
    try:
        return {"source": source, "ok": True, "error": None,
                "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "data": fn()}
    except Exception as e:                        # noqa: BLE001
        return {"source": source, "ok": False, "error": f"{type(e).__name__}: {e}", "fetched_at": None, "data": None}


def snap(x):
    """NASA POWER's own grid is about half a degree, so nearby farms get the same data: snap to 0.5 degrees. One download is then shared by every farm in that cell."""
    return round(round(float(x) * 2) / 2, 1)


def power_is_cached(lat, lon, start=2005, end=2025):
    lat, lon = snap(lat), snap(lon)
    return all((CACHE / f"pd_{lat}_{lon}_{y0}_{min(y0 + 4, end)}.json").exists() for y0 in range(start, end + 1, 5))


_BG: dict = {}


def background(key, fn):
    """Start fn once in the background and give back its Future. A second caller for the same key shares it, so a slow download is never started twice."""
    from concurrent.futures import ThreadPoolExecutor
    f = _BG.get(key)
    if f is None or (f.done() and not f.result().get("ok")):
        _BG.setdefault("_ex", ThreadPoolExecutor(max_workers=6))
        f = _BG["_ex"].submit(fn)
        _BG[key] = f
    return f


def wait(fut, seconds, source):
    """The result of a background download, or a typed 'too slow' result. The download keeps going and fills the disk cache for next time."""
    from concurrent.futures import TimeoutError as _T
    try:
        return fut.result(timeout=max(0.2, seconds))
    except _T:
        return {"source": source, "ok": False, "error": f"still downloading after {seconds:.0f} s; skipped for now", "fetched_at": None, "data": None}


def power_daily(lat, lon, start=2005, end=2025):
    """Daily NASA POWER arrays. Five-year chunks, downloaded at the same time (about five times faster), and kept on disk. Missing values (-999) become NaN."""
    from concurrent.futures import ThreadPoolExecutor
    lat, lon = snap(lat), snap(lon)
    spans = [(y0, min(y0 + 4, end)) for y0 in range(start, end + 1, 5)]

    def one(span):
        y0, y1 = span
        return _cached(f"pd_{lat}_{lon}_{y0}_{y1}", lambda: _get(POWER_DAILY, {
            "parameters": PARAMS, "community": "AG", "longitude": lon, "latitude": lat,
            "start": f"{y0}0101", "end": f"{y1}1231", "format": "JSON"}, timeout=25, tries=2))
    with ThreadPoolExecutor(max_workers=5) as ex:
        chunks = list(ex.map(one, spans))
    dates, cols = [], {k: [] for k in PARAMS.split(",")}
    for c in chunks:
        par = c["properties"]["parameter"]
        days = sorted(par["T2M_MAX"])
        dates += days
        for k in cols:
            cols[k] += [par[k][d] for d in days]
    out = {k: np.array(v, float) for k, v in cols.items()}
    for v in out.values():
        v[v <= -990] = np.nan
    out["dates"] = np.array([f"{d[:4]}-{d[4:6]}-{d[6:]}" for d in dates], "datetime64[D]")
    return out


OPENMETEO_ARCHIVE = "https://archive-api.open-meteo.com/v1/archive"


def openmeteo_daily(lat, lon, start=2005, end=2025):
    """Backup daily weather (ERA5 reanalysis through Open-Meteo), used only when NASA POWER cannot be reached. Same array layout as power_daily."""
    lat, lon = round(lat, 2), round(lon, 2)
    j = _cached(f"om_{lat}_{lon}_{start}_{end}", lambda: _get(OPENMETEO_ARCHIVE, {
        "latitude": lat, "longitude": lon, "start_date": f"{start}-01-01", "end_date": f"{end}-12-31",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum", "timezone": "UTC"}, timeout=30, tries=2))
    d = j["daily"]
    def col(k):
        return np.array([np.nan if v is None else v for v in d[k]], float)
    return {"T2M_MAX": col("temperature_2m_max"), "T2M_MIN": col("temperature_2m_min"), "PRECTOTCORR": col("precipitation_sum"),
            "dates": np.array(d["time"], "datetime64[D]")}


def fill_gaps(a, max_gap=5):
    """Linear fill of short gaps only. Returns (filled array, number of days filled)."""
    a = np.array(a, float)
    bad = np.isnan(a)
    n_filled = 0
    i = 0
    while i < len(a):
        if bad[i]:
            j = i
            while j < len(a) and bad[j]:
                j += 1
            if j - i <= max_gap and i > 0 and j < len(a):
                a[i:j] = np.interp(range(i, j), [i - 1, j], [a[i - 1], a[j]])
                n_filled += j - i
            i = j
        else:
            i += 1
    return a, n_filled


def soilgrids(lat, lon):
    """Mean sand/clay/silt (%) and organic carbon for 0-30 cm. SoilGrids reports g/kg for texture."""
    d = _cached(f"sg_{round(lat,3)}_{round(lon,3)}", lambda: _get(SOILGRIDS, [
        ("lon", lon), ("lat", lat), ("property", "sand"), ("property", "clay"), ("property", "silt"),
        ("property", "soc"), ("depth", "0-5cm"), ("depth", "5-15cm"), ("depth", "15-30cm"), ("value", "mean")], timeout=15, tries=2))
    out = {}
    for layer in d["properties"]["layers"]:
        vals = [dep["values"]["mean"] for dep in layer["depths"] if dep["values"]["mean"] is not None]
        if vals:
            out[layer["name"]] = float(np.mean(vals)) / (10 if layer["name"] in ("sand", "clay", "silt") else 1)
    return out


def elevation(lat, lon):
    return float(_get(ELEV, {"latitude": lat, "longitude": lon}, timeout=10)["elevation"][0])


MODIS = "https://modis.ornl.gov/rst/api/v1/MOD13Q1"


def modis_ndvi(lat, lon, years=15, workers=8):
    """MODIS 16-day NDVI for the last `years` years from ORNL DAAC. Returns {"dates": datetime64 array, "ndvi": array}.
    NOT VERIFIED beyond the top-level keys seen on a real call (subset, band, scale ...): check scripts/verify_sources.py."""
    from concurrent.futures import ThreadPoolExecutor
    hdr = {"Accept": "application/json"}
    lat, lon = round(lat, 3), round(lon, 3)
    d = _cached(f"md_dates_{lat}_{lon}", lambda: requests.get(f"{MODIS}/dates", params={"latitude": lat, "longitude": lon},
                                                              headers=hdr, timeout=15).json())
    items = d["dates"]
    cut = str(np.datetime64("today", "Y") - years)
    items = [x for x in items if x["calendar_date"][:4] >= cut]
    chunks = [items[i:i + 10] for i in range(0, len(items), 10)]

    def one(ch):
        key = f"md_{lat}_{lon}_{ch[0]['modis_date']}"
        return _cached(key, lambda: requests.get(f"{MODIS}/subset", params={
            "latitude": lat, "longitude": lon, "band": "250m_16_days_NDVI", "startDate": ch[0]["modis_date"],
            "endDate": ch[-1]["modis_date"], "kmAboveBelow": 0, "kmLeftRight": 0}, headers=hdr, timeout=25).json())

    with ThreadPoolExecutor(workers) as ex:
        parts = list(ex.map(one, chunks))
    dates, vals = [], []
    for p in parts:
        scale = float(p.get("scale", 0.0001))
        for row in p["subset"]:
            v = row["data"][0] if row["data"] else None
            dates.append(row["calendar_date"][:10])
            vals.append(np.nan if v is None or v <= -2000 else v * scale)
    return {"dates": np.array(dates, "datetime64[D]"), "ndvi": np.array(vals, float)}
