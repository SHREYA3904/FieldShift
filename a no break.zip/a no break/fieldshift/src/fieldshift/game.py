"""Season Challenge: replay a REAL past growing season from the field's own NASA POWER weather, one week at a time.

The player picks a crop and a sowing date, then decides when to irrigate with a limited water budget. The weather and the soil-water
bookkeeping are the same as in the rotation model (simulate.simulate_season); the only difference is that irrigation is chosen by the player.
The year is hidden until the end, and the server only sends days that have already happened, so the future cannot be peeked at.
This is a teaching game: the score is a transparent index, not a yield forecast.
"""
from __future__ import annotations

import numpy as np

from . import datapack, ingest
from . import pipeline as P
from . import simulate as S

DOSE_MM = 25.0
BUDGET_MM = 150.0
_W: dict = {}


def weather(lat: float, lon: float) -> dict:
    key = (ingest.snap(lat), ingest.snap(lon))
    if key in _W:
        return _W[key]
    pr = P.Sources().power(lat, lon)
    if not pr["ok"]:                                   # NASA POWER unreachable: say so, and use the backup reanalysis instead of leaving the farmer with no game
        om = ingest.result("Open-Meteo archive (ERA5 reanalysis)", lambda: ingest.openmeteo_daily(lat, lon))
        if not om["ok"]:
            raise RuntimeError("Weather data could not be fetched (NASA POWER and the backup source both failed), so there is no season to replay right now. Check the internet connection of the server and try again.")
        pr = {**om, "backup": True}
    dates, tmax, tmin, rain, _ = P._harmonise(pr["data"])
    doy = (dates - dates.astype("datetime64[Y]")).astype(int)
    et0 = S.hargreaves_et0(tmax, tmin, lat, doy + 1)
    ys = sorted({int(str(d)[:4]) for d in dates})
    full = [y for y in ys if (dates[dates.astype("datetime64[Y]") == np.datetime64(str(y), "Y")].size >= 365)]
    out = {"dates": dates, "tmax": tmax, "tmin": tmin, "rain": rain, "et0": et0, "years": full, "bundled": bool(pr.get("bundled")), "source": pr.get("source", "NASA POWER daily") if not pr.get("bundled") else "NASA POWER daily (supplied file)"}
    if pr.get("backup"):                               # stand-in weather is not remembered: the next play picks up NASA POWER as soon as its download has finished
        return out
    if len(_W) > 16:
        _W.pop(next(iter(_W)))
    _W[key] = out
    return out


def awc_for(f: dict) -> tuple[float, str]:
    soil = f.get("soil", "auto")
    if isinstance(soil, str) and soil.startswith("ssurgo:"):
        p = datapack.soil_profile(soil.split(":", 1)[1])
        if p and p.get("usable") and p.get("awc_mm_per_m"):
            return float(p["awc_mm_per_m"]), "SSURGO"
    if soil in P.TEXTURE:
        return S.awc_from_texture(*P.TEXTURE[soil]), "your soil type"
    r = ingest.wait(ingest.background(("soil", round(f["lat"], 3), round(f["lon"], 3)), lambda: P.Sources().soil(f["lat"], f["lon"])), 6, "SoilGrids")      # soil may take 6 s at most
    if r["ok"] and {"sand", "clay"} <= set(r["data"] or {}):
        return S.awc_from_texture(r["data"]["sand"], r["data"]["clay"]), "SoilGrids"
    return S.awc_from_texture(*P.TEXTURE["loam"]), "assumed loam"


def _start_idx(w: dict, year: int, month: int, day: int):
    try:
        t = np.datetime64(f"{year:04d}-{month:02d}-{day:02d}")
    except ValueError:
        return None
    i = int(np.searchsorted(w["dates"], t))
    return i if i < len(w["dates"]) and w["dates"][i] == t else None


def playable_cases(w: dict, p: S.CropParams, awc: float, month: int, day: int) -> list[int]:
    """Years in which this crop, sown on this date, can finish before the data ends. Each is a 'case' the server keeps secret."""
    out = []
    for y in w["years"]:
        i = _start_idx(w, y, month, day)
        if i is not None and S.simulate_season(w["tmax"], w["tmin"], w["rain"], w["et0"], i, p, awc, 0.0) is not None:
            out.append(y)
    return out


MULCH_CUT = 0.10      # game rule: straw mulch on the soil lowers the crop's water use by about a tenth for the rest of the season
COVERS, SCOUTS = 2, 4  # frost-cover nights and look-ahead peeks the player may use


def run(w: dict, p: S.CropParams, awc: float, start: int, doses: dict[int, float] | None, auto_mm: float = 0.0, upto: int | None = None,
        covers: frozenset = frozenset(), mulch_day: int | None = None) -> dict:
    """Day-by-day season. doses = {days since sowing: mm} chosen by the player; with doses=None the model's own automatic irrigation (auto_mm budget) is used."""
    tmax, tmin, rain, et0 = w["tmax"], w["tmin"], w["rain"], w["et0"]
    n = len(tmax)
    taw = awc * p.root_m
    raw = p.p_dep * taw
    dep = 0.3 * taw
    gdd = 0.0
    left = auto_mm if doses is None else 0.0
    etc_sum = eta_sum = used = 0.0
    heat = cold = 0
    days, finished = [], False
    i = start
    while i < n and i - start < 300:
        d = i - start
        if upto is not None and d >= upto:
            break
        t_mean = (min(tmax[i], p.tcap) + max(tmin[i], p.tbase)) / 2
        gdd += max(0.0, t_mean - p.tbase)
        frac = gdd / p.gdd_total
        kc = S.stage_kc(min(frac, 1.0), p)
        etc = kc * et0[i] * (1 - MULCH_CUT if mulch_day is not None and d >= mulch_day else 1.0)
        ks = 1.0 if dep <= raw else max(0.0, (taw - dep) / (taw - raw))
        dose = 0.0
        if doses is None:
            if ks < 1.0 and left > 0:
                dose = min(left, dep)
                left -= dose
        elif d in doses:
            dose = min(doses[d], dep)
        if dose:
            dep -= dose
            used += dose
            ks = 1.0 if dep <= raw else max(0.0, (taw - dep) / (taw - raw))
        eta = ks * etc
        dep = dep - rain[i] + eta
        if dep < 0:
            dep = 0.0
        dep = min(dep, taw)
        etc_sum += etc
        eta_sum += eta
        if 0.4 <= frac < 0.8:
            heat += int(tmax[i] > p.heat_crit)
        frost = bool(tmin[i] < p.cold_crit)
        saved = frost and d in covers                     # a frost cover only helps on a night that really is too cold
        cold += int(frost and not saved)
        days.append({"d": d, "tmax": round(float(tmax[i]), 1), "tmin": round(float(tmin[i]), 1), "rain": round(float(rain[i]), 1), "water": round(float(1 - dep / taw), 3),
                     "stress": round(float(1 - ks), 3), "growth": round(float(min(frac, 1.0)), 3), "irrigated": round(float(dose), 1), "covered": bool(d in covers), "saved": bool(saved), "mulched": bool(mulch_day is not None and d >= mulch_day)})
        i += 1
        if frac >= 1.0:
            finished = True
            break
    stress = float(1 - eta_sum / etc_sum) if etc_sum > 0 else 0.0
    return {"days": days, "finished": finished, "water_stress": stress, "heat_days": heat, "cold_days": cold, "irrigation_used_mm": round(used, 1), "score": score(stress, heat, cold)}


def score(stress: float, heat: int, cold: int) -> int:
    """Game score 0 to 100: share of the crop's water need met, less 5% per hot day in flowering (max 50%) and 10% per frost day (max 50%)."""
    return int(round(100 * (1 - stress) * (1 - min(0.5, 0.05 * heat)) * (1 - min(0.5, 0.10 * cold))))


def season_facts(w: dict, start: int, length: int) -> dict:
    sl = slice(start, start + length)
    return {"rain_mm": round(float(w["rain"][sl].sum()), 0), "hot_days_over_35": int((w["tmax"][sl] > 35).sum()), "mean_tmax": round(float(w["tmax"][sl].mean()), 1)}


# Orchard and vegetable crops that are not in the rotation model. Kc and depletion fractions from FAO-56 Tables 12 and 22
# (apple, cherry, pear: no ground cover); thermal values are typical, flagged as estimates.
_EXTRA = [
    dict(id="apple", name="Apple (orchard)", family="orchard", tbase=5, tcap=30, gdd_total=2800, kc_ini=0.45, kc_mid=0.95, kc_end=0.70, root_m=1.5, p_dep=0.50, heat_crit=35, cold_crit=-2),
    dict(id="grape", name="Grapes", family="orchard", tbase=10, tcap=32, gdd_total=2400, kc_ini=0.30, kc_mid=0.70, kc_end=0.45, root_m=1.5, p_dep=0.35, heat_crit=38, cold_crit=-1),
    dict(id="tomato", name="Tomato", family="vegetable", tbase=10, tcap=30, gdd_total=1500, kc_ini=0.60, kc_mid=1.15, kc_end=0.80, root_m=1.0, p_dep=0.40, heat_crit=35, cold_crit=2),
]


def crops():
    ps = dict(S.load_params())
    base = ps["wheat"]
    for c in _EXTRA:
        d = {k: getattr(base, k) for k in base.__dataclass_fields__}
        d.update(c, confidence="estimate", sources=("https://www.fao.org/4/x0490e/x0490e0b.htm (FAO-56 Tables 12 and 22)",))
        ps[c["id"]] = type(base)(**d)
    for k in ("cover_legume", "red_clover", "vetch", "sainfoin"):
        ps.pop(k, None)
    return ps


def outlook(w, p, awc, month, day, n_years):
    """Run the crop through every past year. Verdict from the share of years it finishes and its typical score."""
    cases = playable_cases(w, p, awc, month, day)
    if len(cases) < 3:
        return {"verdict": "poor", "headline": f"{p.name} sown then rarely finishes here", "why": "The season is too cold or too short in most past years. Try another month, or another crop.",
                "years_tested": n_years, "years_finished": len(cases)}
    auto, rain, heat, cold, used, lens = [], [], [], [], [], []
    for y in cases:
        i = _start_idx(w, y, month, day)
        a = run(w, p, awc, i, None, BUDGET_MM)
        r = run(w, p, awc, i, {})
        lens.append(len(a["days"])); auto.append(a["score"]); rain.append(r["score"]); heat.append(a["heat_days"]); cold.append(a["cold_days"]); used.append(a["irrigation_used_mm"])
    med = lambda v: int(sorted(v)[len(v) // 2])
    share = len(cases) / max(1, n_years)
    frost_years = sum(1 for c in cold if c > 0) / len(cases)
    m = med(auto)
    verdict = "good" if m >= 80 and share >= 0.7 and frost_years < 0.3 else "poor" if m < 55 or share < 0.4 else "risky"
    why = []
    why.append(f"It finished in {len(cases)} of {n_years} past years.")
    why.append(f"With smart watering the typical score was {m}/100; on rain alone {med(rain)}/100.")
    if frost_years >= 0.15:
        why.append(f"Frost hit it in {round(frost_years * 100)}% of years.")
    if med(heat) >= 3:
        why.append(f"A typical season had {med(heat)} very hot days.")
    if med(used) > 0:
        why.append(f"Smart watering used about {med(used)} mm.")
    head = {"good": "Good choice for your location", "risky": "Possible, but risky", "poor": "Poor choice for your location"}[verdict]
    return {"verdict": verdict, "headline": head, "why": " ".join(why), "years_tested": n_years, "years_finished": len(cases), "season_days": med(lens), "median_auto": m, "median_rainfed": med(rain),
            "note": "Based on your field's real past weather, not a forecast or a yield guarantee."}


_RANK = {"good": 2, "risky": 1, "poor": 0}


def recommend(w, ps, awc, crop, month, day):
    """Best sowing month for the chosen crop, and the best few crops for the chosen month, all replayed on this spot's real weather."""
    n = len(w["years"])
    def one(c, m):
        o = outlook(w, ps[c], awc, m, day, n)
        share = o.get("years_finished", 0) / max(1, n)
        return {"crop": c, "name": ps[c].name, "month": m, "verdict": o["verdict"], "score": o.get("median_auto", 0), "finish_share": round(share, 2), "season_days": o.get("season_days", 0)}
    key = lambda r: (_RANK[r["verdict"]], r["score"] * r["finish_share"])
    months = sorted((one(crop, m) for m in range(1, 13)), key=key, reverse=True)
    others = sorted((one(c, month) for c in ps if c != crop), key=key, reverse=True)
    return {"chosen": one(crop, month), "best_months": months[:3], "other_crops": others[:3], "years_tested": n,
            "note": "Replayed on this spot's real past weather. A guide, not a yield guarantee."}
