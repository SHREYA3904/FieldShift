"""Field Shift: explainable crop-rotation decision support from NASA Earth observations."""
__version__ = "0.1.0"
