"""FAO EcoCrop suitability: does this place's climate and soil sit inside each crop's published envelope?

EcoCrop gives, for each crop, an optimal range and an absolute range for temperature, annual rainfall and soil pH, plus texture and
drainage classes and the length of the crop cycle. Here each factor is scored 0 to 1 (1 inside the optimal range, falling to 0 at the
absolute limit) and the overall score is the weakest factor, which is how a limiting factor works. It is a climate-and-soil envelope check,
not a yield forecast, and it is independent of the water-balance simulation, so the two can be compared.
"""
from __future__ import annotations

import math

from . import datapack as D

MONTHS = D.MONTHS


def _trap(x, amin, omin, omax, amax):
    """0 at/below the absolute minimum, 1 across the optimal range, 0 at/above the absolute maximum, linear in between."""
    if any(isinstance(v, float) and math.isnan(v) for v in (amin, omin, omax, amax)) or x is None:
        return None
    if x <= amin or x >= amax:
        return 0.0
    if omin <= x <= omax:
        return 1.0
    return (x - amin) / (omin - amin) if x < omin else (amax - x) / (amax - omax)


def _cls(value: str | None, opt: list[str], absl: list[str]):
    if value is None or (not opt and not absl):
        return None
    if "wide" in opt:
        return 1.0
    if value in opt:
        return 1.0
    if value in absl or "wide" in absl:
        return 0.5
    return 0.0


def _drain(value: str | None, opt: str | None, absl: str | None):
    if value is None or (not opt and not absl):
        return None
    if opt and value in opt:
        return 1.0
    if absl and value in absl:
        return 0.5
    return 0.0


def assess(cid: str, monthly_t: list[float], water_mm: float, ph: float | None = None, sand: float | None = None, clay: float | None = None,
           drainage: str | None = None) -> dict | None:
    e = D.ecocrop().get(cid)
    if e is None:
        return None
    cyc = e["cycle_days"][0]
    n = max(1, min(12, int(math.ceil((cyc if not math.isnan(cyc) else 120) / 30.4))))
    ta, to = e["t_abs"], e["t_opt"]
    mscore = [_trap(t, ta[0], to[0], to[1], ta[1]) for t in monthly_t]
    by_sow = []
    for m in range(12):
        win = [mscore[(m + k) % 12] for k in range(n)]
        by_sow.append(round(sum(win) / n, 3) if all(w is not None for w in win) else None)
    best_t = max([s for s in by_sow if s is not None], default=None)
    factors = {"temperature": best_t, "rainfall": _trap(water_mm, e["rain_abs"][0], e["rain_opt"][0], e["rain_opt"][1], e["rain_abs"][1]),
               "ph": _trap(ph, e["ph_abs"][0], e["ph_opt"][0], e["ph_opt"][1], e["ph_abs"][1]) if ph is not None else None,
               "texture": _cls(D.texture_class(sand, clay), e["texture_opt"], e["texture_abs"]) if sand is not None and clay is not None else None,
               "drainage": _drain(D.drainage_eco(drainage), e["drainage_opt"], e["drainage_abs"])}
    known = {k: v for k, v in factors.items() if v is not None}
    unknown = [k for k, v in factors.items() if v is None] + ["salinity", "fertility", "soil depth"]
    limiting = min(known, key=known.get) if known else None
    score = known[limiting] if limiting else None
    why = []
    if factors["rainfall"] is not None and factors["rainfall"] < 1:
        lo, hi = e["rain_opt"]
        why.append(f"water supply {water_mm:.0f} mm/year (rain plus irrigation) is {'below' if water_mm < lo else 'above'} the optimal {lo:.0f} to {hi:.0f} mm")
    if factors["temperature"] is not None and factors["temperature"] < 1:
        why.append(f"temperatures during a {n}-month cycle only partly fall inside the optimal {to[0]:.0f} to {to[1]:.0f} C")
    if factors["ph"] is not None and factors["ph"] < 1:
        why.append(f"soil pH {ph:.1f} is outside the optimal {e['ph_opt'][0]:g} to {e['ph_opt'][1]:g}" + (" and beyond the absolute limit" if factors["ph"] == 0 else ""))
    if factors["texture"] is not None and factors["texture"] < 1:
        why.append(f"{D.texture_class(sand, clay)} soil texture is not in the crop's optimal classes ({', '.join(e['texture_opt']) or 'n/a'})")
    if factors["drainage"] is not None and factors["drainage"] < 1:
        why.append("drainage class is not the crop's optimal one")
    return {"crop_id": cid, "name": e["common_name"], "scientific_name": e["scientific_name"], "score": None if score is None else round(score, 2),
            "limiting_factor": limiting, "factors": {k: (None if v is None else round(v, 2)) for k, v in factors.items()}, "cycle_months_used": n,
            "cycle_days": e["cycle_days"], "best_sow_months": [MONTHS[m] for m in range(12) if by_sow[m] is not None and best_t and by_sow[m] >= 0.9 * best_t and best_t > 0],
            "temperature_by_sow_month": by_sow, "not_assessed": unknown, "reasons": why, "url": e["url"]}


def assess_all(monthly_t, water_mm, ph=None, sand=None, clay=None, drainage=None) -> list[dict]:
    out = [a for cid in D.ecocrop() if (a := assess(cid, monthly_t, water_mm, ph, sand, clay, drainage))]
    out.sort(key=lambda a: -(a["score"] if a["score"] is not None else -1))
    return out
