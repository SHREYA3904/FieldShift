import time

import numpy as np

from fieldshift import ingest, pipeline as P


def _arrays():
    d = np.arange(np.datetime64("2005-01-01"), np.datetime64("2026-01-01"))
    n = len(d)
    return {"dates": d, "T2M_MAX": np.full(n, 30.0), "T2M_MIN": np.full(n, 20.0), "PRECTOTCORR": np.full(n, 2.0), "GWETROOT": np.full(n, 0.4)}


def test_slow_nasa_never_blocks_for_minutes_and_backup_is_labelled(monkeypatch):
    monkeypatch.setenv("FIELDSHIFT_POWER_WAIT", "1")
    monkeypatch.setattr(ingest, "_BG", {})
    monkeypatch.setattr(ingest, "power_daily", lambda *a, **k: (time.sleep(5), _arrays())[1])
    monkeypatch.setattr(ingest, "openmeteo_daily", lambda *a, **k: _arrays())
    t = time.time()
    r = P.Sources().power(22.58, 88.34)
    assert time.time() - t < 4
    assert r["ok"] and r.get("backup") and "Open-Meteo" in r["source"]
    time.sleep(5)                                                       # the NASA download finishes in the background...
    r2 = P.Sources().power(22.58, 88.34)
    assert r2["ok"] and not r2.get("backup") and r2["source"] == "NASA POWER daily"   # ...and the next load uses it


def test_wait_skips_a_slow_source():
    from concurrent.futures import ThreadPoolExecutor
    f = ThreadPoolExecutor(1).submit(lambda: (time.sleep(3), {"ok": True})[1])
    r = ingest.wait(f, 0.3, "X")
    assert not r["ok"] and "still downloading" in r["error"]
