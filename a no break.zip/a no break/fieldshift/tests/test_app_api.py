import pytest
from fastapi.testclient import TestClient

from fieldshift import pipeline, store
from fieldshift.api import app, _CACHE
from test_pipeline_v2 import Fake, fake_daily


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(store, "DB", str(tmp_path / "t.db"))
    monkeypatch.setattr(pipeline, "Sources", lambda: Fake(fake_daily()))
    _CACHE.clear()
    return TestClient(app)


def signin(c, email="farmer@example.com", name="Asha Devi", pw="field-pass-1"):
    v = c.post("/api/auth/signup", json={"email": email, "password": pw, "name": name})
    assert v.status_code == 200, v.text
    return v.json()


def test_demo_field_and_crud(client):
    assert client.post("/api/fields", json={}).status_code == 401
    signin(client)
    fs = client.get("/api/fields").json()
    assert fs[0]["id"] == "demo-field"
    body = {k: fs[0][k] for k in ("farm", "name", "lat", "lon", "soil", "current", "irrigation_mm")}
    body.update(name="My plot", lat=10.5, lon=76.2)
    new = client.post("/api/fields", json=body).json()
    assert client.get(f"/api/fields/{new['id']}").json()["name"] == "My plot"
    body["name"] = "Renamed"
    assert client.put(f"/api/fields/{new['id']}", json=body).json()["name"] == "Renamed"
    assert client.delete(f"/api/fields/{new['id']}").status_code == 200
    assert client.delete("/api/fields/demo-field").status_code == 400
    assert client.get(f"/api/fields/{new['id']}").status_code == 404
    bad = dict(body, current=["rice", "rice"])
    assert client.post("/api/fields", json=bad).status_code == 422


def test_analyse_has_vulnerability_planner_data_and_scenarios_change_results(client):
    a = client.post("/api/fields/demo-field/analyse", json={}).json()
    v = a["vulnerability"]
    assert 0 <= v["overall"] <= 100 and v["category"] in ("low", "moderate", "high") and v["indicators"]
    assert any("organic carbon" in i["evidence"] for i in v["indicators"])      # demo field has a soil test
    assert {d["id"]: d["status"] for d in a["datasets"]}["smap"] == "not_connected"
    assert "interventions" in a["strategies"][0]
    dry = client.post("/api/fields/demo-field/analyse", json={"rain_pct": -30, "temp_c": 3}).json()
    assert dry["scenario"]["hypothetical"] is True
    assert dry["strategies"][0]["scores"]["irrigation_need_mm_per_year"] >= a["strategies"][0]["scores"]["irrigation_need_mm_per_year"]
    heavy = client.post("/api/fields/demo-field/analyse", json={"priorities": {"water": 5, "nfix": 0, "erosion": 0, "om": 0, "forage": 0, "market": 0}}).json()
    assert heavy["strategies"][1]["scores"]["priority_match"] != a["strategies"][1]["scores"]["priority_match"] or heavy["strategies"][1]["label"] != a["strategies"][1]["label"]


def test_assistant_answers_from_results_and_reruns_scenarios(client):
    signin(client)
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "What happens if rainfall falls by 15%?"}).json()
    assert r["mode"] == "template" and "-15%" in r["text"] and "hypothetical" in r["text"]
    m = client.post("/api/assistant", json={"field_id": "demo-field", "question": "What information is missing from this assessment?"}).json()
    assert "missing" in m["text"].lower() or "estimates" in m["text"].lower()
    w = client.post("/api/assistant", json={"field_id": "demo-field", "question": "Why is my current crop vulnerable?"}).json()
    assert "out of 100" in w["text"]


def test_auth_rules_and_isolation(client):
    assert client.get("/api/me").json()["user"] is None
    assert client.post("/api/auth/signup", json={"email": "nope", "password": "longenough1"}).status_code == 400
    assert client.post("/api/auth/signup", json={"email": "a@example.com", "password": "short"}).status_code == 400
    assert client.post("/api/auth/signup", json={"email": "a@example.com", "password": "password"}).status_code == 400
    ok = client.post("/api/auth/signup", json={"email": "A@Example.com", "password": "correct-horse", "name": "Ann"})
    assert ok.status_code == 200 and ok.json()["user"]["email"] == "a@example.com"
    assert "pw" not in ok.json()["user"] and "password" not in str(ok.json())
    assert client.post("/api/auth/signup", json={"email": "a@example.com", "password": "another-pass1"}).status_code == 409
    me = client.get("/api/me").json()["user"]
    assert me["name"] == "Ann"
    client.put("/api/me", json={"profile": {"region": "West Bengal", "experience": "beginner", "evil": "x"}})
    assert client.get("/api/me").json()["user"]["profile"] == {"region": "West Bengal", "experience": "beginner"}
    base = {k: v for k, v in client.get("/api/fields").json()[0].items() if k in ("farm", "name", "lat", "lon", "soil", "current", "irrigation_mm")}
    mine = client.post("/api/fields", json=base).json()
    other = TestClient(app)
    signin(other, "b@example.com", "Bob")
    assert [f["id"] for f in other.get("/api/fields").json()] == ["demo-field"]
    assert other.get(f"/api/fields/{mine['id']}").status_code == 404
    assert other.delete(f"/api/fields/{mine['id']}").status_code == 400
    client.post("/api/auth/logout")
    assert client.get("/api/me").json()["user"] is None
    assert client.get("/api/fields").json()[0]["id"] == "demo-field" and len(client.get("/api/fields").json()) == 1
    back = client.post("/api/auth/login", json={"email": "a@example.com", "password": "correct-horse"})
    assert back.status_code == 200
    assert mine["id"] in [f["id"] for f in client.get("/api/fields").json()]      # the data is remembered across sessions


def test_login_failures_lock_out(client):
    from fieldshift import auth
    auth._FAILS.clear()
    signin(client, "c@example.com", "Cy", "right-pass-1")
    client.post("/api/auth/logout")
    for _ in range(5):
        assert client.post("/api/auth/login", json={"email": "c@example.com", "password": "wrong-pass-1"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "c@example.com", "password": "right-pass-1"}).status_code == 429
    auth._FAILS.clear()
    assert client.post("/api/auth/login", json={"email": "nobody@example.com", "password": "whatever-1"}).status_code == 401


def test_gemini_call_shape_and_number_guard(client, monkeypatch):
    import requests
    from fieldshift import ai
    seen = {}

    class R:
        status_code, ok, text = 200, True, ""

        def __init__(self, t): self.t = t
        def json(self): return {"candidates": [{"content": {"parts": [{"text": self.t}]}}]}

    def fake_post(url, json=None, headers=None, timeout=None):
        seen.update(url=url, body=json, headers=headers)
        return R(seen.get("reply", "A short plain answer."))
    monkeypatch.setattr(requests, "post", fake_post)
    signin(client, "g@example.com", "Gita")
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "Why this rotation?"}, headers={"X-AI-Key": "AIza-test", "X-AI-Model": "gemini-2.5-flash"}).json()
    assert r["mode"] == "ai" and "Gemini" in r["note"]
    assert "gemini-2.5-flash:generateContent" in seen["url"] and seen["headers"]["x-goog-api-key"] == "AIza-test"
    assert seen["body"]["contents"][-1]["role"] == "user" and "systemInstruction" in seen["body"]
    seen["reply"] = "It will give you 9999 kg of extra yield."
    bad = client.post("/api/assistant", json={"field_id": "demo-field", "question": "Why this rotation?"}, headers={"X-AI-Key": "AIza-test"}).json()
    assert bad["mode"] == "template" and "numbers not in your results" in bad["note"]
    off = client.post("/api/assistant", json={"field_id": "demo-field", "question": "Why this rotation?"}).json()
    assert off["mode"] == "template" and "Gemini" in off["note"]


def _fake_forecast(hot=True, dry=True):
    from datetime import date, timedelta
    d0 = date.today()
    return {"source": "test", "fetched_at": "t", "days": [{"date": (d0 + timedelta(days=i)).isoformat(), "tmax": 40.0 if hot and i in (2, 3, 4) else 30.0, "tmin": 22.0,
                                                           "rain_mm": 0.0 if dry else 12.0, "rain_prob": 10, "et0_mm": 5.0, "wind_kmh": 10} for i in range(16)]}


def test_forecast_outlook_rules_and_endpoint(client, monkeypatch):
    from fieldshift import forecast
    n = {"tmax": [32.0] * 366, "tmin": [20.0] * 366, "rain": [3.0] * 366, "tmax_p90": [36.0] * 366}
    out = forecast.outlook(_fake_forecast(), n, {"crop": {"name": "Rice", "heat_crit": 35.0, "cold_crit": 10.0}, "irrigation_mm": 250, "ndvi_gap": -0.2, "ndvi_date": "Oct 2026"})
    ids = [a["id"] for a in out["actions"]]
    assert out["level"] == "alert" and ids[0] == "combined" and "heat" in ids and "dry" in ids
    calm = forecast.outlook(_fake_forecast(hot=False, dry=False), n, {"crop": {"name": "Rice", "heat_crit": 35.0, "cold_crit": 10.0}, "ndvi_gap": 0.0, "ndvi_date": "x"})
    assert calm["level"] in ("calm", "watch") and "heat" not in [a["id"] for a in calm["actions"]]
    monkeypatch.setattr(forecast, "fetch", lambda lat, lon, days=16: _fake_forecast())
    j = client.get("/api/fields/demo-field/forecast").json()
    assert j["stats"]["rain_next16_mm"] == 0 and j["days"][0]["lead_confidence"] == "high" and j["days"][10]["lead_confidence"] == "low"
    a = client.post("/api/fields/demo-field/analyse", json={}).json()
    assert len(a["climate"]["normals"]["tmax"]) == 366


def test_assistant_is_personal_and_remembers(client, monkeypatch):
    from fieldshift import forecast
    monkeypatch.setattr(forecast, "fetch", lambda lat, lon, days=16: _fake_forecast())
    signin(client, "d@example.com", "Dev Kumar")
    base = {k: v for k, v in client.get("/api/fields").json()[0].items() if k in ("farm", "name", "lat", "lon", "soil", "current", "irrigation_mm")}
    f = client.post("/api/fields", json={**base, "name": "North plot"}).json()
    client.post(f"/api/fields/{f['id']}/analyse", json={})
    hi = client.post("/api/assistant", json={"field_id": f["id"], "question": "hii"}).json()
    assert "Dev" in hi["text"] and "North plot" in hi["text"]
    w = client.post("/api/assistant", json={"field_id": f["id"], "question": "What is the weather forecast this week?"}).json()
    assert "Open-Meteo" in w["text"] and "Outlook level" in w["text"]
    mem = client.get("/api/me/memory").json()
    assert len(mem["chat"]) == 4 and len(mem["snapshots"]) == 1
    fl = client.post("/api/assistant", json={"field_id": f["id"], "question": "show my fields"}).json()
    assert "North plot" in fl["text"] and "vulnerability" in fl["text"]
    odd = client.post("/api/assistant", json={"field_id": f["id"], "question": "banana smoothie recipe"}).json()
    assert "could not tell" in odd["text"]
    client.delete("/api/me/memory")
    assert client.get("/api/me/memory").json()["chat"] == []


def test_planting_answers_and_unknown_crop(client):
    from fieldshift import assistant
    c = client
    a = c.post("/api/fields/demo-field/analyse", json={}).json()
    assert "planting" in a and "wheat" in a["planting"] and a["data_quality"]["last_weather_date"]
    r = c.post("/api/assistant", json={"field_id": "demo-field", "question": "hi can i grow cosmos now?"}).json()
    assert "cosmos" in r["text"] and "do not have" in r["text"]
    assert r["as_of"]["weather_through"]
    r = c.post("/api/assistant", json={"field_id": "demo-field", "question": "when can i plant wheat?"}).json()
    assert "Wheat" in r["text"] and "Best sowing months" in r["text"] or "No month" in r["text"]
    r = c.post("/api/assistant", json={"field_id": "demo-field", "question": "what can I plant now?"}).json()
    assert "Sowing in" in r["text"]
    assert assistant._norm_digits("१२३ 45") == "123 45"


def test_model_fallback_on_404(monkeypatch):
    from fieldshift import ai
    calls = []

    class R:
        def __init__(s, code, js): s.status_code, s._j, s.ok, s.text = code, js, code < 400, ""
        def json(s): return s._j

    def post(url, json=None, headers=None, timeout=0):
        calls.append(url)
        if "gemini-2.5-flash:" in url:
            return R(404, {})
        return R(200, {"candidates": [{"content": {"parts": [{"text": "ok"}]}}]})

    def get(url, headers=None, timeout=0):
        return R(200, {"models": [{"name": "models/gemini-3-flash", "supportedGenerationMethods": ["generateContent"]}, {"name": "models/embedding-001", "supportedGenerationMethods": ["embedContent"]}]})
    monkeypatch.setattr(ai.requests, "post", post); monkeypatch.setattr(ai.requests, "get", get)
    assert ai.generate("s", [{"role": "user", "content": "x"}], "KEY", "gemini-2.5-flash") == "ok"
    assert any("gemini-3-flash" in u for u in calls)


def test_guest_device_account_saves_a_field_without_signup(client):
    c = client
    g = c.post("/api/auth/guest"); assert g.status_code == 200 and g.json()["guest"]
    body = {"farm": "My farm", "name": "Salkia", "lat": 22.58, "lon": 88.34, "area_ha": None, "soil": "auto", "irrigation_mm": 0, "water_availability": "medium", "current": ["wheat", "chickpea"], "history": [], "priorities": {"water": 3, "nfix": 3, "erosion": 3, "om": 3, "forage": 1, "market": 3}, "soil_test": {}, "boundary": None, "note": ""}
    s = c.post("/api/fields", json=body); assert s.status_code == 200, s.text
    assert any(f["name"] == "Salkia" for f in c.get("/api/fields").json())
    assert c.post("/api/auth/guest").json()["new"] is False        # same device keeps the same account
