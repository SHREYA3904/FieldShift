import numpy as np
import pytest
from fastapi.testclient import TestClient

from fieldshift import service
from fieldshift.api import app
from fieldshift.climate import from_power_json, synthetic
from fieldshift.crops import load_crops


def fake_power(lat=30.0):
    """Build a POWER-shaped JSON from a synthetic climate so the parser is tested offline."""
    c = synthetic(lat, annual_rain=700, mean_t=24, amp=10)
    rng = np.random.default_rng(1)
    T, R, W = {}, {}, {}
    for y in range(2005, 2026):
        for m in range(12):
            k = f"{y}{m+1:02d}"
            T[k] = float(c.temp[m] + rng.normal(0, 1))
            R[k] = float(max(0, c.rain[m] / 30.4 + rng.normal(0, 1)))
            W[k] = 0.5
        T[f"{y}13"] = 24.0
        R[f"{y}13"] = 2.0
    return {"properties": {"parameter": {"T2M": T, "PRECTOTCORR": R, "GWETROOT": W}}}


def test_crop_table_valid():
    crops = load_crops()
    assert len(crops) >= 8
    for c in crops:
        assert c.tmin < c.tlo <= c.thi < c.tmax
        assert c.need > 0 and c.dur >= 1


def test_power_parser_ignores_annual_month13_and_gives_spread():
    c = from_power_json(fake_power())
    assert c.years == 21 and c.source == "nasa_power"
    assert c.temp.shape == (12,) and (c.temp_sd > 0).all()
    assert abs(c.annual_rain() - 700) < 80


def test_southern_hemisphere_shifts_season():
    n = service.analyse(40, 0, climate=synthetic(40, mean_t=12, amp=10), n_mc=30)
    s = service.analyse(-40, 0, climate=synthetic(-40, mean_t=12, amp=10), n_mc=30)
    nm = n["strategies"][0]["crops"][0]["sow_month"]
    sm = s["strategies"][0]["crops"][0]["sow_month"]
    assert nm != sm


def test_current_rotation_always_included_first():
    out = service.analyse(30, 75, climate=from_power_json(fake_power()), current=("maize", "wheat"), n_mc=50)
    first = out["strategies"][0]
    assert first["label"] == "Your current rotation"
    assert {c["id"] for c in first["crops"]} == {"maize", "wheat"}
    assert len(out["strategies"]) >= 3


def test_uncertainty_fields_and_determinism():
    kw = dict(climate=from_power_json(fake_power()), current=("maize", "wheat"), n_mc=80, seed=3)
    a = service.analyse(30, 75, **kw)
    b = service.analyse(30, 75, **kw)
    assert a["strategies"] == b["strategies"]
    for s in a["strategies"]:
        u = s["uncertainty"]
        assert 0 <= u["p_in_top3"] <= 1 and u["overall_p10"] <= u["overall_p90"]
        assert u["p_beats_current"] is not None
    assert a["strategies"][0]["uncertainty"]["p_beats_current"] == 0.0   # current never beats itself


def test_scenario_changes_water_need():
    base = service.analyse(30, 75, climate=from_power_json(fake_power()), current=("rice", "wheat"), n_mc=30)
    dry = service.analyse(30, 75, climate=from_power_json(fake_power()), current=("rice", "wheat"),
                          rain_pct=-30, n_mc=30)
    assert (dry["strategies"][0]["scores"]["irrigation_need_mm_per_year"]
            > base["strategies"][0]["scores"]["irrigation_need_mm_per_year"])


def test_same_crop_twice_rejected():
    with pytest.raises(ValueError):
        service.analyse(30, 75, climate=synthetic(30), current=("maize", "maize"), n_mc=20)


def test_api_roundtrip_and_validation():
    c = TestClient(app)
    assert c.get("/health").json()["status"] == "ok"
    assert len(c.get("/crops").json()) >= 8
    r = c.post("/strategies", json={"lat": 30.9, "lon": 75.85, "current": ["maize", "wheat"],
                                    "offline": True, "n_mc": 30})
    assert r.status_code == 200
    body = r.json()
    assert body["climate"]["source"] == "synthetic" and body["strategies"]
    bad = c.post("/strategies", json={"lat": 30.9, "lon": 75.85, "current": ["maize", "nonsense"], "offline": True})
    assert bad.status_code == 422
    assert c.post("/strategies", json={"lat": 200, "lon": 0}).status_code == 422


def test_ml_anomalies_and_ai_template():
    from fieldshift import service, ai
    o = service.analyse(30.9, 75.85, offline=True, current=("maize", "wheat"), n_mc=30)
    assert o["climate"]["anomalies"]["monthly_risk"]["dry"]
    r = ai.explain(o["strategies"][0])
    assert r["mode"] in ("template", "ai") and r["text"]


def test_explain_endpoint_web_and_redirect():
    from fastapi.testclient import TestClient
    from fieldshift.api import app
    c = TestClient(app)
    body = {"lat": 30.9, "lon": 75.85, "current": ["maize", "wheat"], "n_mc": 30, "offline": True}
    s = c.post("/strategies", json=body).json()["strategies"][0]
    assert c.post("/explain", json={"strategy": s}).status_code == 200
    assert c.post("/explain", json={"strategy": {"x": 1}}).status_code == 422
    assert c.get("/app/").status_code == 200
    assert c.get("/", follow_redirects=False).status_code in (302, 307)
