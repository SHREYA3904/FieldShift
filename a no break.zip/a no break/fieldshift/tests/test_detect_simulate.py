import numpy as np
import pytest

from fieldshift import detect as D
from fieldshift import simulate as S


def test_mann_kendall_detects_trend_not_noise():
    rng = np.random.default_rng(1)
    trend = np.arange(30) * 0.05 + rng.normal(0, 0.2, 30)
    noise = rng.normal(0, 0.2, 30)
    assert D.mann_kendall(trend)["trend"] == "increasing"
    assert D.mann_kendall(noise)["trend"] == "no significant trend"
    assert D.mann_kendall(trend)["slope"] == pytest.approx(0.05, abs=0.02)


def test_pettitt_finds_step():
    rng = np.random.default_rng(2)
    x = np.r_[rng.normal(0, 1, 20), rng.normal(3, 1, 20)]
    r = D.pettitt(x)
    assert r["significant"] and abs(r["change_index"] - 20) <= 2


def test_spi_is_standardised():
    rng = np.random.default_rng(3)
    r = rng.gamma(2.0, 30.0, 12 * 30)
    s = D.spi(r, 3)
    assert abs(np.nanmean(s)) < 0.15 and abs(np.nanstd(s) - 1) < 0.2


def test_cdd():
    assert D.max_consecutive_dry_days([0, 0, 5, 0, 0, 0, 2]) == 3


def test_hargreaves_plausible():
    et0 = S.hargreaves_et0([38], [24], 30.0, [196])[0]
    assert 6 < et0 < 9.5          # hot summer day at 30 N


def _year(rain_per_day):
    d = np.arange(np.datetime64("2001-01-01"), np.datetime64("2004-01-01"))
    n = len(d)
    doy = (d - d.astype("datetime64[Y]")).astype(int)
    tmax = 28 + 8 * np.sin((doy - 100) / 365 * 2 * np.pi)
    return d, tmax, tmax - 12, np.full(n, rain_per_day)


def test_water_balance_physical():
    p = S.load_params()["maize"]
    awc = S.awc_from_texture(40, 20)
    d, tx, tn, wet = _year(8.0)
    _, _, _, dry = _year(0.0)
    a = S.season_distribution(d, tx, tn, wet, 30, p, awc, 5)
    b = S.season_distribution(d, tx, tn, dry, 30, p, awc, 5)
    c = S.season_distribution(d, tx, tn, dry, 30, p, awc, 5, irrigation_mm=800)
    assert a["water_stress_p50"] < 0.05
    assert b["water_stress_p50"] > 0.3
    assert c["water_stress_p50"] < b["water_stress_p50"]      # irrigation helps
    assert b["p_bad_season"] == 1.0


def test_bare_soil_erodes_more():
    rain = np.r_[np.zeros(300), np.full(65, 40.0)]
    assert S.erosion_index(rain, np.zeros(365), 0.3) > S.erosion_index(rain, np.ones(365), 0.3)
