import time

import numpy as np
import pytest

from fieldshift import pipeline as P


def fake_daily(lat=30.0, years=(2001, 2025), wet=1.0, warm=0.0, seed=0):
    rng = np.random.default_rng(seed)
    d = np.arange(np.datetime64(f"{years[0]}-01-01"), np.datetime64(f"{years[1]+1}-01-01"))
    doy = (d - d.astype("datetime64[Y]")).astype(int)
    yi = d.astype("datetime64[Y]").astype(int) + 1970 - years[0]
    tmean = 22 + 10 * np.sin((doy - 100) / 365 * 2 * np.pi) + warm * yi * 0.04 + rng.normal(0, 1.5, len(d))
    rainy = rng.random(len(d)) < (0.1 + 0.35 * (np.sin((doy - 140) / 365 * 2 * np.pi) > 0.3))
    rain = np.where(rainy, rng.gamma(0.8, 12 * wet, len(d)), 0.0)
    return {"dates": d, "T2M_MAX": tmean + 6, "T2M_MIN": tmean - 6, "PRECTOTCORR": rain, "GWETROOT": np.clip(0.3 + 0.02 * rain + rng.normal(0, 0.05, len(d)), 0, 1)}


class Fake:
    def __init__(self, raw, soil_ok=True, ndvi=True):
        self.raw, self.soil_ok, self.has_ndvi = raw, soil_ok, ndvi

    def power(self, lat, lon): return {"source": "p", "ok": True, "error": None, "fetched_at": "t", "data": self.raw}
    def soil(self, lat, lon):
        return ({"source": "s", "ok": True, "error": None, "fetched_at": "t", "data": {"sand": 35, "clay": 25, "silt": 40, "soc": 15}}
                if self.soil_ok else {"source": "s", "ok": False, "error": "timeout", "fetched_at": None, "data": None})
    def elevation(self, lat, lon): return {"ok": True, "data": 200}
    def ndvi(self, lat, lon):
        if not self.has_ndvi:
            return {"ok": False, "error": "x", "data": None, "fetched_at": None}
        raw = self.raw
        d = np.arange(np.datetime64("2005-01-15"), np.datetime64("2026-01-01"), np.timedelta64(16, "D"))
        from fieldshift import detect as DD
        ys, rm = DD.monthly_from_daily(raw["dates"], rain=raw["PRECTOTCORR"])
        _, tm = DD.monthly_from_daily(raw["dates"], temp=(raw["T2M_MAX"] + raw["T2M_MIN"]) / 2)
        ym = d.astype("datetime64[M]")
        yr = ym.astype("datetime64[Y]").astype(int) + 1970; mo = ym.astype(int) % 12
        yi = {int(y): i for i, y in enumerate(ys)}
        nd = np.array([0.15 + 0.004 * min(rm[yi[y], m] + (rm[yi[y], m - 1] if m else 0), 150) + 0.01 * (tm[yi[y], m] - 15)
                       if y in yi else np.nan for y, m in zip(yr, mo)])
        nd = np.where(yr == 2015, nd - 0.25, nd)                       # injected stress year the weather does not explain
        return {"ok": True, "error": None, "fetched_at": "t", "data": {"dates": d, "ndvi": nd}}


def run(**kw):
    raw = kw.pop("raw", None) or fake_daily()
    return P.analyse(30.0, 75.0, sources=Fake(raw, kw.pop("soil_ok", True), kw.pop("ndvi", True)), **kw)


def test_full_pipeline_shape_and_speed():
    t = time.time()
    r = run(current=("maize", "wheat"), irrigation_mm=200)
    assert time.time() - t < 60
    s = r["strategies"]
    assert len(s) >= 3 and s[0]["label"] == "Your current rotation"
    for x in s:
        assert 0 <= x["scores"]["overall"] <= 1.1 and x["uncertainty"]["overall_p10"] <= x["uncertainty"]["overall_p90"]
        assert len(x["calendar"]) == 12 and x["crops"][0]["id"] != x["crops"][1]["id"]
    assert r["detection"]["shifts"][0]["verdict"] and r["data_quality"]["years"] >= 20
    assert r["satellite"]["agreement_with_current"] is not None


def test_less_rain_means_more_water_shortfall():
    a = run(current=("maize", "wheat"))["strategies"][0]["scores"]["irrigation_need_mm_per_year"]
    b = run(current=("maize", "wheat"), rain_pct=-40)["strategies"][0]["scores"]["irrigation_need_mm_per_year"]
    assert b > a


def test_degrades_honestly_without_soil_and_ndvi():
    r = run(current=("maize", "wheat"), soil_ok=False, ndvi=False)
    assert r["evidence_grade"]["grade"] == "C" and r["satellite"] is None
    assert any("loam is assumed" in n for n in r["climate"]["notes"])


def test_detects_injected_warming():
    r = run(raw=fake_daily(warm=1.0), current=("maize", "wheat"))
    assert r["detection"]["shifts"][0]["mann_kendall"]["trend"] == "increasing"
    assert r["trend_projection"]["warming_to_2040_c"] > 0


def test_refuses_with_too_little_data():
    with pytest.raises(ValueError):
        run(raw=fake_daily(years=(2015, 2025)), current=("maize", "wheat"))


def test_wetness_cross_check_present():
    r = run(current=("maize", "wheat"))
    assert r["nasa_soil_wetness_check"] is not None and -1 <= r["nasa_soil_wetness_check"]["spearman_r"] <= 1


def test_ml_detects_unexplained_stress_year():
    r = run(current=("maize", "wheat"), rain_pct=-30)
    m = r["ml_detection"]
    assert m and m["reliable"] and m["skill_vs_monthly_average"] > 0
    assert any(f["year"] == 2015 for f in m["unexplained_stress"])
    assert m["scenario_response"]["mean_change_ndvi"] < 0          # less rain -> less greenness


def test_backup_weather_when_nasa_power_is_slow_and_is_labelled():
    raw = fake_daily()
    core = {k: raw[k] for k in ("T2M_MAX", "T2M_MIN", "PRECTOTCORR", "dates")}          # a backup source has no humidity, wind or root-zone wetness
    class Backup(Fake):
        def power(self, lat, lon): return {"source": "Open-Meteo archive", "ok": True, "error": None, "fetched_at": "t", "data": core, "backup": True, "live_error": "timeout"}
    r = P.analyse(40.0, -100.0, sources=Backup(core))
    assert r["data_quality"]["sources"]["NASA POWER daily"] is False and r["climate"]["source"] == "open_meteo_era5_backup"
    assert any("Open-Meteo" in n for n in r["climate"]["notes"])
