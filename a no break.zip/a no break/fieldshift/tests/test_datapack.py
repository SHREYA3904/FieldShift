import numpy as np
from test_app_api import client, signin   # noqa: F401
from fieldshift import datapack as D, ecocrop


def test_region_gate():
    assert D.region(39.76, -115.97)["in_region"] and not D.region(23.25, 87.86)["in_region"]


def test_ssurgo_weighting_and_unusable():
    p = D.soil_profile("demo")
    assert p["usable"] and p["sand_pct"] + p["silt_pct"] + p["clay_pct"] > 99 and p["awc_mm_per_m"] == 120
    assert D.soil_profile("no-such-unit") is None
    assert all(D.soil_profile(m["mukey"])["usable"] for m in D.mapunits()[:20])


def test_solar_unit_conversion_and_projection():
    p = D.projection("ssp370", "2081-2100")
    assert p["annual_delta_t_c"] > D.projection("ssp126", "2021-2040")["annual_delta_t_c"] > 0
    assert all(0.85 < r < 1.15 for r in p["solar_ratio"])          # ratio of same-unit values, unit mislabel cancels but not mis-scaled
    assert D.projection("bad", "2021-2040") is None
    assert 3 < max(D._nex()["ssp245"][(2050, 7)]["sw"], 3) < 40     # MJ/m2/day after x0.0864


def test_power_daily_estimated_tmax_tmin():
    d = D.power_daily()
    assert (d["T2M_MAX"] > d["T2M_MIN"]).all() and d["_estimated_tmax_tmin"]


def test_ecocrop_limits_and_missing_data():
    c = D.climatology()
    a = ecocrop.assess("barley", c["t2m_c"], 285, ph=6.5, sand=40, clay=20, drainage="Well drained")
    assert a["score"] is not None and 0 <= a["score"] <= 1
    hi = ecocrop.assess("barley", c["t2m_c"], 285, ph=9.9)
    assert hi["factors"]["ph"] == 0 and hi["limiting_factor"] == "ph"
    nodata = ecocrop.assess("barley", c["t2m_c"], 285)
    assert nodata["factors"]["ph"] is None and "salinity" in nodata["not_assessed"]


def test_priorities_parse_and_errors():
    t = D.priorities_template()
    assert D.parse_priorities("")["ok"] is False and D.parse_priorities("a,b\n1,2")["ok"] is False
    assert D.parse_priorities(t)["ok"] is False                      # template untouched: nothing filled in
    f = t.replace("maximum irrigation allocation,,,m3/ha/year,", "maximum irrigation allocation,,4500,m3/ha/year,").replace("avoid new equipment,,,", "avoid new equipment,5,,")
    r = D.parse_priorities(f)
    assert r["ok"] and r["constraints"]["max_irrigation_mm"] == 450 and any("equipment" in x["row"] for x in r["not_modelled"])


def test_cdl_noise_filter():
    c = {x["category"]: x for x in D.cdl()["crops"]}
    assert c["Alfalfa"]["reliable"] and not c["Corn"]["reliable"]


def test_api_datapack_and_demo_analysis(client):
    j = client.get("/api/datapack").json()
    assert len(j["files"]) == 8 and j["projections"]["table"]
    assert client.get("/api/datapack/projection?scenario=ssp245&period=2041-2060").status_code == 200
    assert client.get("/api/datapack/projection?scenario=x&period=y").status_code == 422
    assert client.get("/api/datapack/soils").json()
    r = client.post("/api/priorities/parse", json={"text": "bad"})
    assert r.status_code == 422
    a = client.post("/api/fields/demo-field/analyse", json={}).json()
    assert a["region"]["in_region"] and a["data_quality"]["soil"]["source"] == "ssurgo" and a["ecocrop"] and a["local_crops"]
    p = client.post("/api/fields/demo-field/analyse", json={"projection_scenario": "ssp370", "projection_period": "2081-2100"}).json()
    assert p["projection"]["annual_delta_t_c"] > 2 and p["scenario"]["hypothetical"]
    assert a["constraints"]["applied"]            # demo carries an irrigation cap


def test_assistant_place_by_name_and_friendly_404(client, monkeypatch):
    from fieldshift import geo
    signin(client)
    monkeypatch.setattr(geo, "geocode", lambda n, timeout=8: {"name": "Howrah", "admin": "West Bengal", "country": "India", "lat": 22.5892, "lon": 88.3103} if n.lower() == "howrah" else None)
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "can you check for howrah?", "language": "Auto"})
    assert r.status_code == 200 and r.json()["place"]["name"] == "Howrah"
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "what can I plant in Nowhereville now", "language": "Auto"})
    assert r.status_code == 200 and "could not find a place" in r.json()["text"]
    r = client.post("/api/assistant", json={"field_id": "not-mine", "question": "hii", "language": "Auto"})
    assert r.status_code == 404 and "pick a field again" in r.json()["detail"]
    assert geo.place_in("When can I plant rice?") is None and geo.place_in("weather at Nagpur today") == "Nagpur"


def test_translate_endpoint_uses_local_model_only_and_never_errors(client, monkeypatch):
    from fieldshift import ai
    monkeypatch.setenv("GEMINI_API_KEY", "expired-key")                                   # Gemini must never be used for translating
    monkeypatch.setattr(ai, "local_info", lambda force=False: None)
    r = client.post("/api/translate", json={"language": "Swahili", "texts": ["Hello", "Soil"]})
    assert r.status_code == 200 and r.json()["translations"] == {}                       # no local model: English stays, no error badge
    calls = []
    monkeypatch.setattr(ai, "local_info", lambda force=False: {"url": "x", "model": "m", "models": ["m"]})
    def fake(s, m, k, model=None, t=45, mt=1500, json_mode=False):
        assert k == ai.LOCAL; calls.append(1); return '["Habari", "Udongo"]'
    monkeypatch.setattr(ai, "generate", fake)
    r = client.post("/api/translate", json={"language": "Swahili", "texts": ["Hello", "Soil"]})
    assert r.json()["translations"] == {"Hello": "Habari", "Soil": "Udongo"}
    r = client.post("/api/translate", json={"language": "Swahili", "texts": ["Hello", "Soil"]})       # cached: no new call
    assert r.status_code == 200 and len(calls) == 1
    monkeypatch.setattr(ai, "generate", lambda *a, **k: '["only one"]')
    assert client.post("/api/translate", json={"language": "Swahili", "texts": ["a1", "b2"]}).status_code == 200   # a bad answer is skipped quietly
    assert client.post("/api/translate", json={"language": "x; drop", "texts": ["a"]}).status_code == 422


def test_assistant_uses_device_location(client):
    signin(client)
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "weather today where I live", "language": "Auto", "here_lat": 22.5892, "here_lon": 88.3103, "use_here": True})
    j = r.json()
    assert r.status_code == 200 and j["place"]["lat"] == 22.5892 and j["place"]["name"] == "your location"
    r = client.post("/api/assistant", json={"field_id": "demo-field", "question": "আজকের আবহাওয়া", "language": "Bengali"})
    assert r.status_code == 200


def test_spoken_summary_and_transcribe(client, monkeypatch):
    from fieldshift import assistant, ai
    s = assistant.spoken("In Pune you can plant wheat from November (0% of past years stressed, 124 days). Oats are fine too. Based on NASA POWER daily weather from 2001. Please check with an adviser.")
    assert s == "In Pune you can plant wheat from November. Oats are fine too." and len(s) < 260
    assert client.post("/api/transcribe", json={"audio_b64": "AAAA", "mime": "audio/webm"}).status_code == 402
    monkeypatch.setattr(ai, "transcribe", lambda b, m, k, l="", model=None, timeout=40: "hello terra")
    r = client.post("/api/transcribe", json={"audio_b64": "AAAA", "mime": "audio/webm;codecs=opus"}, headers={"X-AI-Key": "k"})
    assert r.json() == {"text": "hello terra"}
    signin(client)
    a = client.post("/api/assistant", json={"field_id": "demo-field", "question": "what can I plant now?", "voice": True}).json()
    assert a["spoken"] and len(a["spoken"]) <= len(a["text"])


def test_game_matches_model_and_hides_future(client):
    import numpy as np
    from fieldshift import game, simulate as S
    w = game.weather(22.59, 88.31)
    p = S.load_params()["wheat"]; awc = S.awc_from_texture(40, 20)
    i = game._start_idx(w, w["years"][0], 11, 15)
    a = game.run(w, p, awc, i, None, 150); b = S.simulate_season(w["tmax"], w["tmin"], w["rain"], w["et0"], i, p, awc, 150)
    assert abs(a["water_stress"] - b["water_stress"]) < 1e-9 and len(a["days"]) == b["days"]
    assert 0 <= game.score(0.5, 3, 1) <= 100 and game.score(0, 0, 0) == 100
    r = client.post("/api/game/play", json={"field_id": "demo-field", "crop": "wheat", "month": 11, "day": 15, "case": 1, "day_now": 28}).json()
    assert r["now"] == 28 and len(r["days"]) == 28 and "result" not in r and r["doses_left"] == 6
    r = client.post("/api/game/play", json={"field_id": "demo-field", "crop": "wheat", "month": 11, "day": 15, "case": 1, "doses": [10, 40, 70], "day_now": 300}).json()
    res = r["result"]
    assert r["finished"] and res["year"] >= 2000 and r["doses_left"] == 3 and res["rainfed"]["score"] <= 100 and res["autopilot"]["score"] >= res["rainfed"]["score"] - 1
    assert client.post("/api/game/play", json={"field_id": "demo-field", "crop": "nocrop", "month": 1}).status_code == 422


def test_game_outlook_apple_and_health_hint(client):
    ids = [c["id"] for c in client.get("/api/game/crops").json()]
    assert "apple" in ids and "wheat" in ids and "vetch" not in ids
    r = client.post("/api/game/outlook", json={"field_id": "demo-field", "crop": "apple", "month": 4, "day": 15}).json()
    assert r["verdict"] in ("good", "risky", "poor") and r["headline"] and r["years_tested"] >= 10
    r = client.post("/api/game/play", json={"field_id": "demo-field", "crop": "apple", "month": 4, "day": 15, "auto": True, "day_now": 300})
    assert r.status_code in (200, 422)
    if r.status_code == 200:
        assert r.json()["finished"] and r.json()["doses_left"] == 0
    assert "ai_hint" in client.get("/api/health").json()


def test_save_key_to_env_and_test_endpoint(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from fieldshift import ai, api
    monkeypatch.setattr(ai, "ENV_DIR", tmp_path); monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    remote = TestClient(api.app)
    assert remote.post("/api/ai/save-key", json={"key": "AIza" + "x" * 30}).status_code == 403
    local = TestClient(api.app, client=("127.0.0.1", 5000))
    assert local.post("/api/ai/save-key", json={"key": "short"}).status_code == 422
    r = local.post("/api/ai/save-key", json={"key": "AIza" + "x" * 30})
    assert r.status_code == 200 and (tmp_path / ".env").read_text().strip() == "GEMINI_API_KEY=AIza" + "x" * 30
    assert ai.env_key().startswith("AIza")
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    assert local.post("/api/ai/test").json()["ok"] is False


def test_local_model_is_used_when_no_gemini_key(monkeypatch):
    import json, threading
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from fastapi.testclient import TestClient
    from fieldshift import ai, api

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            self.send_response(200); self.send_header("content-type", "application/json"); self.end_headers()
            self.wfile.write(json.dumps({"data": [{"id": "nomic-embed-text"}, {"id": "qwen2.5:3b"}]}).encode())
        def do_POST(self):
            n = int(self.headers.get("content-length", 0)); body = json.loads(self.rfile.read(n))
            assert body["model"] == "qwen2.5:3b"
            self.send_response(200); self.send_header("content-type", "application/json"); self.end_headers()
            self.wfile.write(json.dumps({"choices": [{"message": {"content": "<think>hmm</think>Water the field tomorrow."}}]}).encode())
    srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    monkeypatch.setenv("LOCAL_LLM_URL", f"http://127.0.0.1:{srv.server_port}")
    for k in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_KEY", "AI_PROVIDER"):
        monkeypatch.delenv(k, raising=False)
    ai._LOCAL_CACHE.update(t=0.0, info=None)
    assert ai.env_key() == "local"
    assert ai.generate("sys", [{"role": "user", "content": "hi"}], "local") == "Water the field tomorrow."
    h = TestClient(api.app).get("/api/health").json()
    assert h["ai_enabled"] and h["ai_provider"] == "local" and h["ai_model"] == "qwen2.5:3b"
    assert TestClient(api.app).post("/api/ai/test").json()["ok"] is True
    srv.shutdown()
    monkeypatch.setenv("LOCAL_LLM_URL", "http://127.0.0.1:9"); ai._LOCAL_CACHE.update(t=0.0, info=None)
    assert ai.env_key() == ""


def test_bundled_locales_are_consistent():
    import json, re
    from pathlib import Path
    d = Path(__file__).resolve().parents[1] / "src" / "fieldshift" / "web" / "locales"
    data = {k: json.loads((d / f"{k}.json").read_text(encoding="utf-8")) for k in ("hi", "bn", "de")}
    assert set(data["hi"]) == set(data["bn"]) == set(data["de"]) and len(data["hi"]) > 250
    ph = lambda s: sorted(re.findall(r"\{\d+\}", s))
    for k, m in data.items():
        for en, tr in m.items():
            assert tr.strip(), (k, en)
            assert ph(en) == ph(tr), (k, en)


def test_journey_geo_spot_and_recommend(client):
    import time
    t = time.time()
    r = client.post("/api/game/recommend", json={"field_id": "geo:36.5,-116.3", "crop": "wheat", "month": 10, "day": 15})
    assert r.status_code == 200, r.text
    j = r.json()
    assert len(j["best_months"]) == 3 and len(j["other_crops"]) == 3 and j["chosen"]["crop"] == "wheat"
    assert time.time() - t < 20
    p = client.post("/api/game/play", json={"field_id": "geo:36.5,-116.3", "crop": "wheat", "month": 10, "day": 15, "auto": True, "day_now": 300})
    assert p.status_code in (200, 422)
    assert client.post("/api/game/outlook", json={"field_id": "geo:99,0", "crop": "wheat", "month": 1}).status_code == 422


def test_gemini_failure_falls_back_to_local_model(monkeypatch):
    from fieldshift import ai
    monkeypatch.setattr(ai, "_gemini", lambda *a, **k: (_ for _ in ()).throw(ai.AIError("quota")))
    monkeypatch.setattr(ai, "local_info", lambda force=False: {"model": "m", "url": "u"})
    monkeypatch.setattr(ai, "_call_local", lambda *a, **k: "from local")
    assert ai.generate("s", [{"role": "user", "content": "x"}], "somekey") == "from local"
    monkeypatch.setattr(ai, "local_info", lambda force=False: None)
    import pytest
    with pytest.raises(ai.AIError):
        ai.generate("s", [{"role": "user", "content": "x"}], "somekey")


def _fake_year_weather(monkeypatch):
    import numpy as np
    from fieldshift import game
    d = np.arange("2005-01-01", "2026-01-01", dtype="datetime64[D]"); n = len(d); r = np.random.default_rng(3)
    doy = (d - d.astype("datetime64[Y]")).astype(int)
    tmax = 18 + 10 * np.sin((doy - 100) / 58.1) + r.normal(0, 1.5, n)
    tmin = tmax - 11 + r.normal(0, 1, n)
    rain = np.maximum(r.normal(0.5, 3, n), 0)
    from fieldshift import simulate as S
    et0 = S.hargreaves_et0(tmax, tmin, 30.0, doy + 1)
    yrs = list(range(2005, 2026))
    game._W.clear(); game._W[(30.0, 70.0)] = {"dates": d, "tmax": tmax, "tmin": tmin, "rain": rain, "et0": et0, "years": yrs, "bundled": False, "source": "NASA POWER daily"}


def test_game_tools_scout_cover_mulch(client, monkeypatch):
    _fake_year_weather(monkeypatch)
    base = {"field_id": "geo:30.0,70.0", "crop": "wheat", "month": 11, "day": 15, "case": 2}
    plain = client.post("/api/game/play", json={**base, "day_now": 300}).json()
    mul = client.post("/api/game/play", json={**base, "day_now": 300, "mulch": 5}).json()
    assert mul["result"]["water_stress"] <= plain["result"]["water_stress"]          # mulch never makes the season drier
    resp = client.post("/api/game/play", json={**base, "day_now": 30, "scouts": [10, 20, 29, 29]}); assert resp.status_code == 200, resp.text; mid = resp.json()
    assert mid["scouts_left"] == 1 and len(mid["peeks"]) == 3                          # day 29 listed twice counts once
    assert all(p["from"] < mid["now"] for p in mid["peeks"])                           # a peek never starts after the player's own day
    assert client.post("/api/game/play", json={**base, "day_now": 5, "scouts": [20]}).json()["peeks"] == []   # cannot scout from a day that has not happened
    assert client.post("/api/game/play", json={**base, "day_now": 300, "covers": [1, 2, 3]}).status_code == 422      # at most 2 covers


def test_cover_only_helps_on_a_frost_night():
    import numpy as np
    from fieldshift import game, simulate as S
    cr = game.crops()["wheat"]
    n = 400; w = {"tmax": np.full(n, 20.0), "tmin": np.full(n, 8.0), "rain": np.full(n, 1.0), "et0": np.full(n, 3.0)}
    w["tmin"][30] = cr.cold_crit - 3                                                    # one frost night on day 30
    a = game.run(w, cr, 150.0, 0, {})
    b = game.run(w, cr, 150.0, 0, {}, covers=frozenset({30}))
    c = game.run(w, cr, 150.0, 0, {}, covers=frozenset({31}))                          # cover on the wrong night
    assert a["cold_days"] == 1 and b["cold_days"] == 0 and c["cold_days"] == 1
    assert b["score"] > a["score"] == c["score"]


def test_weather_backup_when_nasa_power_is_down(monkeypatch):
    import numpy as np
    from fieldshift import game, ingest, pipeline as P
    d = np.arange("2005-01-01", "2026-01-01", dtype="datetime64[D]"); n = len(d)
    monkeypatch.setattr(ingest, "openmeteo_daily", lambda la, lo: {"T2M_MAX": np.full(n, 25.0), "T2M_MIN": np.full(n, 12.0), "PRECTOTCORR": np.full(n, 1.0), "dates": d})
    class Down:
        def power(self, la, lo): return {"ok": False, "error": "down", "data": None, "source": "NASA POWER daily"}
    monkeypatch.setattr(P, "Sources", Down); game._W.clear()
    w = game.weather(12.34, 56.78)
    assert "Open-Meteo" in w["source"] and len(w["years"]) >= 20
    def Both(la, lo): raise OSError("no network")
    monkeypatch.setattr(ingest, "openmeteo_daily", Both); game._W.clear()
    import pytest
    with pytest.raises(RuntimeError):
        game.weather(12.34, 56.78)


def test_locale_pattern_rules():
    import json, pathlib
    for code in ("bn", "hi", "de"):
        d = json.loads((pathlib.Path(__file__).parents[1] / "src/fieldshift/web/locales" / f"{code}.json").read_text(encoding="utf-8"))
        for k in ("Home", "My Season", "My Farm", "Ask Terra", "Sow in {0} and {1}", "{0} then {1}", "Wheat", "Jan"):
            assert k in d, (code, k)



def test_worst_year_has_the_lowest_rainfed_score(client, monkeypatch):
    _fake_year_weather(monkeypatch)
    base = {"field_id": "geo:30.0,70.0", "crop": "wheat", "month": 11, "day": 15, "day_now": 300}
    worst = client.post("/api/game/play", json={**base, "worst": True}).json()
    assert worst["worst"] is True
    scores = [client.post("/api/game/play", json={**base, "case": c}).json()["result"]["rainfed"]["score"] for c in range(12)]
    assert worst["result"]["rainfed"]["score"] <= min(scores)


def test_expired_gemini_key_switches_to_local_model_and_stays_there(monkeypatch):
    from fieldshift import ai
    calls = {"g": 0, "l": 0}
    def bad(*a, **k):
        calls["g"] += 1; raise ai.AIError("API key expired")
    def good(*a, **k):
        calls["l"] += 1; return "from local"
    monkeypatch.setattr(ai, "_gemini", bad); monkeypatch.setattr(ai, "_call_local", good)
    monkeypatch.setattr(ai, "local_info", lambda force=False: {"url": "x", "model": "m", "models": ["m"]})
    ai._GEM_BAD["until"] = 0.0
    assert ai.generate("s", [{"role": "user", "content": "hi"}], "KEY") == "from local"
    assert ai.generate("s", [{"role": "user", "content": "hi"}], "KEY") == "from local"
    assert calls["g"] == 1 and calls["l"] == 2          # the second question did not wait for Gemini again
    ai._GEM_BAD["until"] = 0.0

